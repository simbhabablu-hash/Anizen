# AniZen shared gallery visibility fix

## Problem
Anime added from the admin gallery could remain only in the admin browser's IndexedDB when the configured Worker/API was stale, unavailable, or a previous local configuration was broken. The UI could still show the anime on that phone.

## Changes
- Added automatic fallback to the built-in shared Nostr catalog when the configured Worker/API cannot be read.
- Added automatic fallback to Nostr when a catalog save fails on the configured backend.
- Failed catalog writes are now retained as pending and retried automatically after 5 seconds instead of being silently dropped.
- Refresh/focus/online sync also falls back to the same public catalog rather than silently switching to a private local view.
- The admin browser switches its active catalog ID to `nostr` after a successful fallback, so subsequent gallery uploads continue going to the shared catalog.

## Important media note
Anime metadata and gallery images can be made public through the shared catalog. Video files selected from a phone gallery are still device-local unless they are uploaded to a public video host (for example Cloudinary) or replaced with a public MP4/stream URL. This is a storage limitation, not a catalog visibility bug.

## Deployment
1. Build/deploy the project normally.
2. Open Admin → Data Safety & Sharing and confirm the status becomes `LIVE — sabko dikhega` after the first successful publish.
3. Add an anime from Gallery and wait for the sync status to become `saved`/LIVE.
4. Open the public site in an incognito window or another phone to verify.

# AniZen Share Sheet Fix

- Share sheet now uses a high z-index so it stays above the mobile bottom navigation.
- Mobile sheet has a dynamic viewport max-height (`dvh`) and internal scrolling.
- Added safe-area bottom padding for Android/iOS browser gesture/navigation areas.
- Added a mobile drag handle and prevented content from being clipped.
- Desktop behavior remains centered and unchanged.

# AniZen Share Sheet Fix v2

Fixed the actual clipping cause: ShareSheet was rendered as a fixed child inside the Framer Motion AnimeModal container. A transformed ancestor can create a containing block for fixed descendants, so the sheet was positioned relative to the modal and clipped on mobile.

Changes:
- ShareSheet is now portaled directly to document.body with ReactDOM createPortal.
- z-index increased to 9999 so it stays above the bottom navigation.
- Mobile sheet uses 100dvh/safe-area-aware max height.
- Content scrolls inside the sheet instead of being clipped.
- Buttons use one/two-column responsive layout and remain reachable on small screens.
- No anime/catalog/player behavior changed.

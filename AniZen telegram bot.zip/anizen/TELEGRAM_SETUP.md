# AniZen × Telegram Bot — Setup (5 minute)

Website ka frontend **kabhi bhi bot token hold nahi karta** (har visitor ko dikhta).
Saara connection backend (`server/`) mein hota hai. Bas ye steps follow karo:

## 1) BotFather se token lo
1. Telegram mein **@BotFather** kholo → `/newbot` → naam + username do.
2. Token milega, e.g. `123456:ABC-...`. **Ye secret hai — kahin public mat dalo.**

> ⚠️ Agar token kahin leak ho gaya ho (chat, screenshot, git), BotFather mein
> `/revoke` karke naya token bana lo. Purana token turant kaam karna band kar dega.

## 2) Apni chat id lo
**@userinfobot** ko message karo — wo tumhari numeric chat id dega
(TELEGRAM_ADMIN_CHAT_ID mein chahiye, notifications ke liye).

## 3) Server env vars set karo
Hosting platform (Render/Railway/Fly) ya `server/.env` mein:

```
TELEGRAM_BOT_TOKEN=123456:ABC-...        # BotFather ka token
TELEGRAM_WEBHOOK_SECRET=random-long-secret   # `openssl rand -hex 32`
TELEGRAM_ADMIN_CHAT_ID=123456789         # @userinfobot ki id
SITE_URL=https://aapki-site.vercel.app   # public website URL
```

## 4) Webhook set karo (bot ↔ server connect)

Server ka public HTTPS URL maan lo `https://anizen-api.onrender.com` hai.
Admin JWT token se ye call karo (ya browser/Postman se):

```bash
curl -X POST https://anizen-api.onrender.com/api/admin/telegram/webhook   -H "Authorization: Bearer ADMIN_JWT"   -H "Content-Type: application/json"   -d '{"url": "https://anizen-api.onrender.com/api/telegram/webhook"}'
```

Webhook URL hamesha yehi format rakho: `{API_URL}/api/telegram/webhook`

Check status: `GET /api/admin/telegram/status` (admin JWT chahiye)

## 5) Website pe bot ka button (optional)
Vercel env var: `VITE_TELEGRAM_BOT_URL=https://t.me/AapkeBotKaUsername`
Footer mein automatically ek 🤖 button aa jayega.

## Kya-kya kaam karta hai
| Feature | Kaise |
|---|---|
| `/start`, `/help` | Bot welcome + commands |
| `/catalog` | Latest anime list (direct watch links ke saath) |
| `/anime <id>` | Anime ki details + watch link |
| `/link` | Website link |
| New anime notification | Admin panel mein naya anime add karte hi tumhare Telegram pe message 📲 |

## Files jo add/hue change hue
- `server/src/telegram.js` — naya (Telegram API helper, koi extra package nahi)
- `server/src/index.js` — webhook endpoint, admin routes, notify-on-add
- `server/.env.example` — naye env vars
- `src/social.ts` + `src/components/Footer.tsx` — optional bot button

# AniZen Backend (real server)

Small, self-contained Node + Express + SQLite backend for AniZen. All admin
write operations require a JWT (admin login); reads are public so every visitor
gets the same catalog.

## Endpoints

| Method | Path                          | Auth  | What                                          |
| ------ | ----------------------------- | ----- | --------------------------------------------- |
| GET    | `/api/health`                 | –     | Simple health check                           |
| GET    | `/api/catalog`                | –     | Full anime catalog (with ETag)                |
| GET    | `/api/anime/:id`              | –     | One anime with episodes                       |
| POST   | `/api/auth/login`             | –     | `{ password }` → `{ token, expiresIn }`       |
| GET    | `/api/auth/me`                | admin | Verifies the JWT                              |
| POST   | `/api/auth/change-password`   | admin | `{ current, next }`                           |
| POST   | `/api/anime`                  | admin | Create or upsert an anime                     |
| PUT    | `/api/anime/:id`              | admin | Update an anime (replaces its episodes)       |
| DELETE | `/api/anime/:id`              | admin | Delete an anime and its episodes              |
| PUT    | `/api/catalog`                | admin | Replace the whole catalog (`{ anime: [] }`)   |

## Run locally

```bash
cd server
cp .env.example .env         # then edit .env
npm install
npm run dev                  # or: npm start
# API is now on http://localhost:8080
```

Point the website to it: in your website root, create `.env.local`:

```
VITE_API_URL=http://localhost:8080
```

Then `npm run dev` in the website folder.

## Deploy (free options)

- **Railway / Render / Fly.io / Northflank**: connect this `server/` folder,
  set the env vars from `.env.example`, deploy. All give you an HTTPS URL you
  can put into `VITE_API_URL` on your Vercel website settings.
- **Docker**: `Dockerfile` example:

  ```Dockerfile
  FROM node:20-alpine
  WORKDIR /app
  COPY package*.json ./
  RUN npm ci --omit=dev
  COPY . .
  ENV PORT=8080
  EXPOSE 8080
  CMD ["node", "src/index.js"]
  ```

## Env vars

| Var              | Meaning                                            |
| ---------------- | -------------------------------------------------- |
| `PORT`           | HTTP port (default 8080)                           |
| `CORS_ORIGIN`    | Allowed origins (comma-separated) or `*`           |
| `JWT_SECRET`     | Long random string — signs admin tokens            |
| `ADMIN_PASSWORD` | Initial admin password (seeded once)               |
| `DB_FILE`        | Path to the SQLite file (auto-created)             |

## Notes

- Data lives in a single SQLite file (`data/anizen.db`). Back it up regularly.
- Admin login is JWT-based (30-day tokens). The token is stored only in the
  admin's browser (`localStorage`).
- Videos/images are **not** stored on this server — only their URLs. Host media
  on Cloudinary, S3, YouTube, etc. and paste the URL in the admin form.

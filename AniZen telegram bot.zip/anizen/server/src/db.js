import Database from "better-sqlite3";
import fs from "node:fs";
import path from "node:path";
import bcrypt from "bcryptjs";

const DB_FILE = process.env.DB_FILE || "./data/anizen.db";
fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });

export const db = new Database(DB_FILE);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
  CREATE TABLE IF NOT EXISTS anime (
    id            TEXT PRIMARY KEY,
    title         TEXT NOT NULL,
    title_english TEXT,
    synopsis      TEXT,
    poster        TEXT,
    banner        TEXT,
    thumbnail     TEXT,
    genres        TEXT NOT NULL DEFAULT '[]',
    type          TEXT,
    status        TEXT,
    year          INTEGER,
    rating        REAL DEFAULT 0,
    studio        TEXT,
    featured      INTEGER NOT NULL DEFAULT 0,
    trailer_url   TEXT,
    created_at    INTEGER NOT NULL,
    updated_at    INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS episode (
    id         TEXT PRIMARY KEY,
    anime_id   TEXT NOT NULL,
    number     INTEGER NOT NULL,
    title      TEXT NOT NULL,
    video_url  TEXT NOT NULL,
    video_type TEXT NOT NULL DEFAULT 'mp4',
    thumbnail  TEXT,
    duration   TEXT,
    position   INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (anime_id) REFERENCES anime(id) ON DELETE CASCADE
  );

  CREATE INDEX IF NOT EXISTS idx_episode_anime ON episode(anime_id);
  CREATE INDEX IF NOT EXISTS idx_anime_updated ON anime(updated_at DESC);

  CREATE TABLE IF NOT EXISTS admin_user (
    id            INTEGER PRIMARY KEY,
    password_hash TEXT NOT NULL,
    updated_at    INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT
  );
`);

/** Seed the admin password from ADMIN_PASSWORD if no admin exists yet. */
export function seedAdminIfMissing() {
  const row = db.prepare("SELECT id FROM admin_user WHERE id = 1").get();
  if (row) return;
  const plain = process.env.ADMIN_PASSWORD || "balvir63";
  const hash = bcrypt.hashSync(plain, 10);
  db.prepare(
    "INSERT INTO admin_user (id, password_hash, updated_at) VALUES (1, ?, ?)",
  ).run(hash, Date.now());
  console.log("Admin password seeded from ADMIN_PASSWORD env.");
}

function rowToAnime(row, episodes) {
  return {
    id: row.id,
    title: row.title,
    titleEnglish: row.title_english || "",
    synopsis: row.synopsis || "",
    poster: row.poster || "",
    banner: row.banner || "",
    thumbnail: row.thumbnail || "",
    genres: JSON.parse(row.genres || "[]"),
    type: row.type || "TV",
    status: row.status || "Ongoing",
    year: row.year || 0,
    rating: Number(row.rating) || 0,
    studio: row.studio || "",
    featured: !!row.featured,
    trailerUrl: row.trailer_url || "",
    createdAt: row.created_at,
    episodes,
  };
}

function rowToEpisode(row) {
  return {
    id: row.id,
    number: row.number,
    title: row.title,
    videoUrl: row.video_url,
    videoType: row.video_type,
    thumbnail: row.thumbnail || "",
    duration: row.duration || "",
  };
}

const listAnimeStmt = db.prepare("SELECT * FROM anime ORDER BY updated_at DESC");
const getEpisodesStmt = db.prepare(
  "SELECT * FROM episode WHERE anime_id = ? ORDER BY position ASC, number ASC",
);
const getAnimeStmt = db.prepare("SELECT * FROM anime WHERE id = ?");
const upsertAnimeStmt = db.prepare(`
  INSERT INTO anime (id, title, title_english, synopsis, poster, banner, thumbnail,
                     genres, type, status, year, rating, studio, featured, trailer_url,
                     created_at, updated_at)
  VALUES (@id, @title, @titleEnglish, @synopsis, @poster, @banner, @thumbnail,
          @genres, @type, @status, @year, @rating, @studio, @featured, @trailerUrl,
          @createdAt, @updatedAt)
  ON CONFLICT(id) DO UPDATE SET
    title=@title, title_english=@titleEnglish, synopsis=@synopsis,
    poster=@poster, banner=@banner, thumbnail=@thumbnail,
    genres=@genres, type=@type, status=@status, year=@year, rating=@rating,
    studio=@studio, featured=@featured, trailer_url=@trailerUrl,
    updated_at=@updatedAt
`);
const deleteEpisodesStmt = db.prepare("DELETE FROM episode WHERE anime_id = ?");
const insertEpisodeStmt = db.prepare(`
  INSERT INTO episode (id, anime_id, number, title, video_url, video_type, thumbnail, duration, position)
  VALUES (@id, @animeId, @number, @title, @videoUrl, @videoType, @thumbnail, @duration, @position)
`);
const deleteAnimeStmt = db.prepare("DELETE FROM anime WHERE id = ?");

export function listAnime() {
  const rows = listAnimeStmt.all();
  return rows.map((r) => rowToAnime(r, getEpisodesStmt.all(r.id).map(rowToEpisode)));
}

export function getAnime(id) {
  const row = getAnimeStmt.get(id);
  if (!row) return null;
  return rowToAnime(row, getEpisodesStmt.all(row.id).map(rowToEpisode));
}

function saveAnimeRow(anime) {
  const now = Date.now();
  upsertAnimeStmt.run({
    id: String(anime.id),
    title: String(anime.title || "Untitled"),
    titleEnglish: anime.titleEnglish || "",
    synopsis: anime.synopsis || "",
    poster: anime.poster || "",
    banner: anime.banner || "",
    thumbnail: anime.thumbnail || "",
    genres: JSON.stringify(Array.isArray(anime.genres) ? anime.genres : []),
    type: anime.type || "TV",
    status: anime.status || "Ongoing",
    year: Number(anime.year) || 0,
    rating: Number(anime.rating) || 0,
    studio: anime.studio || "",
    featured: anime.featured ? 1 : 0,
    trailerUrl: anime.trailerUrl || "",
    createdAt: Number(anime.createdAt) || now,
    updatedAt: now,
  });
  deleteEpisodesStmt.run(anime.id);
  const eps = Array.isArray(anime.episodes) ? anime.episodes : [];
  eps.forEach((ep, i) => {
    insertEpisodeStmt.run({
      id: String(ep.id || `${anime.id}-e${ep.number || i + 1}`),
      animeId: String(anime.id),
      number: Number(ep.number) || i + 1,
      title: String(ep.title || `Episode ${i + 1}`),
      videoUrl: String(ep.videoUrl || ""),
      videoType: ep.videoType === "embed" ? "embed" : "mp4",
      thumbnail: ep.thumbnail || "",
      duration: ep.duration || "",
      position: i,
    });
  });
}

const saveTxn = db.transaction((anime) => saveAnimeRow(anime));

export function saveAnime(anime) {
  saveTxn(anime);
  return getAnime(anime.id);
}

export function deleteAnime(id) {
  return deleteAnimeStmt.run(id).changes > 0;
}

export function replaceAll(animeList) {
  if (!Array.isArray(animeList)) throw new TypeError("animeList must be an array");
  const tx = db.transaction((list) => {
    db.prepare("DELETE FROM anime").run();
    for (const a of list) saveAnimeRow(a);
  });
  tx(animeList);
}

/** Simple etag from the newest updated_at + count — used by the client to poll cheaply. */
export function catalogEtag() {
  const r = db
    .prepare("SELECT COUNT(*) AS n, COALESCE(MAX(updated_at), 0) AS t FROM anime")
    .get();
  return `${r.n}-${r.t}`;
}

export function verifyAdminPassword(password) {
  const row = db.prepare("SELECT password_hash FROM admin_user WHERE id = 1").get();
  if (!row) return false;
  return bcrypt.compareSync(password, row.password_hash);
}

export function changeAdminPassword(newPassword) {
  const hash = bcrypt.hashSync(newPassword, 10);
  db.prepare("UPDATE admin_user SET password_hash = ?, updated_at = ? WHERE id = 1").run(
    hash,
    Date.now(),
  );
}

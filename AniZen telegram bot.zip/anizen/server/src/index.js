import express from "express";
import cors from "cors";
import morgan from "morgan";
import jwt from "jsonwebtoken";
import {
  catalogEtag,
  changeAdminPassword,
  deleteAnime,
  getAnime,
  listAnime,
  replaceAll,
  saveAnime,
  seedAdminIfMissing,
  verifyAdminPassword,
} from "./db.js";
import {
  deleteWebhook as tgDeleteWebhook,
  getMe,
  getWebhookInfo,
  notifyAdmin,
  sendMessage,
  setWebhook as tgSetWebhook,
  telegramAdminChat,
  telegramEnabled,
  telegramSiteUrl,
} from "./telegram.js";

const PORT = Number(process.env.PORT) || 8080;
const JWT_SECRET = process.env.JWT_SECRET || "change-me-in-production";
const CORS_ORIGIN = process.env.CORS_ORIGIN || "*";
const TG_SECRET = process.env.TELEGRAM_WEBHOOK_SECRET || "";
const SITE_URL = telegramSiteUrl();

seedAdminIfMissing();

const app = express();
app.disable("x-powered-by");
app.set("trust proxy", 1);
app.use(express.json({ limit: "25mb" }));
app.use(morgan("tiny"));

const origins = CORS_ORIGIN.split(",").map((s) => s.trim()).filter(Boolean);
app.use(
  cors({
    origin: origins.includes("*") ? true : origins,
    methods: ["GET", "POST", "PUT", "DELETE"],
    allowedHeaders: ["Content-Type", "Authorization"],
  }),
);

/** Require a valid admin JWT for the route. */
function requireAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "Auth token missing" });
  try {
    jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: "Invalid or expired token" });
  }
}

/** Very light rate-limit for login attempts. */
const loginAttempts = new Map();
function throttleLogin(req, res, next) {
  const ip = req.ip || "unknown";
  const now = Date.now();
  const rec = loginAttempts.get(ip) || { count: 0, first: now };
  if (now - rec.first > 60_000) {
    rec.count = 0;
    rec.first = now;
  }
  rec.count += 1;
  loginAttempts.set(ip, rec);
  if (rec.count > 10) {
    return res.status(429).json({ error: "Too many login attempts, thodi der ruko" });
  }
  next();
}

/* ------------------------------ Public routes ------------------------------ */

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, name: "anizen-backend", time: Date.now() });
});

app.get("/api/catalog", (req, res) => {
  const etag = `W/"${catalogEtag()}"`;
  if (req.headers["if-none-match"] === etag) {
    res.set("ETag", etag);
    return res.status(304).end();
  }
  res.set("ETag", etag);
  res.set("Cache-Control", "public, max-age=15");
  res.json({ version: 1, anime: listAnime(), etag });
});

app.get("/api/anime/:id", (req, res) => {
  const a = getAnime(req.params.id);
  if (!a) return res.status(404).json({ error: "Not found" });
  res.json(a);
});

/* ------------------------------ Auth ------------------------------ */

app.post("/api/auth/login", throttleLogin, (req, res) => {
  const { password } = req.body || {};
  if (!password || typeof password !== "string") {
    return res.status(400).json({ error: "Password chahiye" });
  }
  if (!verifyAdminPassword(password)) {
    return res.status(401).json({ error: "Galat password" });
  }
  const token = jwt.sign({ role: "admin" }, JWT_SECRET, { expiresIn: "30d" });
  res.json({ token, expiresIn: 30 * 24 * 60 * 60 });
});

app.get("/api/auth/me", requireAuth, (_req, res) => {
  res.json({ role: "admin" });
});

app.post("/api/auth/change-password", requireAuth, (req, res) => {
  const { current, next } = req.body || {};
  if (!current || !next) return res.status(400).json({ error: "Missing fields" });
  if (!verifyAdminPassword(current)) return res.status(401).json({ error: "Purana password galat" });
  if (String(next).length < 6) return res.status(400).json({ error: "Naya password kam se kam 6 chars ka do" });
  changeAdminPassword(String(next));
  res.json({ ok: true });
});

/* ------------------------------ Admin CRUD ------------------------------ */

app.post("/api/anime", requireAuth, (req, res) => {
  const body = req.body;
  if (!body || !body.id || !body.title) {
    return res.status(400).json({ error: "id aur title chahiye" });
  }
  const existed = Boolean(getAnime(body.id));
  const saved = saveAnime(body);
  // Naya anime add hua → Telegram bot se admin ko notification.
  if (!existed && telegramAdminChat()) {
    notifyAdmin(
      [
        "🆕 <b>Naya anime add hua!</b>",
        "",
        `🎬 <b>${escapeHtml(saved.title)}</b>`,
        [saved.type, saved.status, saved.year ? `📅 ${saved.year}` : "", saved.rating ? `⭐ ${saved.rating}` : ""]
          .filter(Boolean)
          .join("  "),
        `🎞 Episodes: ${Array.isArray(saved.episodes) ? saved.episodes.length : 0}`,
        "",
        `👉 Dekho: ${tgLink(`/?watch=${encodeURIComponent(saved.id)}`)}`,
      ].join("\n"),
    ).catch((err) => console.error("telegram notify error:", err));
  }
  res.status(201).json(saved);
});

app.put("/api/anime/:id", requireAuth, (req, res) => {
  const id = req.params.id;
  const body = { ...req.body, id };
  if (!body.title) return res.status(400).json({ error: "title chahiye" });
  const saved = saveAnime(body);
  res.json(saved);
});

app.delete("/api/anime/:id", requireAuth, (req, res) => {
  const ok = deleteAnime(req.params.id);
  if (!ok) return res.status(404).json({ error: "Not found" });
  res.json({ ok: true });
});

app.put("/api/catalog", requireAuth, (req, res) => {
  const body = req.body;
  const list = Array.isArray(body) ? body : body?.anime;
  if (!Array.isArray(list)) return res.status(400).json({ error: "anime array chahiye" });
  replaceAll(list);
  res.json({ ok: true, count: list.length });
});

/* ------------------------------ Telegram bot ------------------------------ */

/** Escape user/database content for Telegram HTML parse mode. */
function escapeHtml(s) {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

const tgLink = (path = "") => `${SITE_URL}${path}`;

/** Handle one Telegram update (currently: text commands). */
async function handleTelegramUpdate(update) {
  const msg = update?.message;
  const text = msg?.text;
  if (!msg || !text) return;
  const chatId = msg.chat.id;
  const cmdRaw = text.trim().split(/\s+/)[0] || "";
  const cmd = cmdRaw.split("@")[0].toLowerCase();
  const arg = text.trim().slice(cmdRaw.length).trim();

  if (cmd === "/start" || cmd === "/help") {
    await sendMessage(
      chatId,
      [
        "👋 <b>AniZen Bot mein swagat hai!</b>",
        "",
        `🌐 Website: ${tgLink()}`,
        "",
        "<b>Commands:</b>",
        "/catalog — latest anime ki list",
        "/anime \u003cid\u003e — kisi anime ki details",
        "/link — website ka link",
        "/help — ye message",
      ].join("\n"),
      { disable_web_page_preview: false },
    );
    return;
  }

  if (cmd === "/link") {
    await sendMessage(chatId, `🌐 AniZen: ${tgLink()}`, { disable_web_page_preview: false });
    return;
  }

  if (cmd === "/catalog") {
    const all = listAnime();
    if (!all.length) {
      await sendMessage(chatId, "Abhi catalog khaali hai. 🫥");
      return;
    }
    const lines = all.slice(0, 20).map((a) => {
      const meta = [a.year ? `📅 ${a.year}` : "", a.rating ? `⭐ ${a.rating}` : ""]
        .filter(Boolean)
        .join("  ");
      return `• <a href="${tgLink(`/?watch=${encodeURIComponent(a.id)}`)}">${escapeHtml(a.title)}</a>${meta ? "  " + meta : ""}`;
    });
    if (all.length > 20) lines.push(`…aur ${all.length - 20} aur! Website pe dekho: ${tgLink()}`);
    await sendMessage(chatId, `<b>📚 Latest Anime (${all.length}):</b>\n\n${lines.join("\n")}`, {
      disable_web_page_preview: true,
    });
    return;
  }

  if (cmd === "/anime") {
    if (!arg) {
      await sendMessage(chatId, "Use: /anime \u003cid\u003e — id /catalog se milta hai.");
      return;
    }
    const a = getAnime(arg);
    if (!a) {
      await sendMessage(chatId, `❌ "${escapeHtml(arg)}" naam ka koi anime nahi mila. /catalog se id check karo.`);
      return;
    }
    const eps = Array.isArray(a.episodes) ? a.episodes.length : 0;
    await sendMessage(
      chatId,
      [
        `🎬 <b>${escapeHtml(a.title)}</b>`,
        a.titleEnglish ? `<i>${escapeHtml(a.titleEnglish)}</i>` : "",
        a.synopsis ? `\n${escapeHtml(a.synopsis.slice(0, 300))}${a.synopsis.length > 300 ? "…" : ""}` : "",
        "",
        [a.type, a.status, a.year ? `📅 ${a.year}` : "", a.rating ? `⭐ ${a.rating}` : ""]
          .filter(Boolean)
          .join("  "),
        `🎞 Episodes: ${eps}`,
        "",
        `👉 Dekho: ${tgLink(`/?watch=${encodeURIComponent(a.id)}`)}`,
      ]
        .filter((l) => l !== null)
        .join("\n"),
      { disable_web_page_preview: false },
    );
    return;
  }

  // Unknown command — friendly fallback.
  await sendMessage(chatId, `Samjha nahi 🤔 — /help se commands dekho. Website: ${tgLink()}`);
}

/**
 * Telegram webhook endpoint.
 * Set this URL in BotFather (ya admin endpoint se) + TELEGRAM_WEBHOOK_SECRET
 * match karna zaroori hai — bina secret ke koi bhi fake update bhej sakta hai.
 */
app.post("/api/telegram/webhook", (req, res) => {
  if (TG_SECRET && req.headers["x-telegram-bot-api-secret-token"] !== TG_SECRET) {
    return res.status(401).json({ error: "Invalid webhook secret" });
  }
  res.status(200).json({ ok: true }); // Telegram ko turant 200 chahiye
  Promise.resolve()
    .then(() => handleTelegramUpdate(req.body))
    .catch((err) => console.error("telegram update error:", err));
});

/* ------------------------------ Telegram admin ------------------------------ */

app.get("/api/admin/telegram/status", requireAuth, async (_req, res) => {
  if (!telegramEnabled()) return res.json({ configured: false });
  const [me, info] = await Promise.all([getMe(), getWebhookInfo()]);
  res.json({
    configured: true,
    bot: me.ok ? { id: me.result.id, username: me.result.username, name: me.result.first_name } : null,
    webhook: info.ok ? info.result : null,
    adminChat: telegramAdminChat() ? "set" : "not set",
    siteUrl: SITE_URL || "not set",
  });
});

app.post("/api/admin/telegram/webhook", requireAuth, async (req, res) => {
  const url = String(req.body?.url || "").trim();
  if (!/^https:\/\//.test(url)) {
    return res.status(400).json({ error: "HTTPS webhook URL chahiye" });
  }
  if (!TG_SECRET) {
    return res.status(400).json({ error: "TELEGRAM_WEBHOOK_SECRET env var set karo pehle" });
  }
  const r = await tgSetWebhook(url, TG_SECRET);
  if (!r.ok) return res.status(502).json({ error: r.error || r.description || "setWebhook failed" });
  res.json({ ok: true, result: r.result, description: r.description });
});

app.delete("/api/admin/telegram/webhook", requireAuth, async (_req, res) => {
  const r = await tgDeleteWebhook();
  if (!r.ok) return res.status(502).json({ error: r.error || r.description || "deleteWebhook failed" });
  res.json({ ok: true, result: r.result });
});

/* ------------------------------ Boot ------------------------------ */

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Server error" });
});

app.listen(PORT, () => {
  console.log(`AniZen API running on http://localhost:${PORT}`);
});

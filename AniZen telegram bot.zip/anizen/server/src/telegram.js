// ---------------------------------------------------------------------------
// Telegram Bot API helper — no extra dependencies (uses global fetch, Node 18+).
//
// IMPORTANT: the bot token lives ONLY on this server (env var / hosting secret).
// NEVER put TELEGRAM_BOT_TOKEN in the Vite frontend — anything in src/ is shipped
// to every visitor's browser, and anyone who sees the token controls your bot.
// ---------------------------------------------------------------------------

const BOT_TOKEN = (process.env.TELEGRAM_BOT_TOKEN || "").trim();
const ADMIN_CHAT_ID = (process.env.TELEGRAM_ADMIN_CHAT_ID || "").trim();
const SITE_URL = (process.env.SITE_URL || "").trim().replace(/\/$/, "");

export const telegramEnabled = () => Boolean(BOT_TOKEN);
export const telegramAdminChat = () => ADMIN_CHAT_ID;
export const telegramSiteUrl = () => SITE_URL;

const api = (method) => `https://api.telegram.org/bot${BOT_TOKEN}/${method}`;

async function call(method, payload) {
  if (!telegramEnabled()) return { ok: false, error: "TELEGRAM_BOT_TOKEN not set" };
  try {
    const res = await fetch(api(method), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload ?? {}),
    });
    return await res.json();
  } catch (err) {
    return { ok: false, error: String(err?.message || err) };
  }
}

/** Send a text message. Extra params (reply_markup, etc.) pass through. */
export function sendMessage(chatId, text, extra = {}) {
  if (!chatId) return Promise.resolve({ ok: false, error: "No chat_id" });
  return call("sendMessage", {
    chat_id: chatId,
    text,
    parse_mode: "HTML",
    disable_web_page_preview: true,
    ...extra,
  });
}

/** Send a message to the admin chat (new-anime notifications, etc.). */
export const notifyAdmin = (text) => sendMessage(ADMIN_CHAT_ID, text);

/* ------------------------------ Webhook mgmt ------------------------------ */

export function setWebhook(url, secret) {
  return call("setWebhook", {
    url,
    secret_token: secret || undefined,
    drop_pending_updates: false,
  });
}

export function deleteWebhook() {
  return call("deleteWebhook", { drop_pending_updates: false });
}

export function getWebhookInfo() {
  return call("getWebhookInfo");
}

export function getMe() {
  return call("getMe");
}

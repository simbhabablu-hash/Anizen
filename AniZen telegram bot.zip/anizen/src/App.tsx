import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence } from "framer-motion";
import { Bookmark } from "lucide-react";
import Navbar from "./components/Navbar";
import BottomTabs from "./components/BottomTabs";
import Hero from "./components/Hero";
import Section from "./components/Section";
import AnimeGrid from "./components/AnimeGrid";
import ScrollRow from "./components/ScrollRow";
import AnimeModal from "./components/AnimeModal";
import Footer from "./components/Footer";
import WatchPage from "./components/WatchPage";
import ContinueRow from "./components/ContinueRow";
import NewUpdates from "./components/NewUpdates";
import ScheduleView from "./components/ScheduleView";
import HistoryView from "./components/HistoryView";
import Library, { DEFAULT_LIB, type LibFilters } from "./components/Library";
import AdminPanel from "./components/admin/AdminPanel";
import Splash from "./components/Splash";
import Background3D from "./components/Background3D";
import Logo from "./components/Logo";
import PartyModal from "./components/PartyModal";
import PartyDock from "./components/PartyDock";
import { useWatchParty } from "./hooks/useWatchParty";
import { isFinished, progressOf, useWatchlist, type ContinueItem } from "./hooks/useWatchlist";
import { useAnimeStore } from "./store/AnimeStore";
import type { Anime } from "./types";

type View = "home" | "schedule" | "saved" | "history" | "library" | "watch";

export default function App() {
  const [view, setView] = useState<View>("home");
  const [prevView, setPrevView] = useState<View>("home");
  const [selected, setSelected] = useState<Anime | null>(null);
  const [watching, setWatching] = useState<Anime | null>(null);
  const [showAdmin, setShowAdmin] = useState(false);
  const [splash, setSplash] = useState(true);
  const [lib, setLib] = useState<LibFilters>(DEFAULT_LIB);
  const [watchEp, setWatchEp] = useState(1);
  const [partyOpen, setPartyOpen] = useState(false);
  const [partyPrefill, setPartyPrefill] = useState("");
  const deepHandled = useRef(false);
  const partyLinkHandled = useRef(false);

  const { animeList, allGenres, loading, cloudId } = useAnimeStore();
  const { list: myList, history, inList, toggle, touchHistory, recordProgress, removeHistory, clearHistory } =
    useWatchlist();

  // ---- Watch Party: it needs to know what we are watching, and be able to open an episode ----
  const animeListRef = useRef(animeList);
  animeListRef.current = animeList;
  const nowRef = useRef({ view, watching, watchEp });
  nowRef.current = { view, watching, watchEp };
  const openWatchRef = useRef<(a: Anime, ep?: number) => void>(() => {});

  const party = useWatchParty({
    onRemoteEpisode: (animeId, ep) => {
      const a = animeListRef.current.find((x) => x.id === animeId);
      if (!a) return false;
      openWatchRef.current(a, ep);
      return true;
    },
    getCurrent: () => {
      const s = nowRef.current;
      return s.view === "watch" && s.watching ? { animeId: s.watching.id, ep: s.watchEp } : null;
    },
  });

  /* ---------------- derived lists for the Home sections ---------------- */

  const byRating = useMemo(() => [...animeList].sort((a, b) => b.rating - a.rating), [animeList]);
  const latest = useMemo(() => [...animeList].sort((a, b) => b.createdAt - a.createdAt), [animeList]);
  const featured = useMemo(() => {
    const f = animeList.filter((a) => a.featured);
    return f.length ? f : byRating.slice(0, 6);
  }, [animeList, byRating]);

  const sections = useMemo(() => {
    const airing = byRating.filter((a) => a.status === "Ongoing");
    const picks = animeList.filter((a) => a.featured);
    const movies = byRating.filter((a) => a.type === "Movie");
    const completed = byRating.filter((a) => a.status === "Completed");
    const upcoming = animeList.filter((a) => a.status === "Upcoming");

    const counts = new Map<string, number>();
    animeList.forEach((a) => a.genres.forEach((g) => counts.set(g, (counts.get(g) ?? 0) + 1)));
    const topGenres = [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 2).map(([g]) => g);

    const rows: { key: string; title: string; subtitle?: string; items: Anime[]; preset?: Partial<LibFilters> }[] = [
      { key: "trending", title: "Trending Now", subtitle: "Sabse zyada rating wale", items: byRating.slice(0, 12), preset: { sort: "rating" } },
      { key: "airing", title: "Top Airing", subtitle: "Abhi chal rahe shows", items: airing.slice(0, 12), preset: { status: "Ongoing" } },
      { key: "picks", title: "Featured Picks", subtitle: "Hamari pasand", items: picks.slice(0, 12) },
      { key: "movies", title: "Movies", items: movies.slice(0, 12), preset: { type: "Movie" } },
      { key: "completed", title: "Completed Series", subtitle: "Poori series, binge karo", items: completed.slice(0, 12), preset: { status: "Completed" } },
      ...topGenres.map((g) => ({
        key: `g-${g}`,
        title: g,
        items: byRating.filter((a) => a.genres.includes(g)).slice(0, 12),
        preset: { genre: g } as Partial<LibFilters>,
      })),
      { key: "upcoming", title: "Coming Soon", items: upcoming.slice(0, 12), preset: { status: "Upcoming" } },
    ];
    return rows.filter((r) => r.items.length > 0);
  }, [animeList, byRating]);

  const topAiring = useMemo(() => {
    const airing = byRating.filter((a) => a.status === "Ongoing");
    return (airing.length ? airing : byRating).slice(0, 4);
  }, [byRating]);

  // Saved / History store raw copies or ids; remap to the resolved catalog items
  const byId = useMemo(() => new Map(animeList.map((a) => [a.id, a])), [animeList]);
  const savedResolved = useMemo(() => myList.map((m) => byId.get(m.id) ?? m), [myList, byId]);

  // "Continue Watching" = newest unfinished episode of each anime, from real history
  const continueList: ContinueItem[] = useMemo(() => {
    const seen = new Set<string>();
    const out: ContinueItem[] = [];
    const sorted = [...history].sort((a, b) => b.watchedAt - a.watchedAt);
    for (const h of sorted) {
      if (seen.has(h.animeId)) continue;
      seen.add(h.animeId); // only the latest episode of each anime counts
      const anime = byId.get(h.animeId);
      if (!anime || isFinished(h)) continue;
      out.push({ anime, episode: h.episode, progress: progressOf(h), updatedAt: h.watchedAt });
    }
    return out.slice(0, 12);
  }, [history, byId]);
  const continueMap = useMemo(() => new Map(continueList.map((c) => [c.anime.id, c])), [continueList]);

  /* ---------------- actions ---------------- */

  const openWatch = (anime: Anime, episode = 1) => {
    setPrevView(view === "watch" ? prevView : view);
    setWatching(anime);
    setWatchEp(episode);
    setView("watch");
  };
  openWatchRef.current = openWatch;

  // Resume position for an episode (History). In a Watch Party the room decides the position.
  const historyRef = useRef(history);
  historyRef.current = history;
  const inPartyRef = useRef(false);
  inPartyRef.current = !!party.room;
  const getResume = useCallback((animeId: string, ep: number) => {
    if (inPartyRef.current) return 0;
    const h = historyRef.current.find((x) => x.animeId === animeId && x.episode === ep);
    if (!h || h.duration <= 0) return 0;
    if (h.position < 5 || isFinished(h)) return 0;
    return h.position;
  }, []);

  // Invite link  ?party=CODE  -> open the join box with the code already typed in
  useEffect(() => {
    if (partyLinkHandled.current) return;
    partyLinkHandled.current = true;
    try {
      const c = new URLSearchParams(window.location.search).get("party");
      if (c) {
        setPartyPrefill(c);
        setPartyOpen(true);
      }
    } catch {
      /* ignore */
    }
  }, []);

  // Deep link: ?watch=<animeId>&ep=<n> (from Share buttons) opens that episode directly
  useEffect(() => {
    if (loading || deepHandled.current) return;
    deepHandled.current = true;
    try {
      const params = new URLSearchParams(window.location.search);
      const w = params.get("watch");
      if (w && animeList.length > 0) {
        const found = animeList.find((a) => a.id === w);
        if (found) {
          const ep = Math.max(1, parseInt(params.get("ep") || "1", 10) || 1);
          setPrevView("home");
          setWatching(found);
          setWatchEp(ep);
          setView("watch");
          setSplash(false);
        }
      }
    } catch {
      /* ignore bad URLs */
    }
  }, [loading, animeList]);

  const scrollTop = () => window.scrollTo({ top: 0, behavior: "smooth" });

  const navigate = (v: string) => {
    if (v === "library") setLib(DEFAULT_LIB);
    setView(v as View);
    scrollTop();
  };

  /** Open the Library already filtered (used by every "View All" and the search box). */
  const openLibrary = (preset: Partial<LibFilters> = {}) => {
    setLib({ ...DEFAULT_LIB, ...preset });
    setView("library");
    scrollTop();
  };

  const gridProps = {
    onSelect: setSelected,
    onWatch: openWatch,
    onToggleList: toggle,
    inListFn: inList,
  };

  if (splash) {
    return <Splash onDone={() => setSplash(false)} />;
  }

  if (showAdmin) {
    return <AdminPanel onExit={() => setShowAdmin(false)} />;
  }

  if (loading) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-[#0a0e1a]">
        <Logo className="text-3xl" />
        <div className="h-1 w-40 overflow-hidden rounded-full bg-white/10">
          <div className="h-full w-1/2 animate-[loadbar_1.1s_ease-in-out_infinite] rounded-full bg-cyan-400" />
        </div>
        <p className="text-sm text-slate-400">Loading your library...</p>
      </div>
    );
  }

  const activeNav = ["home", "schedule", "saved", "history", "library"].includes(view) ? view : "";

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white">
      <Background3D />
      <div className="relative z-10 pb-16 md:pb-0">
        <Navbar
          active={activeNav}
          onNavigate={navigate}
          onSearch={(q) => openLibrary({ q })}
          onAdmin={() => setShowAdmin(true)}
          onParty={() => setPartyOpen(true)}
          partyCode={party.room?.code}
          genres={allGenres}
          topAiring={topAiring}
          onPickGenre={(g) => openLibrary({ genre: g })}
          onPickAnime={setSelected}
        />

        {view === "watch" && watching && (
          <WatchPage
            anime={watching}
            onBack={() => navigate(prevView)}
            inList={inList(watching.id)}
            onToggleList={toggle}
            onWatch={(a, ep) => {
              touchHistory(a.id, ep);
              setWatchEp(ep);
              party.announceEpisode(a.id, ep);
            }}
            initialEpisode={watchEp}
            onVideoEl={party.attachVideo}
            onProgress={recordProgress}
            getResume={getResume}
          />
        )}

        {view === "home" && (
          <>
            <Hero
              items={featured}
              onSelect={setSelected}
              onWatch={openWatch}
              onAdmin={() => setShowAdmin(true)}
              isConnected={!!cloudId}
              continueMap={continueMap}
            />

            {continueList.length > 0 && (
              <Section title="Continue Watching" action={<ViewAllBtn onClick={() => navigate("history")} label="History" />}>
                <ContinueRow
                  items={continueList}
                  onResume={openWatch}
                  onRemove={(id) => removeHistory(id)}
                />
              </Section>
            )}

            {sections.map((s, i) => (
              <Section
                key={s.key}
                title={s.title}
                subtitle={s.subtitle}
                action={
                  <>
                    {i === 0 && <SavedPill count={myList.length} onClick={() => navigate("saved")} />}
                    {s.preset && <ViewAllBtn onClick={() => openLibrary(s.preset)} />}
                  </>
                }
              >
                <ScrollRow items={s.items} {...gridProps} />
              </Section>
            ))}

            {animeList.length > 0 && (
              <Section title="New Updates" action={<ViewAllBtn onClick={() => openLibrary({ sort: "new" })} />}>
                <NewUpdates items={latest.slice(0, 6)} onOpen={openWatch} />
              </Section>
            )}
          </>
        )}

        {view === "schedule" && <ScheduleView anime={animeList} onOpen={setSelected} onWatch={openWatch} />}

        {view === "saved" && (
          <Section title="Saved" subtitle={`${myList.length} anime saved`}>
            {myList.length === 0 ? (
              <div className="flex flex-col items-center gap-3 py-16 text-center text-slate-400">
                <Bookmark className="h-12 w-12" />
                <p className="text-lg font-semibold">Abhi kuch save nahi kiya</p>
                <p className="text-sm">Kisi bhi anime par + dabao, yahan aa jayega.</p>
                <button
                  onClick={() => navigate("library")}
                  className="mt-2 rounded-md bg-blue-600 px-6 py-2.5 text-sm font-bold uppercase tracking-wide text-white transition hover:bg-blue-500"
                >
                  Library kholo
                </button>
              </div>
            ) : (
              <AnimeGrid items={savedResolved} {...gridProps} />
            )}
          </Section>
        )}

        {view === "history" && (
          <HistoryView
            history={history}
            byId={byId}
            onResume={openWatch}
            onOpen={setSelected}
            onRemove={removeHistory}
            onClear={clearHistory}
          />
        )}

        {view === "library" && (
          <Library anime={animeList} genres={allGenres} filters={lib} onChange={setLib} {...gridProps} />
        )}

        <Footer onNavigate={navigate} />
      </div>

      <BottomTabs active={activeNav} onNavigate={navigate} savedCount={myList.length} />

      <AnimatePresence>
        {selected && (
          <AnimeModal
            anime={selected}
            onClose={() => setSelected(null)}
            onWatch={openWatch}
            onToggleList={toggle}
            inList={inList(selected.id)}
          />
        )}
      </AnimatePresence>

      <PartyDock party={party} onWatchPage={view === "watch"} />

      <AnimatePresence>
        {partyOpen && (
          <PartyModal
            party={party}
            prefillCode={partyPrefill}
            onClose={() => {
              setPartyOpen(false);
              setPartyPrefill("");
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function ViewAllBtn({ onClick, label = "View All" }: { onClick: () => void; label?: string }) {
  return (
    <button onClick={onClick} className="text-xs font-semibold text-cyan-400 transition hover:text-cyan-300">
      {label}
    </button>
  );
}

function SavedPill({ count, onClick }: { count: number; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-wider text-slate-300 transition hover:text-white"
    >
      Saved
      <span className="rounded bg-blue-600 px-1.5 py-0.5 text-[10px] leading-none text-white">{count}</span>
    </button>
  );
}

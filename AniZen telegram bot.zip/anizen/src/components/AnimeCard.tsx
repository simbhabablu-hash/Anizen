import { useState } from "react";
import { Star, Play, Plus, Check, Info, Share2 } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import type { Anime } from "../types";
import Tilt3D from "./Tilt3D";
import ShareSheet from "./ShareSheet";
import { watchLink } from "../utils/share";
import { isFresh } from "../utils/format";

interface Props {
  anime: Anime;
  onClick: (anime: Anime) => void;
  onWatch?: (anime: Anime) => void;
  onToggleList?: (anime: Anime) => void;
  inList?: boolean;
  index?: number;
  /** "large" shows a "TV · 12 eps" line instead of genres (Popular This Week) */
  variant?: "default" | "large";
}

export default function AnimeCard({
  anime,
  onClick,
  onWatch,
  onToggleList,
  inList,
  index = 0,
  variant = "default",
}: Props) {
  const [showShare, setShowShare] = useState(false);
  const img = anime.poster || anime.thumbnail || anime.banner;
  const title = anime.titleEnglish || anime.title;
  const fresh = isFresh(anime);
  const eps = anime.episodes?.length ?? 0;

  const subtitle =
    variant === "large"
      ? [anime.type, eps ? `${eps} eps` : "", anime.year ? String(anime.year) : ""].filter(Boolean).join(" · ")
      : anime.genres?.slice(0, 2).join(", ") || anime.type;

  const stop = (fn: () => void) => (e: React.MouseEvent) => {
    e.stopPropagation();
    fn();
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-30px" }}
      transition={{ duration: 0.5, delay: Math.min((index % 6) * 0.06, 0.3), ease: [0.22, 1, 0.36, 1] }}
    >
      <Tilt3D className="group rounded-xl" max={5} scale={1.02} glare={false}>
        <div
          onClick={() => (onWatch || onClick)(anime)}
          className="relative cursor-pointer rounded-xl bg-[#0f1627]/80 p-2 ring-1 ring-white/[0.06] transition duration-300 group-hover:bg-[#131c32] group-hover:ring-cyan-400/40 group-hover:shadow-[0_18px_40px_-16px_rgba(34,211,238,0.35)]"
        >
          <div className="relative aspect-[3/4] overflow-hidden rounded-lg bg-slate-800">
            <img
              src={img}
              alt={anime.title}
              loading="lazy"
              className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />

            {anime.rating ? (
              <div className="absolute bottom-1.5 left-1.5 flex items-center gap-1 rounded-md bg-black/70 px-1.5 py-0.5 text-[11px] font-bold text-white backdrop-blur">
                <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
                {anime.rating.toFixed(1)}
              </div>
            ) : null}

            {/* hover play (desktop) */}
            <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-black/30 opacity-0 transition duration-300 group-hover:opacity-100">
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-600 shadow-xl shadow-blue-600/50">
                <Play className="h-5 w-5 translate-x-0.5 fill-white text-white" />
              </span>
            </div>

            {/* quick actions */}
            <div className="absolute right-1.5 top-1.5 flex flex-col gap-1.5 opacity-0 transition group-hover:opacity-100 [@media(hover:none)]:opacity-100">
              {onToggleList && (
                <button
                  onClick={stop(() => onToggleList(anime))}
                  title={inList ? "Remove from My List" : "Add to My List"}
                  className={`flex h-7 w-7 items-center justify-center rounded-full backdrop-blur transition ${
                    inList ? "bg-blue-600 text-white" : "bg-black/60 text-white ring-1 ring-white/20 hover:bg-black/80"
                  }`}
                >
                  {inList ? <Check className="h-3.5 w-3.5" /> : <Plus className="h-3.5 w-3.5" />}
                </button>
              )}
              <button
                onClick={stop(() => setShowShare(true))}
                title="Share"
                className="flex h-7 w-7 items-center justify-center rounded-full bg-black/60 text-white ring-1 ring-white/20 backdrop-blur transition hover:bg-black/80"
              >
                <Share2 className="h-3.5 w-3.5" />
              </button>
              <button
                onClick={stop(() => onClick(anime))}
                title="More info"
                className="flex h-7 w-7 items-center justify-center rounded-full bg-black/60 text-white ring-1 ring-white/20 backdrop-blur transition hover:bg-black/80"
              >
                <Info className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>

          <div className="px-0.5 pb-0.5 pt-2.5">
            <h3
              className={`truncate font-bold text-white transition-colors group-hover:text-cyan-300 ${
                variant === "large" ? "text-sm" : "text-[13px]"
              }`}
            >
              {title}
            </h3>
            <p className="mt-0.5 truncate text-[11px] text-slate-400">{subtitle}</p>
            {fresh && variant === "default" && (
              <span className="mt-1.5 inline-block rounded bg-blue-600 px-1.5 py-0.5 text-[10px] font-bold text-white">
                New EP
              </span>
            )}
          </div>
        </div>
      </Tilt3D>

      <AnimatePresence>
        {showShare && (
          <ShareSheet
            title={title}
            text={`Dekho "${title}" AniZen par! 🔥`}
            url={watchLink(anime.id)}
            onClose={() => setShowShare(false)}
          />
        )}
      </AnimatePresence>
    </motion.div>
  );
}

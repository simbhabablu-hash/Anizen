import AnimeCard from "./AnimeCard";
import type { Anime } from "../types";

export interface GridHandlers {
  onSelect: (a: Anime) => void;
  onWatch: (a: Anime) => void;
  onToggleList: (a: Anime) => void;
  inListFn: (id: string) => boolean;
}

export default function AnimeGrid({
  items,
  large,
  onSelect,
  onWatch,
  onToggleList,
  inListFn,
}: { items: Anime[]; large?: boolean } & GridHandlers) {
  return (
    <div
      className={
        large
          ? "grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-4"
          : "grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 md:grid-cols-4 lg:grid-cols-6"
      }
    >
      {items.map((a, i) => (
        <AnimeCard
          key={a.id}
          anime={a}
          index={i}
          variant={large ? "large" : "default"}
          onClick={onSelect}
          onWatch={onWatch}
          onToggleList={onToggleList}
          inList={inListFn(a.id)}
        />
      ))}
    </div>
  );
}

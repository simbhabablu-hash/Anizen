import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { X, Star, Calendar, Clapperboard, Play, Plus, Check, Building2, Share2 } from "lucide-react";
import type { Anime } from "../types";
import ShareSheet from "./ShareSheet";
import { watchLink } from "../utils/share";

interface Props {
  anime: Anime;
  onClose: () => void;
  onWatch?: (anime: Anime, episode?: number) => void;
  onToggleList?: (anime: Anime) => void;
  inList?: boolean;
}

export default function AnimeModal({ anime, onClose, onWatch, onToggleList, inList }: Props) {
  const [showShare, setShowShare] = useState(false);

  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "";
    };
  }, []);

  const banner = anime.banner || anime.thumbnail || anime.poster;
  const shareTitle = anime.titleEnglish || anime.title;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/80 p-0 backdrop-blur-sm sm:p-6"
    >
      <motion.div
        initial={{ opacity: 0, y: 40, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20 }}
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-4xl overflow-hidden rounded-none bg-slate-900 shadow-2xl ring-1 ring-white/10 sm:rounded-3xl"
      >
        <button
          onClick={onClose}
          className="absolute right-4 top-4 z-20 rounded-full bg-black/60 p-2 text-white backdrop-blur transition hover:bg-black/90"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="relative h-56 w-full overflow-hidden sm:h-72">
          <img src={banner} alt={anime.title} className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent" />
        </div>

        <div className="relative -mt-24 px-5 pb-8 sm:px-8">
          <div className="flex flex-col gap-5 sm:flex-row">
            <img
              src={anime.poster}
              alt={anime.title}
              className="h-52 w-36 shrink-0 rounded-xl object-cover shadow-xl ring-1 ring-white/10"
            />
            <div className="flex-1 pt-2 sm:pt-24">
              <h2 className="text-2xl font-black text-white sm:text-3xl">
                {anime.titleEnglish || anime.title}
              </h2>
              {anime.titleEnglish && anime.title !== anime.titleEnglish && (
                <p className="mt-1 text-sm text-slate-400">{anime.title}</p>
              )}
              <div className="mt-3 flex flex-wrap gap-2">
                {anime.genres?.map((g) => (
                  <span
                    key={g}
                    className="rounded-full bg-fuchsia-600/20 px-3 py-1 text-xs font-semibold text-fuchsia-300 ring-1 ring-fuchsia-500/30"
                  >
                    {g}
                  </span>
                ))}
              </div>

              <div className="mt-4 flex flex-wrap gap-2">
                {onWatch && (
                  <button
                    onClick={() => {
                      onWatch(anime);
                      onClose();
                    }}
                    className="flex items-center gap-2 rounded-full bg-fuchsia-600 px-6 py-2.5 text-sm font-bold text-white shadow-lg shadow-fuchsia-600/40 transition hover:bg-fuchsia-500"
                  >
                    <Play className="h-4 w-4 fill-white" /> Watch Now
                  </button>
                )}
                {onToggleList && (
                  <button
                    onClick={() => onToggleList(anime)}
                    className={`flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-bold transition ${
                      inList
                        ? "bg-white/15 text-white ring-1 ring-white/20"
                        : "bg-white/5 text-white ring-1 ring-white/15 hover:bg-white/10"
                    }`}
                  >
                    {inList ? <Check className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                    {inList ? "In My List" : "My List"}
                  </button>
                )}
                <button
                  onClick={() => setShowShare(true)}
                  className="flex items-center gap-2 rounded-full bg-white/5 px-5 py-2.5 text-sm font-bold text-white ring-1 ring-white/15 transition hover:bg-white/10"
                >
                  <Share2 className="h-4 w-4" /> Share
                </button>
              </div>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Stat icon={<Star className="mx-auto h-5 w-5 text-amber-400" />} value={anime.rating ? anime.rating.toFixed(1) : "N/A"} label="Rating" />
            <Stat icon={<Clapperboard className="mx-auto h-5 w-5 text-fuchsia-400" />} value={String(anime.episodes?.length ?? 0)} label="Episodes" />
            <Stat icon={<Calendar className="mx-auto h-5 w-5 text-sky-400" />} value={anime.year ? String(anime.year) : "N/A"} label="Year" />
            <Stat icon={<Building2 className="mx-auto h-5 w-5 text-emerald-400" />} value={anime.type} label="Type" />
          </div>

          <div className="mt-6 flex flex-wrap gap-x-6 gap-y-2 text-sm text-slate-300">
            <InfoItem label="Status" value={anime.status} />
            {anime.studio && <InfoItem label="Studio" value={anime.studio} />}
          </div>

          <div className="mt-6">
            <h3 className="mb-2 text-lg font-bold text-white">Synopsis</h3>
            <p className="text-sm leading-relaxed text-slate-300">
              {anime.synopsis || "No synopsis available."}
            </p>
          </div>

          {anime.episodes?.length > 0 && (
            <div className="mt-6">
              <h3 className="mb-3 text-lg font-bold text-white">Episodes</h3>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                {anime.episodes.map((ep) => (
                  <button
                    key={ep.id}
                    onClick={() => {
                      onWatch?.(anime, ep.number);
                      onClose();
                    }}
                    className="flex items-center gap-2 rounded-lg bg-white/5 p-2 text-left ring-1 ring-white/10 transition hover:bg-white/10"
                  >
                    <span className="flex h-8 w-10 shrink-0 items-center justify-center rounded bg-fuchsia-600/80 text-xs font-black text-white">
                      {ep.number}
                    </span>
                    <span className="min-w-0 flex-1 truncate text-xs font-semibold text-white">
                      {ep.title}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </motion.div>

      <AnimatePresence>
        {showShare && (
          <ShareSheet
            title={shareTitle}
            text={`Dekho "${shareTitle}" AniZen par! 🔥`}
            url={watchLink(anime.id)}
            onClose={() => setShowShare(false)}
          />
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function Stat({ icon, value, label }: { icon: React.ReactNode; value: string; label: string }) {
  return (
    <div className="rounded-xl bg-white/5 p-3 text-center ring-1 ring-white/10">
      {icon}
      <div className="mt-1 text-lg font-black text-white">{value}</div>
      <div className="text-[11px] uppercase tracking-wide text-slate-400">{label}</div>
    </div>
  );
}

function InfoItem({ label, value }: { label: string; value: string }) {
  return (
    <span>
      <span className="text-slate-500">{label}:</span>{" "}
      <span className="font-semibold text-white">{value}</span>
    </span>
  );
}

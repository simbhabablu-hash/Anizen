/** Quiet fixed backdrop: deep navy with two soft glows. Keeps posters as the focus. */
export default function Background3D() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
      <div className="absolute -top-48 left-1/4 h-[480px] w-[640px] rounded-full bg-cyan-500/[0.06] blur-[130px]" />
      <div className="absolute -right-48 top-1/2 h-[460px] w-[460px] rounded-full bg-blue-600/10 blur-[130px]" />
    </div>
  );
}

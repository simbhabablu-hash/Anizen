import { CalendarDays, Bookmark, History, LayoutGrid, House } from "lucide-react";

interface Props {
  active: string;
  onNavigate: (view: string) => void;
  savedCount: number;
}

const ITEMS = [
  { id: "home", label: "Home", Icon: House },
  { id: "schedule", label: "Schedule", Icon: CalendarDays },
  { id: "saved", label: "Saved", Icon: Bookmark },
  { id: "history", label: "History", Icon: History },
  { id: "library", label: "Library", Icon: LayoutGrid },
];

/** Phone navigation: Home · Schedule · Saved · History · Library (hidden on desktop). */
export default function BottomTabs({ active, onNavigate, savedCount }: Props) {
  return (
    <nav
      aria-label="Main"
      className="bottom-tabs fixed inset-x-0 bottom-0 z-50 border-t border-white/10 bg-[#0a0e1a]/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-xl md:hidden"
    >
      <ul className="mx-auto grid max-w-md grid-cols-5">
        {ITEMS.map(({ id, label, Icon }) => {
          const on = active === id;
          return (
            <li key={id}>
              <button
                onClick={() => onNavigate(id)}
                aria-current={on ? "page" : undefined}
                className={`relative flex w-full flex-col items-center gap-0.5 py-2.5 text-[10px] font-semibold transition-colors ${
                  on ? "text-cyan-400" : "text-slate-400 active:text-white"
                }`}
              >
                {on && <span className="absolute inset-x-5 top-0 h-[2px] rounded-full bg-cyan-400 shadow-[0_0_10px_#22d3ee]" />}
                <span className="relative">
                  <Icon className={`h-[22px] w-[22px] ${on ? "drop-shadow-[0_0_6px_rgba(34,211,238,0.7)]" : ""}`} />
                  {id === "saved" && savedCount > 0 && (
                    <span className="absolute -right-2.5 -top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-blue-600 px-1 text-[9px] font-bold leading-none text-white">
                      {savedCount > 99 ? "99+" : savedCount}
                    </span>
                  )}
                </span>
                {label}
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

import { Play, X } from "lucide-react";
import type { ContinueItem } from "../hooks/useWatchlist";
import type { Anime } from "../types";

interface Props {
  items: ContinueItem[];
  onResume: (a: Anime, episode: number) => void;
  onRemove: (id: string) => void;
}

export default function ContinueRow({ items, onResume, onRemove }: Props) {
  if (items.length === 0) return null;
  return (
    <div className="-mx-4 flex snap-x gap-3 overflow-x-auto px-4 pb-2 [scrollbar-width:none] sm:mx-0 sm:px-0 [&::-webkit-scrollbar]:hidden">
      {items.map((c) => {
        const img = c.anime.poster || c.anime.thumbnail || c.anime.banner;
        const pct = Math.round(c.progress * 100);
        const title = c.anime.titleEnglish || c.anime.title;
        return (
          <div
            key={c.anime.id}
            onClick={() => onResume(c.anime, c.episode)}
            className="group w-[8.5rem] shrink-0 cursor-pointer snap-start rounded-xl bg-[#0f1627]/80 p-2 ring-1 ring-white/[0.06] transition hover:bg-[#131c32] hover:ring-cyan-400/40 sm:w-40"
          >
            <div className="relative aspect-[4/5] overflow-hidden rounded-lg bg-slate-800">
              <img
                src={img}
                alt={title}
                loading="lazy"
                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

              <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-black/30 opacity-0 transition group-hover:opacity-100">
                <span className="flex h-11 w-11 items-center justify-center rounded-full bg-blue-600 shadow-xl shadow-blue-600/40">
                  <Play className="h-5 w-5 translate-x-0.5 fill-white text-white" />
                </span>
              </div>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onRemove(c.anime.id);
                }}
                title="Remove"
                className="absolute left-1.5 top-1.5 flex h-6 w-6 items-center justify-center rounded-full bg-black/70 text-white opacity-0 transition hover:bg-black group-hover:opacity-100 [@media(hover:none)]:opacity-100"
              >
                <X className="h-3 w-3" />
              </button>

              <span className="absolute bottom-1.5 right-1.5 rounded-md bg-black/75 px-2 py-0.5 text-[10px] font-bold text-white backdrop-blur">
                EP {c.episode}
              </span>
            </div>

            <div className="px-0.5 pt-2">
              <div className="flex items-center justify-between gap-2">
                <p className="truncate text-[12px] font-bold text-white">{title}</p>
                <span className="shrink-0 text-[11px] font-semibold text-slate-300">{pct}%</span>
              </div>
              <div className="mt-1.5 h-1 w-full overflow-hidden rounded-full bg-white/15">
                <div className="h-full rounded-full bg-cyan-400" style={{ width: `${Math.max(4, pct)}%` }} />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

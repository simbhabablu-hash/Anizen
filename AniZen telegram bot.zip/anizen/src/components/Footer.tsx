import { useState } from "react";
import { Bot, Check, Send, Share2 } from "lucide-react";
import Logo from "./Logo";
import { catalogLink, copyText, nativeShare } from "../utils/share";
import { INSTAGRAM_URL, INSTAGRAM_USER, TELEGRAM_BOT_URL, TELEGRAM_URL, TELEGRAM_USER } from "../social";

interface Props {
  onNavigate: (view: string) => void;
}

function InstagramIcon({ className = "h-[18px] w-[18px]" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden
    >
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
    </svg>
  );
}

const navLinks = [
  { id: "home", label: "Home" },
  { id: "schedule", label: "Schedule" },
  { id: "saved", label: "Saved" },
  { id: "history", label: "History" },
  { id: "library", label: "Library" },
];

export default function Footer({ onNavigate }: Props) {
  const [copied, setCopied] = useState(false);

  const doShare = async () => {
    const url = catalogLink();
    const r = await nativeShare("AniZen", "AniZen par anime dekho! 🔥", url);
    if (r === "unsupported") {
      if (await copyText(url)) {
        setCopied(true);
        setTimeout(() => setCopied(false), 1800);
      } else {
        window.prompt("Copy this link:", url);
      }
    }
  };

  const iconBtn =
    "flex h-9 w-9 items-center justify-center rounded-full text-slate-400 transition hover:bg-white/10 hover:text-cyan-400";

  return (
    <footer className="relative z-10 mt-12 border-t border-white/5 bg-[#080c17]/80 backdrop-blur-xl">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <div className="flex flex-col items-center gap-6 md:flex-row md:justify-between">
          <button onClick={() => onNavigate("home")} aria-label="AniZen home">
            <Logo className="text-xl" />
          </button>

          <nav className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-[13px] text-slate-400">
            {navLinks.map((l) => (
              <button key={l.id} onClick={() => onNavigate(l.id)} className="transition hover:text-white">
                {l.label}
              </button>
            ))}
            <a href={TELEGRAM_URL} target="_blank" rel="noreferrer" className="transition hover:text-white">
              Contact
            </a>
          </nav>

          <div className="flex items-center gap-1">
            <a
              href={TELEGRAM_URL}
              target="_blank"
              rel="noreferrer"
              title={`Telegram @${TELEGRAM_USER}`}
              aria-label="Telegram"
              className={iconBtn}
            >
              <Send className="h-[18px] w-[18px] -translate-x-px translate-y-px" />
            </a>
            {TELEGRAM_BOT_URL && (
              <a
                href={TELEGRAM_BOT_URL}
                target="_blank"
                rel="noreferrer"
                title="AniZen Telegram Bot"
                aria-label="Telegram bot"
                className={iconBtn}
              >
                <Bot className="h-[18px] w-[18px]" />
              </a>
            )}
            <a
              href={INSTAGRAM_URL}
              target="_blank"
              rel="noreferrer"
              title={`Instagram ${INSTAGRAM_USER}`}
              aria-label="Instagram"
              className={iconBtn}
            >
              <InstagramIcon />
            </a>
            <button onClick={doShare} title="Share AniZen" aria-label="Share" className={iconBtn}>
              {copied ? <Check className="h-[18px] w-[18px] text-emerald-400" /> : <Share2 className="h-[18px] w-[18px]" />}
            </button>
          </div>
        </div>

        {copied && <p className="mt-3 text-center text-xs font-semibold text-emerald-400">Link copied! ✅</p>}

        <div className="mt-6 flex flex-col items-center justify-between gap-1 border-t border-white/5 pt-5 text-xs text-slate-500 sm:flex-row">
          <p>© {new Date().getFullYear()} AniZen. All Rights Reserved.</p>
          <p>
            Designed &amp; Developed with <span className="text-rose-500">❤️</span> by{" "}
            <span className="font-semibold text-cyan-400">Balvir Coder</span> 👑
          </p>
        </div>
      </div>
    </footer>
  );
}

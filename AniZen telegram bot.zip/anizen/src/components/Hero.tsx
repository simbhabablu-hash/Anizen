import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronLeft, ChevronRight, Shield, Sparkles } from "lucide-react";
import type { Anime } from "../types";
import type { ContinueItem } from "../hooks/useWatchlist";
import { lastEpisodeNumber, statusLabel } from "../utils/format";

interface Props {
  items: Anime[];
  onSelect: (anime: Anime) => void;
  onWatch: (anime: Anime, episode?: number) => void;
  onAdmin?: () => void;
  isConnected?: boolean;
  continueMap?: Map<string, ContinueItem>;
}

export default function Hero({ items, onSelect, onWatch, onAdmin, isConnected, continueMap }: Props) {
  const [idx, setIdx] = useState(0);
  const [paused, setPaused] = useState(false);
  const slides = items.slice(0, 6);

  useEffect(() => {
    if (slides.length <= 1 || paused) return;
    const t = setInterval(() => setIdx((i) => (i + 1) % slides.length), 7000);
    return () => clearInterval(t);
  }, [slides.length, paused]);

  if (slides.length === 0) {
    return (
      <section className="relative z-10 flex min-h-[460px] items-center justify-center overflow-hidden px-6 py-16">
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute left-1/2 top-1/2 h-[480px] w-[480px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-cyan-500/15 blur-3xl" />
          <div className="absolute left-1/3 top-1/4 h-64 w-64 rounded-full bg-blue-600/15 blur-3xl" />
        </div>
        <div className="relative max-w-xl space-y-5 text-center">
          <span className="inline-flex items-center gap-2 rounded-full bg-cyan-500/10 px-3 py-1 text-xs font-bold uppercase tracking-wider text-cyan-300 ring-1 ring-cyan-400/30">
            <Sparkles className="h-3.5 w-3.5" /> Fresh install
          </span>
          <h1 className="text-4xl font-extrabold text-white sm:text-5xl">
            Welcome to ANI<span className="text-cyan-400">Z</span>EN
          </h1>
          <p className="text-base text-slate-300">
            Your library is empty right now. Open the Admin Panel to upload your first anime
            {isConnected ? " — it will sync to every phone instantly." : " and save it on this device."}
          </p>
          {onAdmin && (
            <button
              onClick={onAdmin}
              className="group inline-flex items-center gap-2 rounded-md bg-blue-600 px-6 py-3 text-sm font-bold uppercase tracking-wide text-white shadow-xl shadow-blue-600/30 transition hover:bg-blue-500"
            >
              <Shield className="h-4 w-4 transition group-hover:rotate-12" /> Open Admin Panel
            </button>
          )}
          {!isConnected && (
            <p className="mx-auto mt-2 max-w-md rounded-xl bg-amber-500/10 px-4 py-3 text-xs leading-relaxed text-amber-200 ring-1 ring-amber-500/20">
              ⚠️ Online database is <b>off</b>. Anime you add will only show on this browser. Enable it from Admin
              Panel → <b>Data Safety &amp; Sharing</b>.
            </p>
          )}
        </div>
      </section>
    );
  }

  const safe = idx % slides.length;
  const anime = slides[safe];
  const bg = anime.banner || anime.thumbnail || anime.poster;
  const go = (d: number) => setIdx((i) => (i + d + slides.length) % slides.length);

  const cont = continueMap?.get(anime.id);
  const epNow = cont?.episode ?? lastEpisodeNumber(anime);
  const pct = cont ? Math.round(cont.progress * 100) : null;
  const epCount = anime.episodes?.length ?? 0;

  const others = slides.map((s, i) => ({ s, i })).filter(({ i }) => i !== safe).slice(0, 3);

  const metaParts: string[] = [statusLabel(anime.status)];
  if (anime.rating) metaParts.push(`Rating: ${anime.rating.toFixed(1)} ★`);
  if (anime.genres?.length) metaParts.push(anime.genres.slice(0, 3).join(", "));
  if (anime.type) metaParts.push(anime.type);

  return (
    <section
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      className="relative z-10 h-[400px] w-full overflow-hidden sm:h-[440px] lg:h-[500px]"
    >
      <AnimatePresence>
        <motion.img
          key={anime.id}
          src={bg}
          alt={anime.title}
          initial={{ opacity: 0, scale: 1.08 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.1, ease: "easeOut" }}
          className="absolute inset-0 h-full w-full object-cover object-[center_20%]"
        />
      </AnimatePresence>

      <div className="absolute inset-0 bg-gradient-to-r from-[#0a0e1a]/90 via-[#0a0e1a]/35 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-t from-[#0a0e1a] via-transparent to-[#0a0e1a]/30" />

      {/* Arrows */}
      {slides.length > 1 && (
        <>
          <button
            onClick={() => go(-1)}
            aria-label="Previous"
            className="absolute left-2 top-1/2 z-20 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full border border-white/25 bg-black/40 text-white backdrop-blur transition hover:bg-black/70 sm:left-4 sm:h-10 sm:w-10"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <button
            onClick={() => go(1)}
            aria-label="Next"
            className="absolute right-2 top-1/2 z-20 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full border border-white/25 bg-black/40 text-white backdrop-blur transition hover:bg-black/70 sm:right-4 sm:h-10 sm:w-10"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </>
      )}

      <div className="relative z-10 mx-auto flex h-full max-w-7xl items-end justify-between gap-6 px-12 pb-10 sm:px-16 sm:pb-12">
        <AnimatePresence mode="wait">
          <motion.div
            key={anime.id}
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className="max-w-xl"
          >
            <h1 className="text-2xl font-extrabold uppercase leading-tight tracking-wide text-white drop-shadow-[0_4px_24px_rgba(0,0,0,0.6)] sm:text-4xl lg:text-[44px]">
              {anime.titleEnglish || anime.title}
            </h1>

            <p className="mt-2 flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-slate-300 sm:text-[13px]">
              {metaParts.map((m, i) => (
                <span key={i} className="flex items-center gap-2">
                  {i > 0 && <span className="text-slate-500">|</span>}
                  {m}
                </span>
              ))}
            </p>

            <div className="mt-4 flex flex-wrap gap-3">
              <button
                onClick={() => onWatch(anime, cont?.episode)}
                className="rounded-md bg-blue-600 px-6 py-2.5 text-[13px] font-bold uppercase tracking-wide text-white shadow-lg shadow-blue-600/30 transition hover:bg-blue-500 active:scale-95"
              >
                {cont ? "Resume" : "Watch Now"}
              </button>
              <button
                onClick={() => onSelect(anime)}
                className="rounded-md border border-white/60 bg-black/20 px-6 py-2.5 text-[13px] font-bold uppercase tracking-wide text-white backdrop-blur transition hover:bg-white/15 active:scale-95"
              >
                Details
              </button>
            </div>

            <div className="mt-5 w-full max-w-[22rem]">
              <div className="mb-1.5 flex items-center justify-between text-[11px] font-semibold text-slate-200 sm:text-xs">
                <span>
                  {cont ? `EP ${epNow} (Sub/Dub)` : epCount ? `${epCount} Episode${epCount > 1 ? "s" : ""} (Sub/Dub)` : "Sub/Dub"}
                </span>
                {pct !== null && <span>{pct}%</span>}
              </div>
              {pct !== null && (
                <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/20">
                  <div className="h-full rounded-full bg-blue-500" style={{ width: `${pct}%` }} />
                </div>
              )}
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Next-up thumbnails */}
        {others.length > 0 && (
          <div className="hidden shrink-0 items-end gap-2.5 sm:flex">
            {others.map(({ s, i }) => (
              <button
                key={s.id}
                onClick={() => setIdx(i)}
                title={s.titleEnglish || s.title}
                className="relative h-[68px] w-[118px] overflow-hidden rounded-lg ring-2 ring-white/15 transition hover:ring-cyan-400/70"
              >
                <img src={s.thumbnail || s.banner || s.poster} alt={s.title} className="h-full w-full object-cover" />
                <span className="absolute inset-0 bg-black/20 transition hover:bg-transparent" />
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Dots (mobile) */}
      {slides.length > 1 && (
        <div className="absolute bottom-3 left-1/2 z-20 flex -translate-x-1/2 gap-1.5 sm:hidden">
          {slides.map((_, i) => (
            <button
              key={i}
              onClick={() => setIdx(i)}
              aria-label={`Slide ${i + 1}`}
              className={`h-1.5 rounded-full transition-all ${i === safe ? "w-6 bg-cyan-400" : "w-1.5 bg-white/40"}`}
            />
          ))}
        </div>
      )}
    </section>
  );
}

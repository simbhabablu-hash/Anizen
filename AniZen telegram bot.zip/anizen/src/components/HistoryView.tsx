import { useMemo } from "react";
import { Clock, Play, Trash2, X, CheckCircle2 } from "lucide-react";
import Section from "./Section";
import type { Anime } from "../types";
import { isFinished, progressOf, type HistoryItem } from "../hooks/useWatchlist";
import { clock, dayGroup, timeAgo } from "../utils/format";

interface Props {
  history: HistoryItem[];
  byId: Map<string, Anime>;
  onResume: (a: Anime, ep: number) => void;
  onOpen: (a: Anime) => void;
  onRemove: (animeId: string, episode: number) => void;
  onClear: () => void;
}

const ORDER = ["Today", "Yesterday", "This week", "Earlier"];

export default function HistoryView({ history, byId, onResume, onOpen, onRemove, onClear }: Props) {
  // entries whose anime was deleted from the catalog are simply not shown
  const rows = useMemo(
    () => history.filter((h) => byId.has(h.animeId)).sort((a, b) => b.watchedAt - a.watchedAt),
    [history, byId],
  );

  const groups = useMemo(() => {
    const m = new Map<string, HistoryItem[]>();
    for (const r of rows) {
      const g = dayGroup(r.watchedAt);
      m.set(g, [...(m.get(g) ?? []), r]);
    }
    return ORDER.filter((g) => m.has(g)).map((g) => ({ name: g, items: m.get(g)! }));
  }, [rows]);

  return (
    <Section
      title="History"
      subtitle={rows.length ? `${rows.length} episodes dekhe` : undefined}
      action={
        rows.length > 0 ? (
          <button
            onClick={() => {
              if (confirm("Poori watch history delete kar dun?")) onClear();
            }}
            className="flex items-center gap-1.5 text-xs font-semibold text-rose-300 transition hover:text-rose-200"
          >
            <Trash2 className="h-3.5 w-3.5" /> Clear all
          </button>
        ) : undefined
      }
    >
      {rows.length === 0 ? (
        <div className="flex flex-col items-center gap-3 py-16 text-center text-slate-400">
          <Clock className="h-12 w-12" />
          <p className="text-lg font-semibold">Abhi koi history nahi</p>
          <p className="max-w-xs text-sm">Jo bhi episode dekhoge yahan aa jayega, aur wahin se resume kar paoge.</p>
        </div>
      ) : (
        <div className="space-y-7">
          {groups.map((g) => (
            <div key={g.name}>
              <h3 className="mb-3 text-[11px] font-bold uppercase tracking-[0.2em] text-slate-500">{g.name}</h3>
              <div className="space-y-2.5">
                {g.items.map((h) => {
                  const a = byId.get(h.animeId)!;
                  const ep = a.episodes?.find((e) => e.number === h.episode);
                  const done = isFinished(h);
                  const pct = Math.round(progressOf(h) * 100);
                  const img = a.thumbnail || a.banner || a.poster;
                  const known = h.duration > 0;
                  return (
                    <div
                      key={`${h.animeId}:${h.episode}`}
                      className="group flex items-center gap-3 rounded-xl bg-[#0f1627]/70 p-2.5 ring-1 ring-white/[0.06] transition hover:bg-[#131c32] hover:ring-cyan-400/30"
                    >
                      <button onClick={() => onResume(a, h.episode)} className="relative h-16 w-28 shrink-0 overflow-hidden rounded-lg bg-slate-800 sm:h-[4.5rem] sm:w-32">
                        <img src={img} alt="" loading="lazy" className="h-full w-full object-cover" />
                        <span className="absolute inset-0 flex items-center justify-center bg-black/30 opacity-0 transition group-hover:opacity-100">
                          <Play className="h-6 w-6 fill-white text-white" />
                        </span>
                        {known && !done && (
                          <span className="absolute inset-x-0 bottom-0 h-1 bg-white/25">
                            <span className="block h-full bg-cyan-400" style={{ width: `${Math.max(3, pct)}%` }} />
                          </span>
                        )}
                      </button>

                      <button onClick={() => onOpen(a)} className="min-w-0 flex-1 text-left">
                        <p className="truncate text-[13px] font-bold text-white">{a.titleEnglish || a.title}</p>
                        <p className="truncate text-[11px] text-slate-400">
                          EP {h.episode}
                          {ep?.title && ep.title !== `Episode ${h.episode}` ? ` · ${ep.title}` : ""}
                        </p>
                        <p className="mt-0.5 flex items-center gap-1.5 text-[11px] text-slate-500">
                          {done ? (
                            <span className="flex items-center gap-1 font-semibold text-emerald-400">
                              <CheckCircle2 className="h-3 w-3" /> Poora dekha
                            </span>
                          ) : known ? (
                            <span>
                              {clock(h.position)} / {clock(h.duration)} · {pct}%
                            </span>
                          ) : (
                            <span>Dekha</span>
                          )}
                          <span>· {timeAgo(h.watchedAt)}</span>
                        </p>
                      </button>

                      <button
                        onClick={() => onResume(a, h.episode)}
                        className="hidden shrink-0 rounded-md bg-blue-600 px-3.5 py-2 text-[11px] font-bold uppercase tracking-wide text-white transition hover:bg-blue-500 sm:block"
                      >
                        {done ? "Rewatch" : known ? "Resume" : "Watch"}
                      </button>
                      <button
                        onClick={() => onRemove(h.animeId, h.episode)}
                        title="History se hatao"
                        aria-label="Remove from history"
                        className="shrink-0 rounded-full p-2 text-slate-500 transition hover:bg-white/10 hover:text-white"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </Section>
  );
}

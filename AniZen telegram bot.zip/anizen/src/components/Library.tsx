import { useMemo } from "react";
import { Search, X, SearchX, RotateCcw } from "lucide-react";
import Section from "./Section";
import AnimeGrid, { type GridHandlers } from "./AnimeGrid";
import type { Anime } from "../types";

export interface LibFilters {
  q: string;
  type: string; // "all" or a type
  status: string; // "all" | Ongoing | Completed | Upcoming
  genre: string; // "all" or a genre
  sort: "rating" | "new" | "az" | "episodes";
}

export const DEFAULT_LIB: LibFilters = { q: "", type: "all", status: "all", genre: "all", sort: "rating" };

const TYPES = ["all", "TV", "Movie", "OVA", "ONA", "Special"];
const STATUSES = ["all", "Ongoing", "Completed", "Upcoming"];

interface Props extends GridHandlers {
  anime: Anime[];
  genres: string[];
  filters: LibFilters;
  onChange: (f: LibFilters) => void;
}

export default function Library({ anime, genres, filters, onChange, ...handlers }: Props) {
  const set = <K extends keyof LibFilters>(k: K, v: LibFilters[K]) => onChange({ ...filters, [k]: v });

  const results = useMemo(() => {
    const q = filters.q.trim().toLowerCase();
    let out = anime.filter((a) => {
      if (filters.type !== "all" && a.type !== filters.type) return false;
      if (filters.status !== "all" && a.status !== filters.status) return false;
      if (filters.genre !== "all" && !a.genres.includes(filters.genre)) return false;
      if (q) {
        const hay = `${a.title} ${a.titleEnglish || ""} ${a.studio || ""} ${a.genres.join(" ")}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
    out = [...out].sort((a, b) => {
      switch (filters.sort) {
        case "new":
          return b.createdAt - a.createdAt;
        case "az":
          return (a.titleEnglish || a.title).localeCompare(b.titleEnglish || b.title);
        case "episodes":
          return (b.episodes?.length ?? 0) - (a.episodes?.length ?? 0);
        default:
          return b.rating - a.rating;
      }
    });
    return out;
  }, [anime, filters]);

  const active =
    filters.q || filters.type !== "all" || filters.status !== "all" || filters.genre !== "all" || filters.sort !== "rating";

  const chip = (on: boolean) =>
    `shrink-0 rounded-full px-3.5 py-1.5 text-[12px] font-semibold transition ${
      on
        ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30"
        : "bg-white/[0.06] text-slate-300 ring-1 ring-white/10 hover:bg-white/10 hover:text-white"
    }`;
  const selectCls =
    "rounded-lg border border-white/10 bg-[#0f1627] px-3 py-2 text-[13px] text-white outline-none focus:border-cyan-400/50";

  return (
    <Section title="Library" subtitle={`${results.length} of ${anime.length} titles`}>
      {/* filters */}
      <div className="mb-6 space-y-3 rounded-2xl bg-[#0f1627]/70 p-3 ring-1 ring-white/[0.06] sm:p-4">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            value={filters.q}
            onChange={(e) => set("q", e.target.value)}
            placeholder="Library me dhundo — naam, studio, genre..."
            className="w-full rounded-full border border-white/10 bg-white/[0.06] py-2.5 pl-10 pr-10 text-sm text-white placeholder-slate-500 outline-none focus:border-cyan-400/50"
          />
          {filters.q && (
            <button
              onClick={() => set("q", "")}
              aria-label="Clear search"
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        <div className="flex gap-2 overflow-x-auto pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {TYPES.map((t) => (
            <button key={t} onClick={() => set("type", t)} className={chip(filters.type === t)}>
              {t === "all" ? "All types" : t}
            </button>
          ))}
        </div>

        <div className="flex gap-2 overflow-x-auto pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {STATUSES.map((s) => (
            <button key={s} onClick={() => set("status", s)} className={chip(filters.status === s)}>
              {s === "all" ? "Any status" : s === "Ongoing" ? "Airing" : s}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select value={filters.genre} onChange={(e) => set("genre", e.target.value)} className={selectCls} aria-label="Genre">
            <option value="all">All genres</option>
            {genres.map((g) => (
              <option key={g} value={g}>
                {g}
              </option>
            ))}
          </select>
          <select
            value={filters.sort}
            onChange={(e) => set("sort", e.target.value as LibFilters["sort"])}
            className={selectCls}
            aria-label="Sort"
          >
            <option value="rating">Top rated</option>
            <option value="new">Newest first</option>
            <option value="az">A → Z</option>
            <option value="episodes">Most episodes</option>
          </select>
          {active && (
            <button
              onClick={() => onChange(DEFAULT_LIB)}
              className="ml-auto flex items-center gap-1.5 rounded-lg px-3 py-2 text-[12px] font-semibold text-cyan-400 hover:bg-white/5"
            >
              <RotateCcw className="h-3.5 w-3.5" /> Reset
            </button>
          )}
        </div>
      </div>

      {results.length === 0 ? (
        <div className="flex flex-col items-center gap-3 py-16 text-center text-slate-400">
          <SearchX className="h-12 w-12" />
          <p className="text-lg font-semibold">Kuch nahi mila</p>
          <p className="text-sm">Filter badal ke ya Reset karke dekho.</p>
        </div>
      ) : (
        <AnimeGrid items={results} {...handlers} />
      )}
    </Section>
  );
}

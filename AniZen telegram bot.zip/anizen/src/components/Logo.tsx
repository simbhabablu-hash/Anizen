/** ANIZEN wordmark — the Z is highlighted in cyan like the brand mockup. */
export default function Logo({ className = "text-2xl" }: { className?: string }) {
  return (
    <span className={`font-extrabold uppercase leading-none tracking-[0.06em] text-white ${className}`}>
      ANI
      <span className="text-cyan-400 drop-shadow-[0_0_10px_rgba(34,211,238,0.75)]">Z</span>
      EN
    </span>
  );
}

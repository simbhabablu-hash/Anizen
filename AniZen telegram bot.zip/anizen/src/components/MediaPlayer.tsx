import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type Hls from "hls.js";
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  SkipBack,
  SkipForward,
  Settings,
  Loader2,
  PictureInPicture2,
  Gauge,
  AlertTriangle,
  RefreshCw,
  ExternalLink,
  RotateCw,
  Signal,
} from "lucide-react";
import type { QualityLink } from "../types";

interface Props {
  src: string;
  poster?: string;
  title?: string;
  /** Source is a web page / embed host (not a direct video file) */
  embed?: boolean;
  /** Extra resolutions for the same episode */
  qualities?: QualityLink[];
  /** Gives the <video> element to outside code (Watch Party sync). Must be a stable function. */
  onVideoEl?: (el: HTMLVideoElement | null) => void;
  /** Real watch progress (seconds) for History. Called every few seconds, on pause, end and exit. */
  onProgress?: (position: number, duration: number) => void;
  /** Start playing from this many seconds (resume). Only used when the player first opens. */
  startAt?: number;
  onEnded?: () => void;
  onError?: () => void;
}

const SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];
const QKEY = "aniverse:quality";

/* ------------------------------ small helpers ------------------------------ */

function fmt(t: number): string {
  if (!isFinite(t) || t < 0) return "0:00";
  const h = Math.floor(t / 3600);
  const m = Math.floor((t % 3600) / 60);
  const s = Math.floor(t % 60);
  return h > 0
    ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`
    : `${m}:${String(s).padStart(2, "0")}`;
}

function detectKind(src: string): "youtube" | "vimeo" | "video" {
  const u = src.toLowerCase();
  if (/youtube\.com|youtu\.be/.test(u)) return "youtube";
  if (/vimeo\.com/.test(u)) return "vimeo";
  return "video";
}

function toYouTubeEmbed(url: string): string {
  const m = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/shorts\/)([\w-]{11})/);
  if (!m) return url;
  return `https://www.youtube.com/embed/${m[1]}?rel=0&modestbranding=1&playsinline=1`;
}

function toVimeoEmbed(url: string): string {
  const m = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
  if (!m) return url;
  return `https://player.vimeo.com/video/${m[1]}?title=0&byline=0&portrait=0`;
}

const isHlsUrl = (u: string) => /\.m3u8(\?|#|$)/i.test(u);

/**
 * hls.js is ~500KB, so it is NOT bundled into the site. It is fetched from a CDN only when a
 * viewer actually plays an .m3u8 stream. (The npm package is only used for TypeScript types.)
 */
let hlsPromise: Promise<typeof Hls> | null = null;
function loadHls(): Promise<typeof Hls> {
  const w = window as unknown as { Hls?: typeof Hls };
  if (w.Hls) return Promise.resolve(w.Hls);
  if (!hlsPromise) {
    hlsPromise = new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = "https://cdn.jsdelivr.net/npm/hls.js@1.7.3/dist/hls.min.js";
      s.async = true;
      s.onload = () => (w.Hls ? resolve(w.Hls) : reject(new Error("hls missing")));
      s.onerror = () => {
        hlsPromise = null; // allow a retry
        reject(new Error("hls load failed"));
      };
      document.head.appendChild(s);
    });
  }
  return hlsPromise;
}

interface FsDoc {
  webkitFullscreenElement?: Element | null;
  webkitExitFullscreen?: () => void;
}
interface FsEl {
  webkitRequestFullscreen?: () => void;
}
interface VideoFsEl {
  webkitEnterFullscreen?: () => void;
}
interface OrientationApi {
  lock?: (o: string) => Promise<void>;
  unlock?: () => void;
  type?: string;
}
const orient = (): OrientationApi | undefined =>
  (screen as unknown as { orientation?: OrientationApi }).orientation;
const fsElement = (): Element | null =>
  document.fullscreenElement || (document as unknown as FsDoc).webkitFullscreenElement || null;

/* ------------------------------ quality ------------------------------ */

interface Opt {
  id: string;
  label: string;
  url: string;
  /** vertical resolution, used for sorting. Original is treated as "highest". */
  h: number;
}

/**
 * Cloudinary can serve the same video at another size just by changing the URL.
 * Also forces .mp4 so phone videos (.mov / HEVC) are delivered as widely playable H.264.
 */
function cloudinaryVariant(url: string, h: number): string | null {
  const m = url.match(/^(https?:\/\/res\.cloudinary\.com\/[^/]+\/video\/upload\/)(.*)$/);
  if (!m) return null;
  const rest = m[2];
  const q = rest.match(/(\?.*)$/)?.[1] || "";
  const path = rest.replace(/\.[a-z0-9]+$/i, "");
  return `${m[1]}q_auto,h_${h},c_limit/${path}.mp4${q}`;
}

function buildOptions(src: string, manual?: QualityLink[]): Opt[] {
  const out: Opt[] = [];
  const clean = (manual || []).filter((q) => q && q.url && /^https?:\/\//i.test(q.url));
  if (clean.length) {
    for (const q of clean) out.push({ id: q.label, label: q.label, url: q.url, h: parseInt(q.label, 10) || 0 });
    if (!out.some((o) => o.url === src)) out.push({ id: "original", label: "Original", url: src, h: 99999 });
  } else {
    out.push({ id: "original", label: "Original", url: src, h: 99999 });
    if (cloudinaryVariant(src, 720)) {
      for (const h of [1080, 720, 480, 360]) {
        out.push({ id: `${h}p`, label: `${h}p`, url: cloudinaryVariant(src, h) as string, h });
      }
    }
  }
  return out.sort((a, b) => b.h - a.h);
}

interface NetInfo {
  saveData?: boolean;
  effectiveType?: string;
}

/** "Auto": pick by connection. Slow/data-saver -> lowest, 3g -> about 480p, otherwise best/original. */
function pickAuto(options: Opt[]): Opt {
  if (options.length < 2) return options[0];
  const c = (navigator as unknown as { connection?: NetInfo }).connection;
  const type = c?.effectiveType || "";
  const slow = !!c?.saveData || /(^|-)2g$/.test(type);
  if (slow) return options[options.length - 1];
  if (type === "3g") return options.find((o) => o.h <= 480) ?? options[options.length - 1];
  return options[0];
}

function pickInitial(options: Opt[], pref: string): Opt {
  if (pref !== "auto") {
    const hit = options.find((o) => o.id === pref);
    if (hit) return hit;
  }
  return pickAuto(options);
}

/* ------------------------------ errors ------------------------------ */

const CODEC_TEXT =
  "Is video ki picture decode nahi ho rahi (sirf awaaz ya kaali screen). Aksar H.265/HEVC codec ki wajah se hota hai. Video ko H.264 MP4 me convert karke dobara upload karo.";

function mediaErrorText(v: HTMLVideoElement | null, src: string): string {
  switch (v?.error?.code) {
    case 1:
      return "Video load beech me ruk gaya. Retry dabao.";
    case 2:
      return "Network error — internet check karo, phir Retry dabao.";
    case 3:
      return `Video decode nahi ho paa rahi — file adhuri/kharab hai ya codec support nahi. ${CODEC_TEXT}`;
    case 4:
      return src.startsWith("blob:")
        ? "Ye video file is browser me khul nahi paayi. Admin se kaho video dobara upload kare (MP4 / H.264)."
        : "Ye link ya format is browser me nahi chal sakta. Link seedha public MP4 (H.264) file ka hona chahiye. Agar ye kisi website ka page hai to episode me Source Type 'Embed' chuno.";
    default:
      return "Video load nahi hua. Retry dabao.";
  }
}

/* ------------------------------ entry ------------------------------ */

export default function MediaPlayer(props: Props) {
  const { src, poster, title, embed, qualities, onVideoEl, onProgress, startAt, onEnded, onError } = props;
  const kind = detectKind(src);
  const allow =
    "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen";

  if (kind === "youtube") {
    return <iframe src={toYouTubeEmbed(src)} title={title || "Video"} allow={allow} allowFullScreen className="h-full w-full bg-black" />;
  }
  if (kind === "vimeo") {
    return <iframe src={toVimeoEmbed(src)} title={title || "Video"} allow={allow} allowFullScreen className="h-full w-full bg-black" />;
  }
  if (embed) {
    return <iframe src={src} title={title || "Video"} allow={allow} allowFullScreen className="h-full w-full bg-black" />;
  }
  return (
    <NativePlayer
      src={src}
      poster={poster}
      title={title}
      qualities={qualities}
      onVideoEl={onVideoEl}
      onProgress={onProgress}
      startAt={startAt}
      onEnded={onEnded}
      onError={onError}
    />
  );
}

/* ------------------------------ player ------------------------------ */

function NativePlayer({ src, poster, title, qualities, onVideoEl, onProgress, startAt, onEnded, onError }: Props) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  // ---- History: report real watch progress ----
  const progressCb = useRef(onProgress);
  progressCb.current = onProgress;
  const startRef = useRef(startAt && startAt > 1 ? startAt : 0);
  const lastReport = useRef(0);
  const lastPos = useRef({ t: 0, d: 0 });
  const report = useCallback((finished = false) => {
    const { t, d } = lastPos.current;
    if (!(d > 0)) return;
    progressCb.current?.(finished ? d : t, d);
    lastReport.current = Date.now();
  }, []);
  // leaving the episode (back button, next episode, closing the tab) saves where we were
  useEffect(() => {
    const save = () => report();
    window.addEventListener("pagehide", save);
    return () => {
      window.removeEventListener("pagehide", save);
      report();
    };
  }, [report]);
  const hideTimer = useRef<number | null>(null);
  const lastTap = useRef<{ time: number; side: "l" | "r" | null }>({ time: 0, side: null });
  const resumeRef = useRef<{ t: number; play: boolean } | null>(null);
  const hlsRef = useRef<Hls | null>(null);

  const options = useMemo(() => buildOptions(src, qualities), [src, qualities]);
  const isCoarse = useMemo(() => !!window.matchMedia?.("(pointer: coarse)").matches, []);
  const nativeHls = useMemo(
    () => document.createElement("video").canPlayType("application/vnd.apple.mpegurl") !== "",
    [],
  );

  const [pref, setPref] = useState<string>(() => {
    try {
      return localStorage.getItem(QKEY) || "auto";
    } catch {
      return "auto";
    }
  });
  const [activeId, setActiveId] = useState<string>(() => {
    let p = "auto";
    try {
      p = localStorage.getItem(QKEY) || "auto";
    } catch {
      /* ignore */
    }
    return pickInitial(options, p).id;
  });
  const activeOpt = options.find((o) => o.id === activeId) ?? options[0];
  const activeUrl = activeOpt.url;
  const useHls = isHlsUrl(activeUrl) && !nativeHls;

  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState(1);
  const [current, setCurrent] = useState(0);
  const [duration, setDuration] = useState(0);
  const [buffered, setBuffered] = useState(0);
  const [fullscreen, setFullscreen] = useState(false);
  const [cssFull, setCssFull] = useState(false);
  const [noRotate, setNoRotate] = useState(false);
  const [portrait, setPortrait] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showControls, setShowControls] = useState(true);
  const [speed, setSpeed] = useState(1);
  const [showMenu, setShowMenu] = useState(false);
  const [seekPct, setSeekPct] = useState<number | null>(null);
  const [skipFlash, setSkipFlash] = useState<"back" | "fwd" | null>(null);
  const [pipSupported, setPipSupported] = useState(false);
  const [isPip, setIsPip] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [stalled, setStalled] = useState(false);
  const [videoHeight, setVideoHeight] = useState(0);
  const [note, setNote] = useState("");
  const [hlsLevels, setHlsLevels] = useState<{ index: number; height: number }[]>([]);
  const [hlsCurrent, setHlsCurrent] = useState(-1);
  const [hlsPref, setHlsPref] = useState(-1);
  const [hlsTry, setHlsTry] = useState(0);

  const isFull = fullscreen || cssFull;
  const rotated = cssFull && portrait && !noRotate;

  /* ---- expose the <video> to Watch Party ---- */
  useEffect(() => {
    onVideoEl?.(videoRef.current);
    return () => onVideoEl?.(null);
  }, [onVideoEl]);

  /* ---- basic controls ---- */
  const readDuration = useCallback((v: HTMLVideoElement): number => {
    if (isFinite(v.duration) && v.duration > 0) return v.duration;
    if (v.seekable.length) return v.seekable.end(v.seekable.length - 1);
    return 0;
  }, []);

  const togglePlay = useCallback(() => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) v.play().catch(() => {});
    else v.pause();
  }, []);

  const seek = useCallback(
    (t: number) => {
      const v = videoRef.current;
      if (!v) return;
      const max = readDuration(v);
      if (!max) return;
      v.currentTime = Math.max(0, Math.min(t, max));
    },
    [readDuration],
  );

  const skip = useCallback(
    (delta: number) => {
      seek((videoRef.current?.currentTime || 0) + delta);
      setSkipFlash(delta < 0 ? "back" : "fwd");
      window.setTimeout(() => setSkipFlash(null), 450);
    },
    [seek],
  );

  /* ---- fullscreen + landscape ---- */
  const exitFullscreen = useCallback(() => {
    setCssFull(false);
    setNoRotate(false);
    if (document.fullscreenElement) {
      void document.exitFullscreen?.().catch(() => {});
    } else if ((document as unknown as FsDoc).webkitFullscreenElement) {
      (document as unknown as FsDoc).webkitExitFullscreen?.();
    }
    try {
      orient()?.unlock?.();
    } catch {
      /* ignore */
    }
  }, []);

  const enterFullscreen = useCallback(async () => {
    const el = wrapRef.current as (HTMLDivElement & FsEl) | null;
    const v = videoRef.current as (HTMLVideoElement & VideoFsEl) | null;
    if (!el) return;

    try {
      if (el.requestFullscreen) {
        await el.requestFullscreen({ navigationUI: "hide" });
      } else if (el.webkitRequestFullscreen) {
        el.webkitRequestFullscreen();
      } else if (v?.webkitEnterFullscreen) {
        // iOS Safari's native video fullscreen API.
        v.webkitEnterFullscreen();
        return;
      } else {
        throw new Error("no-fullscreen-api");
      }

      // Prefer landscape for wide videos on supported mobile browsers.
      if (!v || v.videoWidth >= v.videoHeight) {
        try {
          await orient()?.lock?.("landscape");
        } catch {
          /* Orientation lock is optional and browser-dependent. */
        }
      }
    } catch {
      // Fallback for browsers/webviews that expose no usable fullscreen API.
      setCssFull(true);
    }
  }, []);

  const toggleFullscreen = useCallback(() => {
    if (fsElement() || cssFull) exitFullscreen();
    else void enterFullscreen();
  }, [cssFull, exitFullscreen, enterFullscreen]);

  /** Manual rotate button for when auto-landscape is not possible/wanted. */
  const toggleRotate = useCallback(() => {
    if (cssFull) {
      setNoRotate((n) => !n);
      return;
    }
    const o = orient();
    if (o?.lock) {
      const next = (o.type || "").startsWith("landscape") ? "portrait" : "landscape";
      void o.lock(next).catch(() => {});
    }
  }, [cssFull]);

  const togglePip = useCallback(async () => {
    const v = videoRef.current as (HTMLVideoElement & { requestPictureInPicture?: () => Promise<unknown> }) | null;
    if (!v?.requestPictureInPicture) return;
    try {
      if (document.pictureInPictureElement === v) await document.exitPictureInPicture();
      else await v.requestPictureInPicture();
    } catch {
      /* ignore */
    }
  }, []);

  const revealControls = useCallback(() => {
    setShowControls(true);
    if (hideTimer.current) window.clearTimeout(hideTimer.current);
    hideTimer.current = window.setTimeout(() => {
      if (!videoRef.current?.paused) setShowControls(false);
    }, 2800);
  }, []);

  /* ---- environment listeners ---- */
  useEffect(() => {
    const probe = document.createElement("video") as HTMLVideoElement & { requestPictureInPicture?: unknown };
    setPipSupported(typeof document.exitPictureInPicture === "function" && typeof probe.requestPictureInPicture === "function");
  }, []);

  useEffect(() => {
    const onFs = () => {
      const on = !!fsElement();
      setFullscreen(on);
      if (!on) {
        try {
          orient()?.unlock?.();
        } catch {
          /* ignore */
        }
      }
    };
    document.addEventListener("fullscreenchange", onFs);
    document.addEventListener("webkitfullscreenchange", onFs);
    return () => {
      document.removeEventListener("fullscreenchange", onFs);
      document.removeEventListener("webkitfullscreenchange", onFs);
    };
  }, []);

  useEffect(() => {
    const mq = window.matchMedia("(orientation: portrait)");
    const up = () => setPortrait(mq.matches);
    up();
    mq.addEventListener?.("change", up);
    return () => mq.removeEventListener?.("change", up);
  }, []);

  // While our own full-screen layer is on: stop page scroll and hide the Watch Party dock.
  useEffect(() => {
    if (!cssFull) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    document.documentElement.dataset.fs = "1";
    return () => {
      document.body.style.overflow = prev;
      delete document.documentElement.dataset.fs;
    };
  }, [cssFull]);

  // Leaving the page while fullscreen must not leave the phone locked sideways.
  useEffect(
    () => () => {
      try {
        orient()?.unlock?.();
      } catch {
        /* ignore */
      }
    },
    [],
  );

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    const onEnter = () => setIsPip(true);
    const onLeave = () => setIsPip(false);
    v.addEventListener("enterpictureinpicture", onEnter);
    v.addEventListener("leavepictureinpicture", onLeave);
    return () => {
      v.removeEventListener("enterpictureinpicture", onEnter);
      v.removeEventListener("leavepictureinpicture", onLeave);
    };
  }, []);

  /* ---- HLS (.m3u8) via hls.js, with quality levels ---- */
  useEffect(() => {
    if (!useHls) return;
    const video = videoRef.current;
    if (!video) return;
    let cancelled = false;
    let hls: Hls | null = null;

    (async () => {
      let HlsLib: typeof Hls;
      try {
        HlsLib = await loadHls();
      } catch {
        if (!cancelled) {
          setLoading(false);
          setError("HLS player load nahi hua — internet check karo aur Retry dabao.");
        }
        return;
      }
      if (cancelled) return;
      if (!HlsLib.isSupported()) {
        setLoading(false);
        setError("Is browser me .m3u8 (HLS) video support nahi hai. Chrome / Safari update karke dekho.");
        return;
      }
      hls = new HlsLib({ enableWorker: true, lowLatencyMode: false });
      hlsRef.current = hls;
      hls.on(HlsLib.Events.MANIFEST_PARSED, (_e, data) => {
        const lv = data.levels
          .map((l, i) => ({ index: i, height: l.height || 0 }))
          .filter((l) => l.height > 0)
          .sort((a, b) => b.height - a.height);
        setHlsLevels(lv);
        setHlsCurrent(-1);
        void video.play().catch(() => {});
      });
      hls.on(HlsLib.Events.LEVEL_SWITCHED, (_e, data) => setHlsCurrent(data.level));
      hls.on(HlsLib.Events.ERROR, (_e, data) => {
        if (!data.fatal) return;
        if (data.type === HlsLib.ErrorTypes.NETWORK_ERROR) hls?.startLoad();
        else if (data.type === HlsLib.ErrorTypes.MEDIA_ERROR) hls?.recoverMediaError();
        else {
          setLoading(false);
          setError("Ye HLS stream chal nahi paayi. Link check karo ya Retry dabao.");
          onError?.();
        }
      });
      hls.loadSource(activeUrl);
      hls.attachMedia(video);
    })();

    return () => {
      cancelled = true;
      hls?.destroy();
      hlsRef.current = null;
      setHlsLevels([]);
      setHlsCurrent(-1);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeUrl, useHls, hlsTry]);

  /* ---- stuck detector ---- */
  useEffect(() => {
    let last = -1;
    let still = 0;
    const iv = window.setInterval(() => {
      const v = videoRef.current;
      if (!v) return;
      if (v.paused || v.ended || v.seeking) {
        still = 0;
        last = v.currentTime;
        setStalled(false);
        return;
      }
      if (Math.abs(v.currentTime - last) < 0.05) {
        still++;
        if (still >= 6) setStalled(true);
      } else {
        still = 0;
        last = v.currentTime;
        setStalled(false);
      }
    }, 1000);
    return () => window.clearInterval(iv);
  }, []);

  /* ---- keyboard ---- */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
      switch (e.key.toLowerCase()) {
        case " ":
        case "k":
          e.preventDefault();
          togglePlay();
          break;
        case "arrowright":
        case "l":
          skip(5);
          break;
        case "arrowleft":
        case "j":
          skip(-5);
          break;
        case "arrowup":
          setVolume((x) => Math.min(1, x + 0.1));
          break;
        case "arrowdown":
          setVolume((x) => Math.max(0, x - 0.1));
          break;
        case "m":
          setMuted((m) => !m);
          break;
        case "f":
          toggleFullscreen();
          break;
        case "escape":
          if (cssFull) exitFullscreen();
          break;
        case "p":
          void togglePip();
          break;
      }
      revealControls();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [togglePlay, revealControls, skip, toggleFullscreen, togglePip, cssFull, exitFullscreen]);

  useEffect(() => {
    const v = videoRef.current;
    if (v) {
      v.volume = volume;
      v.muted = muted;
    }
  }, [volume, muted]);

  useEffect(() => {
    const v = videoRef.current;
    if (v) v.playbackRate = speed;
  }, [speed]);

  useEffect(() => {
    if (!note) return;
    const t = window.setTimeout(() => setNote(""), 4500);
    return () => window.clearTimeout(t);
  }, [note]);

  /* ---- quality switching ---- */
  const switchTo = useCallback(
    (id: string) => {
      if (id === activeId) return;
      const v = videoRef.current;
      resumeRef.current = v ? { t: v.currentTime, play: !v.paused } : null;
      setLoading(true);
      setError(null);
      setActiveId(id);
    },
    [activeId],
  );

  const chooseQuality = (id: string) => {
    try {
      localStorage.setItem(QKEY, id);
    } catch {
      /* ignore */
    }
    setPref(id);
    const target = id === "auto" ? pickAuto(options) : options.find((o) => o.id === id);
    if (target) switchTo(target.id);
    setShowMenu(false);
  };

  const chooseHls = (index: number) => {
    setHlsPref(index);
    if (hlsRef.current) hlsRef.current.currentLevel = index; // -1 = automatic
    setShowMenu(false);
  };

  const reload = useCallback(() => {
    const v = videoRef.current;
    if (!v) return;
    setError(null);
    setStalled(false);
    setLoading(true);
    if (useHls && !hlsRef.current) {
      setHlsTry((n) => n + 1); // the HLS engine never started: set it up again
      return;
    }
    if (hlsRef.current) {
      hlsRef.current.startLoad();
      hlsRef.current.recoverMediaError();
      void v.play().catch(() => {});
      return;
    }
    resumeRef.current = { t: v.currentTime || 0, play: true };
    v.load();
  }, [useHls]);

  /* ---- gestures ---- */
  const fracOf = (clientX: number, clientY: number, el: HTMLElement): number => {
    const r = el.getBoundingClientRect();
    // In our rotated full-screen layer the video's "left to right" runs top to bottom on screen.
    const f = rotated ? (clientY - r.top) / r.height : (clientX - r.left) / r.width;
    return Math.max(0, Math.min(1, f));
  };

  const onVideoClick = (e: React.MouseEvent<HTMLVideoElement>) => {
    setShowMenu(false);
    if (!isCoarse) {
      togglePlay(); // desktop: click = play/pause, double-click = fullscreen
      return;
    }
    // touch: single tap = play/pause, double tap left/right = -/+10s
    const now = Date.now();
    const side: "l" | "r" = fracOf(e.clientX, e.clientY, e.currentTarget) < 0.5 ? "l" : "r";
    if (now - lastTap.current.time < 320 && lastTap.current.side === side) {
      lastTap.current = { time: 0, side: null };
      skip(side === "l" ? -10 : 10);
    } else {
      lastTap.current = { time: now, side };
      window.setTimeout(() => {
        if (lastTap.current.time && Date.now() - lastTap.current.time >= 300) {
          togglePlay();
          lastTap.current = { time: 0, side: null };
        }
      }, 310);
    }
  };

  const pct = seekPct ?? (duration ? (current / duration) * 100 : 0);
  const bufPct = duration ? (buffered / duration) * 100 : 0;
  const isWeb = /^https?:\/\//i.test(activeUrl);

  /* ---- menu items ---- */
  type QItem = { key: string; label: string; active: boolean; onClick: () => void };
  const qualityItems: QItem[] = useMemo(() => {
    if (hlsLevels.length > 0) {
      const curH = hlsLevels.find((l) => l.index === hlsCurrent)?.height;
      return [
        {
          key: "auto",
          label: `Auto${hlsPref === -1 && curH ? ` (${curH}p)` : ""}`,
          active: hlsPref === -1,
          onClick: () => chooseHls(-1),
        },
        ...hlsLevels.map((l) => ({
          key: String(l.index),
          label: `${l.height}p`,
          active: hlsPref === l.index,
          onClick: () => chooseHls(l.index),
        })),
      ];
    }
    if (options.length > 1) {
      return [
        {
          key: "auto",
          label: `Auto${pref === "auto" ? ` (${activeOpt.label})` : ""}`,
          active: pref === "auto",
          onClick: () => chooseQuality("auto"),
        },
        ...options.map((o) => ({
          key: o.id,
          label: o.label,
          active: pref !== "auto" && activeId === o.id,
          onClick: () => chooseQuality(o.id),
        })),
      ];
    }
    return [];
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hlsLevels, hlsCurrent, hlsPref, options, pref, activeId, activeOpt.label]);

  /* ---- layout ---- */
  const wrapStyle: React.CSSProperties | undefined = cssFull
    ? rotated
      ? {
          position: "fixed",
          top: 0,
          left: 0,
          width: "100dvh",
          height: "100dvw",
          transform: "rotate(90deg) translateY(-100%)",
          transformOrigin: "top left",
          zIndex: 100,
        }
      : { position: "fixed", inset: 0, zIndex: 100 }
    : undefined;

  return (
    <div
      ref={wrapRef}
      style={wrapStyle}
      onMouseMove={revealControls}
      onMouseLeave={() => playing && !showMenu && setShowControls(false)}
      onTouchStart={revealControls}
      className={`group select-none overflow-hidden bg-black ${cssFull ? "" : "relative h-full w-full"}`}
    >
      {/* Plain src, no <source>/type hint and no crossOrigin: those broke gallery files (.mov/.webm)
          and some hosts. The browser works out the real format by itself. */}
      <video
        ref={videoRef}
        src={useHls ? undefined : activeUrl}
        poster={poster}
        className="h-full w-full bg-black"
        onClick={onVideoClick}
        onDoubleClick={isCoarse ? undefined : toggleFullscreen}
        onPlay={() => setPlaying(true)}
        onPause={() => {
          setPlaying(false);
          report();
        }}
        onWaiting={() => setLoading(true)}
        onPlaying={() => {
          setLoading(false);
          setError(null);
        }}
        onCanPlay={() => setLoading(false)}
        onSeeked={() => setLoading(false)}
        onDurationChange={(e) => setDuration(readDuration(e.currentTarget))}
        onLoadedMetadata={(e) => {
          const v = e.currentTarget;
          setDuration(readDuration(v));
          setVideoHeight(v.videoHeight || 0);
          // A video track with no picture => unsupported codec (e.g. HEVC)
          if (v.videoWidth === 0 && v.duration > 0 && !useHls) setError(CODEC_TEXT);
          const r = resumeRef.current;
          if (r) {
            resumeRef.current = null;
            try {
              if (r.t > 1) v.currentTime = r.t;
            } catch {
              /* ignore */
            }
            if (r.play) void v.play().catch(() => {});
          } else if (startRef.current > 0) {
            // Resume from where the viewer stopped last time (History)
            const at = startRef.current;
            startRef.current = 0;
            const len = readDuration(v);
            if (len > 0 && at < len - 10) {
              try {
                v.currentTime = at;
              } catch {
                /* ignore */
              }
            }
          }
        }}
        onResize={(e) => setVideoHeight(e.currentTarget.videoHeight || 0)}
        onTimeUpdate={(e) => {
          const v = e.currentTarget;
          setCurrent(v.currentTime);
          if (!duration) setDuration(readDuration(v));
          const b = v.buffered;
          if (b.length) setBuffered(b.end(b.length - 1));
          // keep History up to date every ~5 seconds of playing
          const d = readDuration(v);
          if (d > 0) {
            lastPos.current = { t: v.currentTime, d };
            if (!v.paused && Date.now() - lastReport.current > 5000) report();
          }
        }}
        onEnded={() => {
          setPlaying(false);
          report(true);
          onEnded?.();
        }}
        onError={(e) => {
          if (useHls) return; // hls.js reports its own errors
          // A resolution variant that fails (e.g. still processing) falls back to the main file.
          const base = options.find((o) => o.id === "original") ?? options[options.length - 1];
          if (base && base.id !== activeOpt.id) {
            const v = e.currentTarget;
            resumeRef.current = { t: v.currentTime || 0, play: true };
            setNote(`${activeOpt.label} abhi available nahi — ${base.label} chala rahe hain.`);
            setActiveId(base.id);
            return;
          }
          setLoading(false);
          setError(mediaErrorText(e.currentTarget, activeUrl));
          onError?.();
        }}
        autoPlay
        playsInline
        preload="auto"
        controlsList="nodownload"
      />

      {/* Loading */}
      {loading && !error && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-black/40">
          <Loader2 className="h-12 w-12 animate-spin text-cyan-400" />
        </div>
      )}

      {/* Little notice (quality fallback etc.) */}
      {note && (
        <div className="pointer-events-none absolute left-1/2 top-14 z-10 max-w-[90%] -translate-x-1/2 rounded-full bg-black/80 px-4 py-2 text-center text-xs font-semibold text-white ring-1 ring-white/20 backdrop-blur">
          {note}
        </div>
      )}

      {/* Stuck banner */}
      {stalled && !error && (
        <div className="absolute inset-x-3 top-12 z-10 flex flex-wrap items-center gap-2 rounded-xl bg-amber-500/15 px-3 py-2 text-xs text-amber-100 ring-1 ring-amber-500/40 backdrop-blur">
          <AlertTriangle className="h-4 w-4 shrink-0 text-amber-400" />
          <span className="min-w-0 flex-1">
            Video atak gayi hai — internet slow ho sakta hai. Quality kam karke dekho ya Reload dabao.
          </span>
          <button onClick={reload} className="flex items-center gap-1 rounded-full bg-amber-500 px-3 py-1 font-bold text-slate-950">
            <RefreshCw className="h-3 w-3" /> Reload
          </button>
        </div>
      )}

      {/* Skip flash */}
      {skipFlash && (
        <div
          className={`pointer-events-none absolute top-1/2 ${
            skipFlash === "back" ? "left-10" : "right-10"
          } -translate-y-1/2 rounded-full bg-black/70 px-4 py-2 text-sm font-black text-white ring-1 ring-white/20`}
        >
          {skipFlash === "back" ? "⏪ 10s" : "10s ⏩"}
        </div>
      )}

      {/* Error */}
      {error && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-3 bg-black/85 px-6 text-center">
          <AlertTriangle className="h-10 w-10 text-amber-400" />
          <p className="max-w-md text-sm font-semibold leading-relaxed text-white">{error}</p>
          <div className="flex flex-wrap justify-center gap-2">
            <button
              onClick={reload}
              className="flex items-center gap-1.5 rounded-full bg-blue-600 px-5 py-2 text-xs font-bold text-white transition hover:bg-blue-500"
            >
              <RefreshCw className="h-3.5 w-3.5" /> Retry
            </button>
            {isWeb && (
              <a
                href={activeUrl}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1.5 rounded-full bg-white/10 px-5 py-2 text-xs font-bold text-white ring-1 ring-white/20 transition hover:bg-white/20"
              >
                <ExternalLink className="h-3.5 w-3.5" /> Link kholo
              </a>
            )}
          </div>
        </div>
      )}

      {/* Big center play */}
      {!playing && !loading && !error && (
        <button
          onClick={togglePlay}
          aria-label="Play"
          className="absolute inset-0 flex items-center justify-center bg-black/20 transition hover:bg-black/30"
        >
          <span className="flex h-20 w-20 items-center justify-center rounded-full bg-blue-600 shadow-2xl shadow-blue-600/50 transition hover:scale-110">
            <Play className="h-9 w-9 translate-x-0.5 fill-white text-white" />
          </span>
        </button>
      )}

      {/* Title */}
      <div
        className={`pointer-events-none absolute inset-x-0 top-0 bg-gradient-to-b from-black/80 to-transparent px-4 pb-6 pt-3 transition-opacity ${
          showControls || !playing ? "opacity-100" : "opacity-0"
        }`}
      >
        {title && <p className="truncate text-sm font-semibold text-white/90">{title}</p>}
      </div>

      {/* Mobile fullscreen affordance: stays reachable even when auto-hide controls are active. */}
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          toggleFullscreen();
          revealControls();
        }}
        aria-label={isFull ? "Exit fullscreen" : "Fullscreen"}
        title={isFull ? "Exit fullscreen" : "Fullscreen"}
        className={`absolute right-2 top-2 z-30 flex h-10 w-10 items-center justify-center rounded-full bg-black/55 text-white/95 ring-1 ring-white/20 backdrop-blur transition-opacity sm:hidden ${showControls || !playing ? "opacity-100" : "opacity-0"}`}
      >
        {isFull ? <Minimize className="h-5 w-5" /> : <Maximize className="h-5 w-5" />}
      </button>

      {/* Controls */}
      <div
        className={`absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/95 via-black/55 to-transparent px-3 pb-3 pt-10 transition-opacity duration-300 ${
          showControls || !playing ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
      >
        {/* Seek */}
        <div
          className="group/seek relative mb-2 h-6 cursor-pointer touch-none"
          onPointerDown={(e) => {
            e.currentTarget.setPointerCapture(e.pointerId);
            setSeekPct(fracOf(e.clientX, e.clientY, e.currentTarget) * 100);
          }}
          onPointerMove={(e) => {
            if (seekPct !== null) setSeekPct(fracOf(e.clientX, e.clientY, e.currentTarget) * 100);
          }}
          onPointerUp={(e) => {
            const p = fracOf(e.clientX, e.clientY, e.currentTarget);
            seek(p * duration);
            setSeekPct(null);
            revealControls();
          }}
          onPointerCancel={() => setSeekPct(null)}
        >
          <div className="absolute top-1/2 h-1.5 w-full -translate-y-1/2 rounded-full bg-white/20">
            <div className="absolute h-full rounded-full bg-white/30" style={{ width: `${bufPct}%` }} />
            <div className="absolute h-full rounded-full bg-gradient-to-r from-blue-500 to-cyan-400" style={{ width: `${pct}%` }} />
            <div
              className="absolute top-1/2 h-4 w-4 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white shadow-lg shadow-cyan-500/50 ring-2 ring-cyan-400 transition"
              style={{ left: `${pct}%` }}
            />
          </div>
        </div>

        <div className="flex min-w-0 items-center gap-0.5 text-white sm:gap-2">
          <Ctrl onClick={togglePlay} label={playing ? "Pause" : "Play"}>
            {playing ? <Pause className="h-5 w-5 fill-white" /> : <Play className="h-5 w-5 fill-white" />}
          </Ctrl>
          <Ctrl onClick={() => skip(-10)} label="Back 10s">
            <SkipBack className="h-5 w-5" />
          </Ctrl>
          <Ctrl onClick={() => skip(10)} label="Forward 10s">
            <SkipForward className="h-5 w-5" />
          </Ctrl>

          <div className="group/vol hidden items-center sm:flex">
            <Ctrl onClick={() => setMuted((m) => !m)} label="Mute">
              {muted || volume === 0 ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
            </Ctrl>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={muted ? 0 : volume}
              onChange={(e) => {
                setVolume(Number(e.target.value));
                setMuted(false);
              }}
              className="h-1 w-0 cursor-pointer appearance-none rounded-full bg-white/30 accent-cyan-400 transition-all duration-200 group-hover/vol:w-20"
              aria-label="Volume"
            />
          </div>

          <Ctrl onClick={() => setMuted((m) => !m)} label={muted || volume === 0 ? "Unmute" : "Mute"}>
            {muted || volume === 0 ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
          </Ctrl>

          <span className="ml-0.5 shrink-0 text-[11px] font-medium tabular-nums text-white/90 sm:ml-1 sm:text-xs">
            {fmt(current)} <span className="text-white/50">/ {fmt(duration)}</span>
          </span>

          <div className="ml-auto flex shrink-0 items-center gap-0.5 sm:gap-2">
            {videoHeight > 0 && (
              <span className="hidden rounded bg-white/15 px-1.5 py-0.5 text-[10px] font-bold text-white/90 sm:inline-flex">{videoHeight}p</span>
            )}

            <div className="relative">
              <Ctrl onClick={() => setShowMenu((s) => !s)} label="Quality & speed">
                <Settings className={`h-5 w-5 transition ${showMenu ? "rotate-45 text-cyan-400" : ""}`} />
              </Ctrl>
              {showMenu && (
                <div className="absolute bottom-12 right-0 max-h-72 w-52 overflow-y-auto rounded-xl bg-slate-900/95 shadow-2xl ring-1 ring-white/15 backdrop-blur">
                  {qualityItems.length > 0 && (
                    <>
                      <div className="flex items-center gap-2 border-b border-white/10 px-3 py-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                        <Signal className="h-3.5 w-3.5" /> Quality
                      </div>
                      {qualityItems.map((q) => (
                        <button
                          key={q.key}
                          onClick={q.onClick}
                          className={`block w-full px-3 py-1.5 text-left text-xs font-semibold transition hover:bg-cyan-500/20 ${
                            q.active ? "text-cyan-400" : "text-white"
                          }`}
                        >
                          {q.active ? "✓ " : "   "}
                          {q.label}
                        </button>
                      ))}
                    </>
                  )}
                  <div className="flex items-center gap-2 border-y border-white/10 px-3 py-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    <Gauge className="h-3.5 w-3.5" /> Playback speed
                  </div>
                  {SPEEDS.map((s) => (
                    <button
                      key={s}
                      onClick={() => {
                        setSpeed(s);
                        setShowMenu(false);
                      }}
                      className={`block w-full px-3 py-1.5 text-left text-xs font-semibold transition hover:bg-cyan-500/20 ${
                        s === speed ? "text-cyan-400" : "text-white"
                      }`}
                    >
                      {s === speed ? "✓ " : "   "}
                      {s}x {s === 1 ? "(Normal)" : ""}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {isFull && (
              <Ctrl onClick={toggleRotate} label="Rotate screen">
                <RotateCw className="h-5 w-5" />
              </Ctrl>
            )}

            {pipSupported && (
              <Ctrl onClick={() => void togglePip()} label="Picture in Picture">
                <PictureInPicture2 className={`h-5 w-5 ${isPip ? "text-cyan-400" : ""}`} />
              </Ctrl>
            )}

            <Ctrl onClick={toggleFullscreen} label={isFull ? "Exit fullscreen" : "Fullscreen"}>
              {isFull ? <Minimize className="h-5 w-5" /> : <Maximize className="h-5 w-5" />}
            </Ctrl>
          </div>
        </div>
      </div>
    </div>
  );
}

function Ctrl({
  onClick,
  label,
  children,
}: {
  onClick: () => void;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={(e) => {
        e.stopPropagation();
        onClick();
      }}
      title={label}
      aria-label={label}
      className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg p-1.5 text-white/90 transition hover:bg-white/15 hover:text-cyan-400 active:scale-95 sm:h-11 sm:w-11 sm:p-2"
    >
      {children}
    </button>
  );
}

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Search, Menu, X, Shield, Users } from "lucide-react";
import Logo from "./Logo";
import type { Anime } from "../types";

interface Props {
  active: string;
  onNavigate: (view: string) => void;
  onSearch: (q: string) => void;
  onAdmin: () => void;
  onParty: () => void;
  /** Code of the Watch Party we are in (shown on the button) */
  partyCode?: string;
  genres: string[];
  topAiring: Anime[];
  onPickGenre: (genre: string) => void;
  onPickAnime: (anime: Anime) => void;
}

export const TABS = [
  { id: "home", label: "Home" },
  { id: "schedule", label: "Schedule" },
  { id: "saved", label: "Saved" },
  { id: "history", label: "History" },
  { id: "library", label: "Library" },
];

export default function Navbar({
  active,
  onNavigate,
  onSearch,
  onAdmin,
  onParty,
  partyCode,
  genres,
  topAiring,
  onPickGenre,
  onPickAnime,
}: Props) {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const closeTimer = useRef<number | null>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const openMenu = () => {
    if (closeTimer.current) window.clearTimeout(closeTimer.current);
    setMenuOpen(true);
  };
  const closeMenuSoon = () => {
    if (closeTimer.current) window.clearTimeout(closeTimer.current);
    closeTimer.current = window.setTimeout(() => setMenuOpen(false), 140);
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onSearch(query.trim());
      setOpen(false);
    }
  };

  const go = (id: string) => {
    onNavigate(id);
    setOpen(false);
    setMenuOpen(false);
  };

  return (
    <header
      className={`sticky top-0 z-40 transition-colors duration-300 ${
        scrolled
          ? "border-b border-white/5 bg-[#0a0e1a]/85 backdrop-blur-xl"
          : "border-b border-transparent bg-[#0a0e1a]/70 backdrop-blur-md"
      }`}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-6 px-4 sm:px-6">
        <button onClick={() => go("home")} aria-label="AniZen home" className="shrink-0">
          <Logo className="text-xl sm:text-2xl" />
        </button>

        <nav className="ml-2 hidden items-center gap-7 md:flex">
          {TABS.map((l) => {
            const isActive = active === l.id;
            const btn = (
              <button
                onClick={() => go(l.id)}
                className={`relative py-5 text-[13px] font-medium uppercase tracking-wide transition-colors ${
                  isActive ? "text-cyan-400" : "text-slate-300 hover:text-white"
                }`}
              >
                {l.label}
                {isActive && (
                  <motion.span
                    layoutId="nav-underline"
                    transition={{ type: "spring", stiffness: 420, damping: 34 }}
                    className="absolute inset-x-0 bottom-3 h-[2px] rounded-full bg-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.8)]"
                  />
                )}
              </button>
            );

            // Hovering "Library" opens the genre / Top Airing quick menu
            if (l.id !== "library") return <div key={l.id}>{btn}</div>;

            return (
              <div key={l.id} className="relative" onMouseEnter={openMenu} onMouseLeave={closeMenuSoon}>
                {btn}
                <AnimatePresence>
                  {menuOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 6 }}
                      transition={{ duration: 0.16 }}
                      className="absolute left-1/2 top-full z-50 w-60 -translate-x-1/2"
                    >
                      <div className="max-h-[70vh] overflow-y-auto rounded-xl border border-white/10 bg-[#0d1424]/95 p-5 shadow-2xl shadow-black/60 backdrop-blur-xl">
                        <h4 className="mb-2.5 text-[15px] font-bold text-white">Categories</h4>
                        {genres.length === 0 ? (
                          <p className="text-xs text-slate-500">Abhi koi genre nahi hai.</p>
                        ) : (
                          <ul className="space-y-1.5">
                            {genres.slice(0, 10).map((g) => (
                              <li key={g}>
                                <button
                                  onClick={() => {
                                    onPickGenre(g);
                                    setMenuOpen(false);
                                  }}
                                  className="text-[13px] text-slate-400 transition hover:text-cyan-400"
                                >
                                  {g}
                                </button>
                              </li>
                            ))}
                          </ul>
                        )}

                        <h4 className="mb-2.5 mt-5 text-[15px] font-bold text-white">Top Airing</h4>
                        {topAiring.length === 0 ? (
                          <p className="text-xs text-slate-500">Abhi kuch airing nahi hai.</p>
                        ) : (
                          <ul className="space-y-1.5">
                            {topAiring.map((a) => (
                              <li key={a.id}>
                                <button
                                  onClick={() => {
                                    onPickAnime(a);
                                    setMenuOpen(false);
                                  }}
                                  className="max-w-full truncate text-left text-[13px] text-slate-400 transition hover:text-cyan-400"
                                >
                                  {a.titleEnglish || a.title}
                                </button>
                              </li>
                            ))}
                          </ul>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </nav>

        <form onSubmit={submit} className="ml-auto hidden w-64 md:block lg:w-80">
          <div className="relative">
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search Anime, Movies, OVAs..."
              className="w-full rounded-full border border-white/10 bg-white/[0.06] py-2 pl-4 pr-10 text-[13px] text-white placeholder-slate-400 outline-none transition focus:border-cyan-400/50 focus:bg-white/[0.09]"
            />
            <button type="submit" aria-label="Search" className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-300 hover:text-cyan-400">
              <Search className="h-4 w-4" />
            </button>
          </div>
        </form>

        <button
          onClick={onParty}
          title="Watch Party"
          className={`hidden h-9 shrink-0 items-center gap-2 rounded-full border px-3.5 text-[12px] font-bold uppercase tracking-wide transition md:flex ${
            partyCode
              ? "border-cyan-400/60 bg-cyan-400/10 text-cyan-300"
              : "border-white/10 bg-white/[0.06] text-slate-300 hover:border-cyan-400/50 hover:text-cyan-400"
          }`}
        >
          <Users className="h-4 w-4" />
          {partyCode ? <span className="font-mono tracking-widest">{partyCode}</span> : "Party"}
        </button>

        <button
          onClick={onAdmin}
          title="Admin Panel"
          aria-label="Admin Panel"
          className="hidden h-9 w-9 shrink-0 items-center justify-center rounded-full border border-white/10 bg-white/[0.06] text-slate-300 transition hover:border-cyan-400/50 hover:text-cyan-400 md:flex"
        >
          <Shield className="h-4 w-4" />
        </button>

        <button
          onClick={() => setOpen((v) => !v)}
          className="ml-auto rounded-lg p-2 text-white md:hidden"
          aria-label="Menu"
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* Mobile: the 5 tabs live in the bottom bar, so this menu only holds the extras */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden border-t border-white/5 bg-[#0a0e1a]/98 backdrop-blur-xl md:hidden"
          >
            <div className="px-4 pb-4 pt-3">
              <form onSubmit={submit} className="mb-3">
                <div className="relative">
                  <input
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Search Anime, Movies, OVAs..."
                    className="w-full rounded-full border border-white/10 bg-white/[0.06] py-2.5 pl-4 pr-10 text-sm text-white placeholder-slate-400 outline-none focus:border-cyan-400/50"
                  />
                  <button type="submit" aria-label="Search" className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-300">
                    <Search className="h-4 w-4" />
                  </button>
                </div>
              </form>
              <div className="flex flex-col">
                <button
                  onClick={() => {
                    onParty();
                    setOpen(false);
                  }}
                  className={`flex items-center gap-2 border-b border-white/5 py-3 text-left text-sm font-medium uppercase tracking-wide ${
                    partyCode ? "text-cyan-400" : "text-slate-300"
                  }`}
                >
                  <Users className="h-4 w-4" /> Watch Party
                  {partyCode && <span className="font-mono tracking-widest">{partyCode}</span>}
                </button>
                <button
                  onClick={() => {
                    onAdmin();
                    setOpen(false);
                  }}
                  className="flex items-center gap-2 py-3 text-left text-sm font-medium uppercase tracking-wide text-slate-400"
                >
                  <Shield className="h-4 w-4" /> Admin Panel
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

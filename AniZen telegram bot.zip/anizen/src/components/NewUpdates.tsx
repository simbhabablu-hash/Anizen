import type { Anime } from "../types";
import { lastEpisodeNumber, updateLabel } from "../utils/format";

interface Props {
  items: Anime[];
  onOpen: (anime: Anime, episode: number) => void;
}

export default function NewUpdates({ items, onOpen }: Props) {
  if (items.length === 0) return null;
  return (
    <div className="grid gap-x-8 gap-y-3 md:grid-cols-2">
      {items.map((a) => {
        const ep = lastEpisodeNumber(a);
        const { day, time } = updateLabel(a.createdAt);
        const img = a.thumbnail || a.banner || a.poster;
        return (
          <button
            key={a.id}
            onClick={() => onOpen(a, ep)}
            className="group flex items-center gap-3 rounded-xl bg-[#0f1627]/60 p-2 text-left ring-1 ring-white/[0.05] transition hover:bg-[#131c32] hover:ring-cyan-400/30"
          >
            <span className="relative h-12 w-[5.2rem] shrink-0 overflow-hidden rounded-lg bg-slate-800">
              <img src={img} alt="" loading="lazy" className="h-full w-full object-cover transition group-hover:scale-105" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block truncate text-[13px] font-bold text-white transition group-hover:text-cyan-300">
                {a.titleEnglish || a.title}
              </span>
              <span className="block text-[11px] text-slate-400">EP {ep}</span>
            </span>
            <span className="shrink-0 text-right text-[11px] leading-tight text-slate-400">
              <span className="block font-semibold text-slate-300">{day}</span>
              {time}
            </span>
          </button>
        );
      })}
    </div>
  );
}

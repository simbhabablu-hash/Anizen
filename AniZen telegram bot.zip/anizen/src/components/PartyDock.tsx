import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Users, X, Send, Crown, Copy, Check, LogOut, AlertTriangle, Play } from "lucide-react";
import type { WatchParty } from "../hooks/useWatchParty";
import { copyText, partyLink } from "../utils/share";

interface Props {
  party: WatchParty;
  /** User is on the watch page right now */
  onWatchPage: boolean;
}

/** Floating Watch Party button + side panel (members, chat, status). Only exists inside a room. */
export default function PartyDock({ party, onWatchPage }: Props) {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [seen, setSeen] = useState(0);
  const [copied, setCopied] = useState(false);
  const listRef = useRef<HTMLDivElement>(null);

  const room = party.room;

  useEffect(() => {
    if (open) {
      setSeen(party.chat.length);
      listRef.current?.scrollTo({ top: listRef.current.scrollHeight });
    }
  }, [open, party.chat.length]);

  if (!room) return null;

  const unread = open ? 0 : Math.max(0, party.chat.length - seen);
  const people = party.members.length + 1;
  const dot =
    party.status === "live" ? "bg-emerald-400" : party.status === "connecting" ? "bg-amber-400 animate-pulse" : "bg-rose-500";

  const send = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    party.sendChat(text);
    setText("");
  };

  const copyCode = async () => {
    const link = partyLink(room.code);
    if (await copyText(`${room.code}\n${link}`)) {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1500);
    }
  };

  const notes: string[] = [];
  if (party.error) notes.push(party.error);
  if (party.notice) notes.push(party.notice);
  if (onWatchPage && !party.videoAttached) {
    notes.push("Is episode ka source embed (YouTube/Drive) hai — saath me khulega, par play/pause sync nahi ho sakta.");
  }
  if (!onWatchPage && !party.roomAnimeId) {
    notes.push(room.host ? "Koi anime kholo — sab ke phone par wahi khul jayega." : "Host abhi koi anime nahi chala raha. Wait karo...");
  }

  return (
    <div className="party-dock fixed bottom-20 right-3 z-[60] flex flex-col items-end gap-2 sm:right-5 md:bottom-4">
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 16, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 12, scale: 0.97 }}
            transition={{ duration: 0.18 }}
            className="flex h-[min(30rem,70vh)] w-[min(22rem,calc(100vw-1.5rem))] flex-col overflow-hidden rounded-2xl bg-[#0d1424]/97 shadow-2xl shadow-black/60 ring-1 ring-white/12 backdrop-blur-xl"
          >
            {/* header */}
            <div className="flex items-center gap-2 border-b border-white/10 px-3 py-2.5">
              <span className={`h-2 w-2 shrink-0 rounded-full ${dot}`} />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-extrabold text-white">
                  Party <span className="font-mono tracking-widest text-cyan-400">{room.code}</span>
                </p>
                <p className="text-[11px] text-slate-400">
                  {people} log · {room.host ? "tum host ho" : "member"}
                </p>
              </div>
              <button onClick={copyCode} title="Code + link copy" className="rounded-lg p-1.5 text-slate-300 hover:bg-white/10">
                {copied ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
              </button>
              <button
                onClick={() => {
                  party.leave();
                  setOpen(false);
                }}
                title="Leave party"
                className="rounded-lg p-1.5 text-rose-300 hover:bg-rose-600/20"
              >
                <LogOut className="h-4 w-4" />
              </button>
              <button onClick={() => setOpen(false)} title="Close" className="rounded-lg p-1.5 text-slate-300 hover:bg-white/10">
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* tap to sync */}
            {party.blocked && (
              <button
                onClick={party.tapToSync}
                className="flex items-center justify-center gap-2 bg-cyan-500 px-3 py-2.5 text-sm font-extrabold text-slate-950"
              >
                <Play className="h-4 w-4 fill-slate-950" /> Tap karo — saath me play karo
              </button>
            )}

            {/* notes */}
            {notes.length > 0 && (
              <div className="space-y-1 border-b border-white/10 bg-amber-500/10 px-3 py-2">
                {notes.map((n, i) => (
                  <p key={i} className="flex items-start gap-1.5 text-[11px] leading-snug text-amber-200">
                    <AlertTriangle className="mt-0.5 h-3 w-3 shrink-0 text-amber-400" />
                    <span>{n}</span>
                  </p>
                ))}
              </div>
            )}

            {/* members */}
            <div className="flex flex-wrap gap-1.5 border-b border-white/10 px-3 py-2">
              <span className="flex items-center gap-1 rounded-full bg-blue-600/25 px-2 py-0.5 text-[11px] font-semibold text-blue-200">
                {room.host && <Crown className="h-3 w-3 text-amber-400" />}
                {party.selfName || "Tum"} (tum)
              </span>
              {party.members.map((m) => (
                <span key={m.id} className="flex items-center gap-1 rounded-full bg-white/8 px-2 py-0.5 text-[11px] font-semibold text-slate-200">
                  {m.host && <Crown className="h-3 w-3 text-amber-400" />}
                  {m.name}
                </span>
              ))}
            </div>

            {/* chat */}
            <div ref={listRef} className="flex-1 space-y-2 overflow-y-auto px-3 py-3">
              {party.chat.length === 0 ? (
                <p className="py-6 text-center text-xs text-slate-500">Abhi koi message nahi. Pehla message bhejo 👋</p>
              ) : (
                party.chat.map((c) => (
                  <div key={c.id} className={`flex flex-col ${c.mine ? "items-end" : "items-start"}`}>
                    <span className="mb-0.5 text-[10px] font-semibold text-slate-500">{c.mine ? "Tum" : c.name}</span>
                    <span
                      className={`max-w-[85%] break-words rounded-2xl px-3 py-1.5 text-[13px] ${
                        c.mine ? "rounded-br-md bg-blue-600 text-white" : "rounded-bl-md bg-white/10 text-slate-100"
                      }`}
                    >
                      {c.text}
                    </span>
                  </div>
                ))
              )}
            </div>

            <form onSubmit={send} className="flex items-center gap-2 border-t border-white/10 p-2.5">
              <input
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Message likho..."
                maxLength={300}
                className="min-w-0 flex-1 rounded-full border border-white/10 bg-white/[0.06] px-4 py-2 text-sm text-white placeholder-slate-500 outline-none focus:border-cyan-400/50"
              />
              <button
                type="submit"
                aria-label="Send"
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-blue-600 text-white transition hover:bg-blue-500 disabled:opacity-40"
                disabled={!text.trim()}
              >
                <Send className="h-4 w-4 -translate-x-px translate-y-px" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <button
        onClick={() => setOpen((o) => !o)}
        className="relative flex items-center gap-2 rounded-full bg-gradient-to-r from-blue-600 to-cyan-500 py-2.5 pl-3.5 pr-4 text-sm font-extrabold text-white shadow-xl shadow-blue-600/40 transition hover:brightness-110 active:scale-95"
      >
        <span className={`h-2 w-2 rounded-full ${dot}`} />
        <Users className="h-4 w-4" />
        <span className="font-mono tracking-wider">{room.code}</span>
        <span className="rounded-full bg-black/25 px-1.5 text-[11px]">{people}</span>
        {unread > 0 && (
          <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-black text-white">
            {unread > 9 ? "9+" : unread}
          </span>
        )}
      </button>
    </div>
  );
}

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { X, Users, Copy, Check, LogOut, Link2, MessageCircle, Loader2, PartyPopper, Hash } from "lucide-react";
import type { WatchParty } from "../hooks/useWatchParty";
import { savedPartyName } from "../hooks/useWatchParty";
import { cleanCode, CODE_LEN } from "../store/party";
import { copyText, partyLink, whatsappUrl } from "../utils/share";

interface Props {
  party: WatchParty;
  prefillCode?: string;
  onClose: () => void;
}

export default function PartyModal({ party, prefillCode, onClose }: Props) {
  const [tab, setTab] = useState<"create" | "join">(prefillCode ? "join" : "create");
  const [name, setName] = useState(() => savedPartyName());
  const [code, setCode] = useState(prefillCode ? cleanCode(prefillCode) : "");
  const [copied, setCopied] = useState("");

  useEffect(() => {
    if (prefillCode) {
      setCode(cleanCode(prefillCode));
      setTab("join");
    }
  }, [prefillCode]);

  const copy = async (text: string, key: string) => {
    if (await copyText(text)) {
      setCopied(key);
      window.setTimeout(() => setCopied(""), 1600);
    } else {
      window.prompt("Copy this:", text);
    }
  };

  const inRoom = party.room;
  const link = inRoom ? partyLink(inRoom.code) : "";

  const inputCls =
    "w-full rounded-xl border border-white/10 bg-white/[0.06] px-4 py-3 text-sm text-white placeholder-slate-500 outline-none focus:border-cyan-400/60";

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
      className="fixed inset-0 z-[70] flex items-end justify-center bg-black/75 p-0 backdrop-blur-sm sm:items-center sm:p-6"
    >
      <motion.div
        initial={{ y: 60, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 40, opacity: 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md overflow-hidden rounded-t-3xl bg-[#0d1424] p-5 ring-1 ring-white/10 sm:rounded-3xl"
      >
        <div className="mb-4 flex items-center justify-between">
          <h3 className="flex items-center gap-2 text-base font-extrabold text-white">
            <PartyPopper className="h-5 w-5 text-cyan-400" /> Watch Party
          </h3>
          <button onClick={onClose} aria-label="Close" className="rounded-full bg-white/5 p-1.5 text-slate-300 hover:bg-white/10">
            <X className="h-4 w-4" />
          </button>
        </div>

        {inRoom ? (
          /* ------------------------- already in a room ------------------------- */
          <div className="space-y-4">
            <div className="rounded-2xl bg-gradient-to-br from-blue-600/20 to-cyan-500/10 p-4 text-center ring-1 ring-cyan-400/25">
              <p className="text-[11px] font-bold uppercase tracking-[0.25em] text-slate-400">Party code</p>
              <p className="mt-1 font-mono text-4xl font-black tracking-[0.3em] text-white">{inRoom.code}</p>
              <p className="mt-1 text-xs text-slate-400">
                {inRoom.host ? "Tum host ho" : "Tum member ho"} ·{" "}
                {party.status === "live" ? `${party.members.length + 1} log` : party.status === "connecting" ? "connect ho raha hai..." : "connection problem"}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => copy(inRoom.code, "code")}
                className="flex items-center justify-center gap-2 rounded-xl bg-blue-600 py-2.5 text-sm font-bold text-white transition hover:bg-blue-500"
              >
                {copied === "code" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                {copied === "code" ? "Copied!" : "Copy code"}
              </button>
              <button
                onClick={() => copy(link, "link")}
                className="flex items-center justify-center gap-2 rounded-xl bg-white/10 py-2.5 text-sm font-bold text-white ring-1 ring-white/15 transition hover:bg-white/15"
              >
                {copied === "link" ? <Check className="h-4 w-4 text-emerald-400" /> : <Link2 className="h-4 w-4" />}
                {copied === "link" ? "Copied!" : "Copy link"}
              </button>
              <a
                href={whatsappUrl(`AniZen Watch Party me aao! 🎬\nCode: ${inRoom.code}\n${link}`)}
                target="_blank"
                rel="noreferrer"
                className="col-span-2 flex items-center justify-center gap-2 rounded-xl bg-[#25D366]/15 py-2.5 text-sm font-bold text-[#25D366] ring-1 ring-[#25D366]/30 transition hover:bg-[#25D366] hover:text-white"
              >
                <MessageCircle className="h-4 w-4" /> WhatsApp par bhejo
              </a>
            </div>

            {party.error && <p className="text-sm font-semibold text-rose-400">{party.error}</p>}

            <p className="rounded-xl bg-white/5 p-3 text-xs leading-relaxed text-slate-400">
              Ab koi bhi anime kholo aur play karo — sabka video saath me chalega. Kisi ne pause/seek kiya to sab ka
              hoga. Chat neeche-right ke <b className="text-slate-200">Party</b> button se khulta hai.
            </p>

            <div className="flex gap-2">
              <button
                onClick={onClose}
                className="flex-1 rounded-xl bg-white/10 py-2.5 text-sm font-bold text-white ring-1 ring-white/15 hover:bg-white/15"
              >
                Done
              </button>
              <button
                onClick={() => {
                  party.leave();
                  onClose();
                }}
                className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-rose-600/20 py-2.5 text-sm font-bold text-rose-300 ring-1 ring-rose-500/30 hover:bg-rose-600 hover:text-white"
              >
                <LogOut className="h-4 w-4" /> Leave party
              </button>
            </div>
          </div>
        ) : (
          /* ------------------------- create / join ------------------------- */
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-1 rounded-xl bg-white/5 p-1">
              {(["create", "join"] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => {
                    setTab(t);
                    party.clearError();
                  }}
                  className={`rounded-lg py-2 text-sm font-bold transition ${
                    tab === t ? "bg-blue-600 text-white shadow" : "text-slate-400 hover:text-white"
                  }`}
                >
                  {t === "create" ? "Party banao" : "Code se judo"}
                </button>
              ))}
            </div>

            <div>
              <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-wider text-slate-400">Tumhara naam</label>
              <input value={name} onChange={(e) => setName(e.target.value.slice(0, 20))} placeholder="Naam" className={inputCls} />
            </div>

            {tab === "join" && (
              <div>
                <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-wider text-slate-400">Party code</label>
                <div className="relative">
                  <Hash className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
                  <input
                    value={code}
                    onChange={(e) => setCode(cleanCode(e.target.value))}
                    placeholder="ABC123"
                    inputMode="text"
                    autoCapitalize="characters"
                    autoComplete="off"
                    maxLength={CODE_LEN}
                    className={`${inputCls} pl-10 text-center font-mono text-lg font-bold tracking-[0.35em]`}
                  />
                </div>
              </div>
            )}

            {party.error && <p className="text-sm font-semibold text-rose-400">{party.error}</p>}

            {tab === "create" ? (
              <button
                onClick={() => party.create(name)}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 py-3 text-sm font-extrabold uppercase tracking-wide text-white shadow-lg shadow-blue-600/30 transition hover:brightness-110 active:scale-[0.98]"
              >
                <Users className="h-4 w-4" /> Code banao
              </button>
            ) : (
              <button
                onClick={() => {
                  if (party.join(code, name)) onClose();
                }}
                disabled={code.length !== CODE_LEN}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 py-3 text-sm font-extrabold uppercase tracking-wide text-white shadow-lg shadow-blue-600/30 transition hover:brightness-110 active:scale-[0.98] disabled:opacity-40"
              >
                {party.status === "connecting" ? <Loader2 className="h-4 w-4 animate-spin" /> : <Users className="h-4 w-4" />}
                Party join karo
              </button>
            )}

            <p className="text-center text-[11px] leading-relaxed text-slate-500">
              Code banake doston ko do. Wo yahin <b>"Code se judo"</b> me daalenge to sabka video ek saath chalega.
            </p>
          </div>
        )}
      </motion.div>
    </motion.div>
  );
}

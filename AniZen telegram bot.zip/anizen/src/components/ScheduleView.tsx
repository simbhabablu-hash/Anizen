import { useMemo, useState } from "react";
import { CalendarClock, CalendarX } from "lucide-react";
import Section from "./Section";
import type { Anime } from "../types";
import { WEEK_DAYS, lastEpisodeNumber, todayDayId } from "../utils/format";

interface Props {
  anime: Anime[];
  onOpen: (a: Anime) => void;
  onWatch: (a: Anime, ep?: number) => void;
}

const timeKey = (t?: string) => (t && /^\d{1,2}:\d{2}/.test(t) ? t.padStart(5, "0") : "99:99");

export default function ScheduleView({ anime, onOpen, onWatch }: Props) {
  const today = todayDayId();
  const [day, setDay] = useState(today);

  const airing = useMemo(() => anime.filter((a) => a.status === "Ongoing"), [anime]);

  const byDay = useMemo(() => {
    const map = new Map<string, Anime[]>();
    for (const d of WEEK_DAYS) map.set(d.id, []);
    for (const a of airing) {
      if (a.airDay && map.has(a.airDay)) map.get(a.airDay)!.push(a);
    }
    map.forEach((list) => list.sort((a, b) => timeKey(a.airTime).localeCompare(timeKey(b.airTime))));
    return map;
  }, [airing]);

  const unscheduled = useMemo(() => airing.filter((a) => !a.airDay || !byDay.has(a.airDay)), [airing, byDay]);
  const upcoming = useMemo(() => anime.filter((a) => a.status === "Upcoming"), [anime]);

  const list = byDay.get(day) ?? [];
  const dayInfo = WEEK_DAYS.find((d) => d.id === day)!;

  return (
    <Section title="Schedule" subtitle="Weekly airing schedule">
      {/* day tabs */}
      <div className="-mx-4 mb-5 flex gap-2 overflow-x-auto px-4 pb-1 [scrollbar-width:none] sm:mx-0 sm:px-0 [&::-webkit-scrollbar]:hidden">
        {WEEK_DAYS.map((d) => {
          const n = byDay.get(d.id)?.length ?? 0;
          const on = d.id === day;
          return (
            <button
              key={d.id}
              onClick={() => setDay(d.id)}
              className={`relative flex min-w-[4.2rem] flex-1 flex-col items-center rounded-xl px-3 py-2.5 transition ${
                on
                  ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30"
                  : "bg-white/[0.05] text-slate-300 ring-1 ring-white/10 hover:bg-white/10"
              }`}
            >
              <span className="text-[13px] font-bold">{d.short}</span>
              <span className={`text-[10px] ${on ? "text-blue-100" : "text-slate-500"}`}>
                {n} {n === 1 ? "show" : "shows"}
              </span>
              {d.id === today && (
                <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-cyan-400 shadow-[0_0_8px_#22d3ee]" />
              )}
            </button>
          );
        })}
      </div>

      <h3 className="mb-3 flex items-center gap-2 text-sm font-bold text-white">
        <CalendarClock className="h-4 w-4 text-cyan-400" />
        {dayInfo.full}
        {day === today && <span className="rounded bg-cyan-400/15 px-1.5 py-0.5 text-[10px] font-bold uppercase text-cyan-300">Today</span>}
      </h3>

      {list.length === 0 ? (
        <div className="flex flex-col items-center gap-2 rounded-2xl bg-white/[0.03] py-10 text-center text-slate-400 ring-1 ring-white/5">
          <CalendarX className="h-9 w-9" />
          <p className="text-sm font-semibold">{dayInfo.full} ko koi anime schedule nahi hai</p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {list.map((a) => (
            <Row key={a.id} a={a} onOpen={onOpen} onWatch={onWatch} />
          ))}
        </div>
      )}

      {unscheduled.length > 0 && (
        <div className="mt-8">
          <h3 className="mb-3 text-sm font-bold uppercase tracking-wide text-slate-300">
            Airing — din abhi announce nahi hua
          </h3>
          <div className="space-y-2.5">
            {unscheduled.map((a) => (
              <Row key={a.id} a={a} onOpen={onOpen} onWatch={onWatch} />
            ))}
          </div>
        </div>
      )}

      {upcoming.length > 0 && (
        <div className="mt-8">
          <h3 className="mb-3 text-sm font-bold uppercase tracking-wide text-slate-300">Coming soon</h3>
          <div className="space-y-2.5">
            {upcoming.map((a) => (
              <Row key={a.id} a={a} onOpen={onOpen} onWatch={onWatch} soon />
            ))}
          </div>
        </div>
      )}
    </Section>
  );
}

function Row({
  a,
  onOpen,
  onWatch,
  soon,
}: {
  a: Anime;
  onOpen: (a: Anime) => void;
  onWatch: (a: Anime, ep?: number) => void;
  soon?: boolean;
}) {
  const img = a.thumbnail || a.banner || a.poster;
  const eps = a.episodes?.length ?? 0;
  return (
    <div className="flex items-center gap-3 rounded-xl bg-[#0f1627]/70 p-2.5 ring-1 ring-white/[0.06] transition hover:bg-[#131c32] hover:ring-cyan-400/30">
      <div className="w-14 shrink-0 text-center">
        <p className="text-[15px] font-extrabold tabular-nums text-cyan-300">{a.airTime || "—"}</p>
      </div>
      <button onClick={() => onOpen(a)} className="relative h-14 w-24 shrink-0 overflow-hidden rounded-lg bg-slate-800">
        <img src={img} alt="" loading="lazy" className="h-full w-full object-cover" />
      </button>
      <button onClick={() => onOpen(a)} className="min-w-0 flex-1 text-left">
        <p className="truncate text-[13px] font-bold text-white">{a.titleEnglish || a.title}</p>
        <p className="truncate text-[11px] text-slate-400">
          {soon ? "Coming soon" : eps ? `Latest: EP ${lastEpisodeNumber(a)}` : "No episodes yet"}
          {a.genres?.length ? ` · ${a.genres.slice(0, 2).join(", ")}` : ""}
        </p>
      </button>
      {!soon && eps > 0 && (
        <button
          onClick={() => onWatch(a, lastEpisodeNumber(a))}
          className="shrink-0 rounded-md bg-blue-600 px-3.5 py-2 text-[11px] font-bold uppercase tracking-wide text-white transition hover:bg-blue-500"
        >
          Watch
        </button>
      )}
    </div>
  );
}

import { useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import AnimeCard from "./AnimeCard";
import type { Anime } from "../types";
import type { GridHandlers } from "./AnimeGrid";

/** One horizontal, swipeable row of anime cards (Trending, Top Airing, ...). */
export default function ScrollRow({
  items,
  onSelect,
  onWatch,
  onToggleList,
  inListFn,
}: { items: Anime[] } & GridHandlers) {
  const ref = useRef<HTMLDivElement>(null);

  const scroll = (dir: 1 | -1) => {
    const el = ref.current;
    if (el) el.scrollBy({ left: dir * el.clientWidth * 0.85, behavior: "smooth" });
  };

  return (
    <div className="group/row relative">
      <div
        ref={ref}
        className="-mx-4 flex snap-x snap-proximity gap-3 overflow-x-auto px-4 pb-2 [scrollbar-width:none] sm:mx-0 sm:gap-4 sm:px-0 [&::-webkit-scrollbar]:hidden"
      >
        {items.map((a, i) => (
          <div key={a.id} className="w-[8.6rem] shrink-0 snap-start sm:w-44">
            <AnimeCard
              anime={a}
              index={i}
              onClick={onSelect}
              onWatch={onWatch}
              onToggleList={onToggleList}
              inList={inListFn(a.id)}
            />
          </div>
        ))}
      </div>

      {items.length > 4 && (
        <>
          <button
            onClick={() => scroll(-1)}
            aria-label="Scroll left"
            className="absolute -left-3 top-[38%] z-10 hidden h-9 w-9 items-center justify-center rounded-full border border-white/15 bg-[#0a0e1a]/90 text-white opacity-0 shadow-lg backdrop-blur transition hover:bg-cyan-500 hover:text-slate-950 group-hover/row:opacity-100 lg:flex"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <button
            onClick={() => scroll(1)}
            aria-label="Scroll right"
            className="absolute -right-3 top-[38%] z-10 hidden h-9 w-9 items-center justify-center rounded-full border border-white/15 bg-[#0a0e1a]/90 text-white opacity-0 shadow-lg backdrop-blur transition hover:bg-cyan-500 hover:text-slate-950 group-hover/row:opacity-100 lg:flex"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </>
      )}
    </div>
  );
}

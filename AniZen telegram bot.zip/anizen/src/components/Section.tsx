import type { ReactNode } from "react";

interface Props {
  title: string;
  subtitle?: string;
  icon?: ReactNode;
  children: ReactNode;
  action?: ReactNode;
}

export default function Section({ title, subtitle, icon, children, action }: Props) {
  return (
    <section className="relative z-10 mx-auto max-w-7xl px-4 py-5 sm:px-6 sm:py-7">
      <div className="mb-4 flex items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          {icon}
          <div>
            <h2 className="text-sm font-extrabold uppercase tracking-wide text-white sm:text-lg">{title}</h2>
            {subtitle && <p className="mt-0.5 text-xs text-slate-400">{subtitle}</p>}
          </div>
        </div>
        {action && <div className="flex shrink-0 items-center gap-4">{action}</div>}
      </div>
      {children}
    </section>
  );
}

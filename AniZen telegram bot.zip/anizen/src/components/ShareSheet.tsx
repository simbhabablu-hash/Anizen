import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { motion } from "framer-motion";
import { X, Copy, Check, Share2, MessageCircle, Send, Link2 } from "lucide-react";
import { copyText, nativeShare, whatsappUrl, telegramUrl } from "../utils/share";

interface Props {
  title: string;
  text: string;
  url: string;
  onClose: () => void;
}

export default function ShareSheet({ title, text, url, onClose }: Props) {
  const [copied, setCopied] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previousOverflow;
    };
  }, []);

  const doCopy = async () => {
    const ok = await copyText(url);
    if (ok) {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } else {
      window.prompt("Copy this link:", url);
    }
  };

  const doNative = async () => {
    const r = await nativeShare(title, text, url);
    if (r === "unsupported") doCopy();
    else if (r === "shared") onClose();
  };

  if (!mounted) return null;

  // IMPORTANT: This is rendered directly under <body>. AnimeModal uses a
  // transformed Framer Motion container, and a fixed child inside that
  // container can otherwise be positioned relative to the modal instead of
  // the actual viewport, which was clipping the share sheet on phones.
  return createPortal(
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
      className="share-sheet-overlay fixed inset-0 z-[9999] flex items-end justify-center bg-black/75 p-0 backdrop-blur-sm sm:items-center sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-label="Share"
    >
      <motion.div
        initial={{ y: 80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 60, opacity: 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        onClick={(e) => e.stopPropagation()}
        className="share-sheet-panel relative flex w-full max-w-lg flex-col overflow-hidden rounded-t-3xl bg-slate-900 px-4 pt-4 ring-1 ring-white/10 sm:max-h-[90vh] sm:rounded-3xl sm:px-5 sm:pb-5"
        style={{
          maxHeight: "calc(100dvh - env(safe-area-inset-top) - env(safe-area-inset-bottom) - 8px)",
          paddingBottom: "max(16px, env(safe-area-inset-bottom))",
        }}
      >
        <div className="mx-auto mb-3 h-1.5 w-10 shrink-0 rounded-full bg-white/15 sm:hidden" />

        <div className="mb-4 flex shrink-0 items-center justify-between">
          <h3 className="flex items-center gap-2 text-base font-black text-white">
            <Share2 className="h-4 w-4 text-blue-400" /> Share
          </h3>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close share dialog"
            className="rounded-full bg-white/5 p-2 text-slate-300 hover:bg-white/10"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="share-sheet-scroll min-h-0 flex-1 overflow-y-auto overscroll-contain pr-0 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          <p className="mb-2 line-clamp-2 text-base font-semibold leading-snug text-white">{title}</p>
          <div className="mb-4 flex min-h-11 items-center gap-2 rounded-xl bg-white/5 px-3 py-2 ring-1 ring-white/10">
            <Link2 className="h-4 w-4 shrink-0 text-slate-400" />
            <span className="min-w-0 truncate text-xs text-slate-400">{url}</span>
          </div>

          <div className="grid grid-cols-1 gap-2 pb-2 min-[380px]:grid-cols-2">
            <button
              type="button"
              onClick={doCopy}
              className="flex min-h-12 items-center justify-center gap-2 rounded-xl bg-blue-600 px-3 py-3 text-sm font-bold text-white transition hover:bg-blue-500 active:scale-[.98]"
            >
              {copied ? <Check className="h-5 w-5" /> : <Copy className="h-5 w-5" />}
              {copied ? "Copied!" : "Copy Link"}
            </button>
            <button
              type="button"
              onClick={doNative}
              className="flex min-h-12 items-center justify-center gap-2 rounded-xl bg-white/10 px-3 py-3 text-sm font-bold text-white ring-1 ring-white/15 transition hover:bg-white/15 active:scale-[.98]"
            >
              <Share2 className="h-5 w-5" /> More...
            </button>
            <a
              href={whatsappUrl(`${text}\n${url}`)}
              target="_blank"
              rel="noreferrer"
              className="flex min-h-12 items-center justify-center gap-2 rounded-xl bg-[#25D366]/15 px-3 py-3 text-sm font-bold text-[#25D366] ring-1 ring-[#25D366]/30 transition hover:bg-[#25D366] hover:text-white active:scale-[.98]"
            >
              <MessageCircle className="h-5 w-5" /> WhatsApp
            </a>
            <a
              href={telegramUrl(url, text)}
              target="_blank"
              rel="noreferrer"
              className="flex min-h-12 items-center justify-center gap-2 rounded-xl bg-[#229ED9]/15 px-3 py-3 text-sm font-bold text-[#229ED9] ring-1 ring-[#229ED9]/30 transition hover:bg-[#229ED9] hover:text-white active:scale-[.98]"
            >
              <Send className="h-5 w-5" /> Telegram
            </a>
          </div>
        </div>
      </motion.div>
    </motion.div>,
    document.body,
  );
}

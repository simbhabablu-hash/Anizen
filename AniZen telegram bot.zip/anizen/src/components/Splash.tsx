import { useEffect } from "react";
import { motion } from "framer-motion";

interface Props {
  onDone: () => void;
}

const LETTERS = "ANIZEN".split("");

export default function Splash({ onDone }: Props) {
  useEffect(() => {
    const t = setTimeout(onDone, 3200);
    return () => clearTimeout(t);
  }, [onDone]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6 }}
      className="fixed inset-0 z-[100] flex items-center justify-center overflow-hidden bg-[#030405]"
    >
      {/* Aurora blobs */}
      <motion.div
        aria-hidden
        className="absolute -right-32 -top-20 h-[70vh] w-[60vw] rounded-full bg-blue-600/25 blur-[110px]"
        animate={{ x: [0, -40, 0], y: [0, 60, 0], opacity: [0.5, 0.9, 0.5] }}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        aria-hidden
        className="absolute -bottom-32 left-1/4 h-[60vh] w-[50vw] rounded-full bg-sky-500/20 blur-[120px]"
        animate={{ x: [0, 50, 0], y: [0, -50, 0], opacity: [0.4, 0.8, 0.4] }}
        transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
      />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(37,99,235,0.18),transparent_60%)]" />

      {/* Logo text */}
      <div className="relative flex flex-col items-center">
        <div className="flex">
          {LETTERS.map((l, i) => (
            <motion.span
              key={i}
              initial={{ opacity: 0, y: 40, filter: "blur(14px)", scale: 0.8 }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)", scale: 1 }}
              transition={{ delay: 0.25 + i * 0.12, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
              className="text-[15vw] font-black leading-none tracking-tight text-blue-500 sm:text-8xl"
              style={{
                textShadow:
                  "0 0 18px rgba(59,130,246,0.85), 0 0 48px rgba(37,99,235,0.6), 0 0 90px rgba(29,78,216,0.45)",
              }}
            >
              {l}
            </motion.span>
          ))}
        </div>

        {/* glow underline */}
        <motion.div
          initial={{ scaleX: 0, opacity: 0 }}
          animate={{ scaleX: 1, opacity: 1 }}
          transition={{ delay: 1.2, duration: 0.9, ease: "easeOut" }}
          className="mt-5 h-[3px] w-full origin-center rounded-full bg-gradient-to-r from-transparent via-blue-400 to-transparent shadow-[0_0_20px_rgba(59,130,246,0.9)]"
        />

        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.6, duration: 0.6 }}
          className="mt-4 text-xs font-semibold uppercase tracking-[0.5em] text-blue-300/80"
        >
          Anime Streaming
        </motion.p>
      </div>
    </motion.div>
  );
}

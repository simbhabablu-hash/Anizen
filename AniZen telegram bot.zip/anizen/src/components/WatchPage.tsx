import { useEffect, useMemo, useState } from "react";
import { AnimatePresence } from "framer-motion";
import {
  ArrowLeft,
  Star,
  Plus,
  Check,
  Play,
  ListVideo,
  Info,
  Share2,
  AlertTriangle,
} from "lucide-react";
import type { Anime, Episode } from "../types";
import MediaPlayer from "./MediaPlayer";
import ShareSheet from "./ShareSheet";
import { watchLink } from "../utils/share";

interface Props {
  anime: Anime;
  onBack: () => void;
  inList: boolean;
  onToggleList: (a: Anime) => void;
  onWatch: (a: Anime, ep: number) => void;
  initialEpisode?: number;
  /** Hands the <video> element to Watch Party so players can be kept in sync. Must be stable. */
  onVideoEl?: (el: HTMLVideoElement | null) => void;
  /** Real watch progress for History */
  onProgress?: (animeId: string, episode: number, position: number, duration: number) => void;
  /** Seconds to resume from for an episode (0 = start). Must be stable. */
  getResume?: (animeId: string, episode: number) => number;
}

export default function WatchPage({
  anime,
  onBack,
  inList,
  onToggleList,
  onWatch,
  initialEpisode = 1,
  onVideoEl,
  onProgress,
  getResume,
}: Props) {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [tab, setTab] = useState<"episodes" | "details">("episodes");
  const [showShare, setShowShare] = useState(false);

  const episodes: Episode[] = anime.episodes?.length
    ? anime.episodes
    : [];

  const current = episodes[currentIdx];

  useEffect(() => {
    window.scrollTo({ top: 0 });
    const idx = Math.max(
      0,
      episodes.findIndex((e) => e.number === initialEpisode),
    );
    setCurrentIdx(idx);
    onWatch(anime, episodes[idx]?.number ?? 1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [anime.id]);

  // Someone in a Watch Party moved to another episode of this same anime
  useEffect(() => {
    const idx = episodes.findIndex((e) => e.number === initialEpisode);
    if (idx < 0 || idx === currentIdx) return;
    setCurrentIdx(idx);
    onWatch(anime, initialEpisode);
    window.scrollTo({ top: 0, behavior: "smooth" });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialEpisode]);

  const poster = anime.banner || anime.thumbnail || anime.poster;

  const selectEpisode = (idx: number) => {
    setCurrentIdx(idx);
    onWatch(anime, episodes[idx].number);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Was this episode's video uploaded from a phone's gallery and never sent online?
  // Then its URL is just a local "idb://..." reference that other devices cannot play.
  const isLocalRef = !!current && current.videoUrl.startsWith("idb://");
  const hasPlayableUrl = !!current && !!current.videoUrl && !isLocalRef;

  const player = useMemo(() => {
    if (!current) {
      return (
        <div className="relative flex h-full w-full items-center justify-center">
          <img src={poster} alt={anime.title} className="absolute inset-0 h-full w-full object-cover opacity-40" />
          <div className="relative z-10 flex flex-col items-center gap-3 text-center">
            <span className="flex h-16 w-16 items-center justify-center rounded-full bg-blue-600 shadow-lg shadow-blue-600/40">
              <Play className="h-7 w-7 translate-x-0.5 fill-white text-white" />
            </span>
            <p className="max-w-xs text-sm text-slate-300">No episodes added yet for this anime.</p>
          </div>
        </div>
      );
    }

    if (!hasPlayableUrl) {
      return (
        <div className="relative flex h-full w-full items-center justify-center overflow-hidden">
          <img
            src={current.thumbnail || poster}
            alt={anime.title}
            className="absolute inset-0 h-full w-full scale-105 object-cover opacity-30 blur-sm"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/70 to-black/50" />
          <div className="relative z-10 flex max-w-md flex-col items-center gap-3 px-6 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-full bg-amber-500/20 ring-1 ring-amber-500/40">
              <AlertTriangle className="h-7 w-7 text-amber-400" />
            </span>
            <h3 className="text-lg font-black text-white">Video link missing</h3>
            <p className="text-sm leading-relaxed text-slate-300">
              {isLocalRef
                ? "Ye episode admin ke phone se directly upload kiya gaya tha, isliye doosre devices par nahi chalega. Admin se kaho ke episode me video ka URL (MP4/YouTube) daalein."
                : "Is episode me abhi tak koi video URL add nahi hua. Admin se kaho ke episode me video link daalein."}
            </p>
          </div>
        </div>
      );
    }

    return (
      <MediaPlayer
        key={`${current.id}:${current.videoUrl}`}
        src={current.videoUrl}
        embed={current.videoType === "embed"}
        qualities={current.qualities}
        onVideoEl={onVideoEl}
        onProgress={(pos, dur) => onProgress?.(anime.id, current.number, pos, dur)}
        startAt={getResume ? getResume(anime.id, current.number) : 0}
        poster={current.thumbnail || poster}
        title={`${anime.titleEnglish || anime.title} — Episode ${current.number}: ${current.title}`}
        onEnded={() => {
          if (currentIdx < episodes.length - 1) selectEpisode(currentIdx + 1);
        }}
      />
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [current, hasPlayableUrl, isLocalRef, poster, anime.id, anime.title, anime.titleEnglish, currentIdx, episodes.length, onVideoEl, onProgress, getResume]);

  const shareTitle = `${anime.titleEnglish || anime.title}${current ? ` — Episode ${current.number}` : ""}`;
  const shareUrl = watchLink(anime.id, current?.number);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
      <button
        onClick={onBack}
        className="mb-4 flex items-center gap-2 rounded-full bg-white/5 px-4 py-2 text-sm font-semibold text-slate-300 ring-1 ring-white/10 transition hover:bg-white/10 hover:text-white"
      >
        <ArrowLeft className="h-4 w-4" /> Back
      </button>

      <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
        <div>
          <div className="relative aspect-video w-full overflow-hidden rounded-2xl bg-black ring-1 ring-white/10">
            {player}
          </div>

          <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h1 className="text-xl font-black text-white sm:text-2xl">
                {anime.titleEnglish || anime.title}
              </h1>
              <p className="text-sm text-slate-400">
                {current
                  ? `Now Playing · Episode ${current.number}${episodes.length ? ` of ${episodes.length}` : ""}`
                  : "No episode"}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => onToggleList(anime)}
                className={`flex items-center gap-2 rounded-full px-4 py-2 text-sm font-bold transition ${
                  inList ? "bg-fuchsia-600 text-white" : "bg-white/5 text-white ring-1 ring-white/15 hover:bg-white/10"
                }`}
              >
                {inList ? <Check className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                {inList ? "In My List" : "My List"}
              </button>
              <button
                onClick={() => setShowShare(true)}
                className="flex items-center gap-2 rounded-full bg-white/5 px-4 py-2 text-sm font-bold text-white ring-1 ring-white/15 transition hover:bg-white/10"
              >
                <Share2 className="h-4 w-4" /> Share
              </button>
            </div>
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-3 text-sm text-slate-300">
            {anime.rating ? (
              <span className="flex items-center gap-1 font-bold text-amber-300">
                <Star className="h-4 w-4 fill-amber-400 text-amber-400" /> {anime.rating.toFixed(1)}
              </span>
            ) : null}
            {anime.type && <span className="rounded bg-white/5 px-2 py-0.5">{anime.type}</span>}
            {anime.year ? <span>{anime.year}</span> : null}
            <span className="text-slate-400">{anime.status}</span>
          </div>

          <div className="mt-3 flex flex-wrap gap-2">
            {anime.genres?.map((g) => (
              <span
                key={g}
                className="rounded-full bg-fuchsia-600/15 px-3 py-1 text-xs font-semibold text-fuchsia-300 ring-1 ring-fuchsia-500/25"
              >
                {g}
              </span>
            ))}
          </div>

          <p className="mt-4 max-w-3xl text-sm leading-relaxed text-slate-300">
            {anime.synopsis || "No synopsis available."}
          </p>
        </div>

        <div className="lg:sticky lg:top-20 lg:self-start">
          <div className="overflow-hidden rounded-2xl bg-slate-900/60 ring-1 ring-white/10">
            <div className="flex border-b border-white/10">
              <TabBtn active={tab === "episodes"} onClick={() => setTab("episodes")} icon={<ListVideo className="h-4 w-4" />}>
                Episodes
              </TabBtn>
              <TabBtn active={tab === "details"} onClick={() => setTab("details")} icon={<Info className="h-4 w-4" />}>
                Details
              </TabBtn>
            </div>

            {tab === "episodes" ? (
              <div className="max-h-[560px] overflow-y-auto p-3">
                {episodes.length === 0 ? (
                  <p className="py-10 text-center text-sm text-slate-400">No episodes yet.</p>
                ) : (
                  <div className="space-y-1.5">
                    {episodes.map((ep, idx) => (
                      <button
                        key={ep.id}
                        onClick={() => selectEpisode(idx)}
                        className={`flex w-full items-center gap-3 rounded-xl p-2 text-left transition ${
                          currentIdx === idx ? "bg-fuchsia-600/20 ring-1 ring-fuchsia-500/40" : "hover:bg-white/5"
                        }`}
                      >
                        <span className="relative h-12 w-20 shrink-0 overflow-hidden rounded-lg bg-white/10">
                          {ep.thumbnail ? (
                            <img src={ep.thumbnail} alt="" className="h-full w-full object-cover" />
                          ) : null}
                          <span className="absolute inset-0 flex items-center justify-center bg-black/30">
                            {currentIdx === idx ? (
                              <Play className="h-4 w-4 fill-white text-white" />
                            ) : (
                              <span className="text-sm font-black text-white">{ep.number}</span>
                            )}
                          </span>
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-sm font-semibold text-white">{ep.title}</span>
                          <span className="text-xs text-slate-500">
                            Episode {ep.number}
                            {ep.duration ? ` · ${ep.duration}` : ""}
                          </span>
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-3 p-4 text-sm">
                <DetailRow label="Title" value={anime.title} />
                <DetailRow label="Type" value={anime.type} />
                <DetailRow label="Episodes" value={String(anime.episodes?.length ?? 0)} />
                <DetailRow label="Status" value={anime.status} />
                <DetailRow label="Year" value={anime.year ? String(anime.year) : null} />
                <DetailRow label="Rating" value={anime.rating ? anime.rating.toFixed(1) : null} />
                <DetailRow label="Studio" value={anime.studio} />
              </div>
            )}
          </div>
        </div>
      </div>

      <AnimatePresence>
        {showShare && (
          <ShareSheet
            title={shareTitle}
            text={`Dekho "${shareTitle}" AniZen par! 🔥`}
            url={shareUrl}
            onClose={() => setShowShare(false)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function TabBtn({
  active,
  onClick,
  icon,
  children,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-1 items-center justify-center gap-2 py-3 text-sm font-bold transition ${
        active ? "bg-white/5 text-fuchsia-400" : "text-slate-400 hover:text-white"
      }`}
    >
      {icon}
      {children}
    </button>
  );
}

function DetailRow({ label, value }: { label: string; value: string | null | undefined }) {
  if (!value) return null;
  return (
    <div className="flex justify-between gap-4 border-b border-white/5 pb-2">
      <span className="text-slate-500">{label}</span>
      <span className="text-right font-semibold text-white">{value}</span>
    </div>
  );
}

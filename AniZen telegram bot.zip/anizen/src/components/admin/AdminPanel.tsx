import { useState } from "react";
import {
  Crown,
  Lock,
  LogOut,
  Plus,
  Pencil,
  Trash2,
  Film,
  Star,
  LayoutDashboard,
  ArrowLeft,
  RotateCcw,
  Home,
  Download,
  Upload,
} from "lucide-react";
import { useRef } from "react";
import type { Anime } from "../../types";
import { useAnimeStore } from "../../store/AnimeStore";
import { useResolvedUrl } from "../../hooks/useResolvedUrl";
import AnimeForm from "./AnimeForm";
import CloudPanel from "./CloudPanel";
import PublishPanel from "./PublishPanel";
import BackendPanel from "./BackendPanel";
import SyncStatusPanel from "./SyncStatusPanel";
import { hasToken, login as apiLogin, logout as apiLogout, usesApi, verifyToken } from "../../store/api";
import { useEffect } from "react";

function Thumb({ src, alt }: { src: string; alt: string }) {
  const url = useResolvedUrl(src);
  return <img src={url} alt={alt} className="h-16 w-12 shrink-0 rounded-lg object-cover ring-1 ring-white/10" />;
}

const ADMIN_PASSWORD = "balvir63";
const AUTH_KEY = "aniverse:admin-auth";

interface Props {
  onExit: () => void;
}

export default function AdminPanel({ onExit }: Props) {
  const apiMode = usesApi();
  const [authed, setAuthed] = useState(() =>
    apiMode ? hasToken() : sessionStorage.getItem(AUTH_KEY) === "1",
  );
  const [pw, setPw] = useState("");
  const [error, setError] = useState("");
  const [loggingIn, setLoggingIn] = useState(false);

  // If a token is saved, quietly verify it — if server says invalid, drop it.
  useEffect(() => {
    if (!apiMode || !authed) return;
    verifyToken().then((ok) => {
      if (!ok) setAuthed(false);
    });
  }, [apiMode, authed]);
  const [mode, setMode] = useState<"list" | "add" | "edit">("list");
  const [editing, setEditing] = useState<Anime | null>(null);

  const { rawAnimeList: animeList, addAnime, updateAnime, deleteAnime, importAnime, resetToSeed, clearAll, saveError } = useAnimeStore();
  const importRef = useRef<HTMLInputElement>(null);
  const [toast, setToast] = useState("");
  const showToast = (t: string) => {
    setToast(t);
    setTimeout(() => setToast(""), 2600);
  };

  const exportData = () => {
    const blob = new Blob([JSON.stringify(animeList, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "aniverse-catalog.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  const importData = (file?: File) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(String(reader.result)) as Anime[];
        if (!Array.isArray(data)) throw new Error("bad");
        const merge = confirm("OK = Merge with existing anime\nCancel = Replace all anime");
        importAnime(data, merge ? "merge" : "replace");
        alert(`Imported ${data.length} anime successfully! ✅`);
      } catch {
        alert("Invalid catalog file ❌");
      }
    };
    reader.readAsText(file);
  };

  const login = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (apiMode) {
      setLoggingIn(true);
      try {
        await apiLogin(pw);
        setAuthed(true);
      } catch (err) {
        setError(err instanceof Error ? err.message : "wrong");
      } finally {
        setLoggingIn(false);
      }
      return;
    }
    if (pw === ADMIN_PASSWORD) {
      sessionStorage.setItem(AUTH_KEY, "1");
      setAuthed(true);
    } else {
      setError("wrong");
    }
  };

  const logout = () => {
    if (apiMode) apiLogout();
    else sessionStorage.removeItem(AUTH_KEY);
    setAuthed(false);
    setPw("");
  };

  if (!authed) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-950 px-4">
        <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(ellipse_at_top,rgba(217,70,239,0.15),transparent_55%)]" />
        <form onSubmit={login} className="relative w-full max-w-sm rounded-3xl bg-slate-900/80 p-8 ring-1 ring-white/10">
          <div className="mb-6 text-center">
            <span className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-fuchsia-500 to-violet-600 shadow-lg shadow-fuchsia-500/30">
              <Crown className="h-7 w-7 text-white" />
            </span>
            <h1 className="text-2xl font-black text-white">Admin Login</h1>
            <p className="mt-1 text-sm text-slate-400">AniVerse Control Panel 👑</p>
          </div>
          <div className="relative">
            <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
            <input
              type="password"
              value={pw}
              onChange={(e) => setPw(e.target.value)}
              placeholder="Enter admin password"
              autoFocus
              className="w-full rounded-xl border border-white/10 bg-slate-800/60 py-3 pl-10 pr-4 text-sm text-white placeholder-slate-500 outline-none focus:border-fuchsia-500/60"
            />
          </div>
          {error && (
            <p className="mt-2 text-sm text-rose-400">
              {error === "wrong" ? "Wrong password ❌" : `❌ ${error}`}
            </p>
          )}
          <button
            type="submit"
            disabled={loggingIn}
            className="mt-4 w-full rounded-xl bg-fuchsia-600 py-3 text-sm font-bold text-white transition hover:bg-fuchsia-500 disabled:opacity-60"
          >
            {loggingIn ? "Signing in..." : apiMode ? "Login (server)" : "Login"}
          </button>
          <button type="button" onClick={onExit} className="mt-3 flex w-full items-center justify-center gap-2 text-sm font-semibold text-slate-400 hover:text-white">
            <ArrowLeft className="h-4 w-4" /> Back to site
          </button>
          <p className="mt-4 text-center text-xs text-slate-600">🔒 Authorized access only</p>
        </form>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(ellipse_at_top,rgba(217,70,239,0.1),transparent_55%)]" />
      <div className="relative">
        {toast && (
          <div className="fixed left-1/2 top-4 z-50 -translate-x-1/2 rounded-full bg-emerald-600 px-5 py-2.5 text-sm font-bold text-white shadow-xl shadow-emerald-600/30">
            {toast}
          </div>
        )}
        {/* Top bar */}
        <header className="sticky top-0 z-30 border-b border-white/10 bg-slate-950/80 backdrop-blur-xl">
          <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3 sm:px-6">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-fuchsia-500 to-violet-600">
              <LayoutDashboard className="h-5 w-5 text-white" />
            </span>
            <div>
              <h1 className="text-lg font-black leading-none">Admin Panel</h1>
              <p className="text-xs text-slate-400">AniVerse CMS</p>
            </div>
            <div className="ml-auto flex items-center gap-2">
              <button onClick={onExit} className="flex items-center gap-2 rounded-full bg-white/5 px-4 py-2 text-sm font-semibold text-slate-300 ring-1 ring-white/10 hover:bg-white/10">
                <Home className="h-4 w-4" /> <span className="hidden sm:inline">View Site</span>
              </button>
              <button onClick={logout} className="flex items-center gap-2 rounded-full bg-rose-600/20 px-4 py-2 text-sm font-semibold text-rose-300 ring-1 ring-rose-500/30 hover:bg-rose-600 hover:text-white">
                <LogOut className="h-4 w-4" /> <span className="hidden sm:inline">Logout</span>
              </button>
            </div>
          </div>
        </header>

        <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
          {mode === "list" ? (
            <>
              {saveError && (
                <div className="mb-4 rounded-xl bg-rose-600/15 px-4 py-3 text-sm font-semibold text-rose-300 ring-1 ring-rose-500/30">
                  ⚠️ Storage full! Some data couldn't be saved. Use smaller videos or paste video URLs instead of uploading large files.
                </div>
              )}
              <SyncStatusPanel />
              <BackendPanel />
              <PublishPanel />
              <CloudPanel />
              {/* Stats */}
              <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
                <StatCard icon={<Film className="h-5 w-5 text-fuchsia-400" />} value={animeList.length} label="Total Anime" />
                <StatCard
                  icon={<LayoutDashboard className="h-5 w-5 text-sky-400" />}
                  value={animeList.reduce((s, a) => s + a.episodes.length, 0)}
                  label="Total Episodes"
                />
                <StatCard icon={<Star className="h-5 w-5 text-amber-400" />} value={animeList.filter((a) => a.featured).length} label="Featured" />
                <StatCard
                  icon={<Film className="h-5 w-5 text-emerald-400" />}
                  value={animeList.filter((a) => a.status === "Ongoing").length}
                  label="Ongoing"
                />
              </div>

              <div className="mb-4 flex items-center justify-between">
                <h2 className="text-xl font-black">Manage Anime</h2>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={exportData}
                    className="flex items-center gap-2 rounded-full bg-white/5 px-4 py-2 text-sm font-semibold text-emerald-300 ring-1 ring-emerald-500/30 hover:bg-emerald-600 hover:text-white"
                  >
                    <Download className="h-4 w-4" /> <span className="hidden sm:inline">Export</span>
                  </button>
                  <button
                    onClick={() => importRef.current?.click()}
                    className="flex items-center gap-2 rounded-full bg-white/5 px-4 py-2 text-sm font-semibold text-sky-300 ring-1 ring-sky-500/30 hover:bg-sky-600 hover:text-white"
                  >
                    <Upload className="h-4 w-4" /> <span className="hidden sm:inline">Import</span>
                  </button>
                  <input
                    ref={importRef}
                    type="file"
                    accept="application/json"
                    className="hidden"
                    onChange={(e) => importData(e.target.files?.[0])}
                  />
                  <button
                    onClick={() => {
                      if (confirm("Sab anime delete kar dun? Ye undo nahi ho sakta.")) clearAll();
                    }}
                    className="flex items-center gap-2 rounded-full bg-white/5 px-4 py-2 text-sm font-semibold text-rose-300 ring-1 ring-rose-500/30 hover:bg-rose-600 hover:text-white"
                  >
                    <Trash2 className="h-4 w-4" /> <span className="hidden sm:inline">Clear all</span>
                  </button>
                  <button
                    onClick={() => {
                      if (confirm("6 demo anime load kar dun? Ye aapke abhi ke anime replace kar dega.")) resetToSeed();
                    }}
                    className="flex items-center gap-2 rounded-full bg-white/5 px-4 py-2 text-sm font-semibold text-slate-300 ring-1 ring-white/10 hover:bg-white/10"
                    title="Sample demo content dobara load karo (optional)"
                  >
                    <RotateCcw className="h-4 w-4" /> <span className="hidden sm:inline">Load demo</span>
                  </button>
                  <button
                    onClick={() => {
                      setEditing(null);
                      setMode("add");
                    }}
                    className="flex items-center gap-2 rounded-full bg-fuchsia-600 px-5 py-2 text-sm font-bold text-white shadow-lg shadow-fuchsia-600/30 hover:bg-fuchsia-500"
                  >
                    <Plus className="h-4 w-4" /> Add Anime
                  </button>
                </div>
              </div>

              {animeList.length === 0 ? (
                <div className="rounded-2xl bg-slate-900/60 py-20 text-center ring-1 ring-white/10">
                  <Film className="mx-auto h-12 w-12 text-slate-600" />
                  <p className="mt-3 text-lg font-bold">No anime yet</p>
                  <p className="text-sm text-slate-400">Click "Add Anime" to create your first title.</p>
                </div>
              ) : (
                <div className="overflow-hidden rounded-2xl bg-slate-900/60 ring-1 ring-white/10">
                  {animeList.map((a) => (
                    <div key={a.id} className="flex items-center gap-4 border-b border-white/5 p-3 last:border-0 hover:bg-white/5">
                      <Thumb src={a.poster} alt={a.title} />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <h3 className="truncate font-bold text-white">{a.titleEnglish || a.title}</h3>
                          {a.featured && <span className="rounded bg-amber-500/20 px-1.5 py-0.5 text-[10px] font-bold text-amber-400">FEATURED</span>}
                        </div>
                        <p className="mt-0.5 flex flex-wrap items-center gap-x-3 text-xs text-slate-400">
                          <span>{a.type}</span>
                          <span>· {a.status}</span>
                          <span>· {a.episodes.length} eps</span>
                          <span>· ⭐ {a.rating}</span>
                          <span>· {a.year}</span>
                        </p>
                      </div>
                      <button
                        onClick={() => {
                          setEditing(a);
                          setMode("edit");
                        }}
                        className="rounded-lg bg-white/5 p-2 text-slate-300 ring-1 ring-white/10 hover:bg-fuchsia-600 hover:text-white"
                        title="Edit"
                      >
                        <Pencil className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`Delete "${a.title}"?`)) deleteAnime(a.id);
                        }}
                        className="rounded-lg bg-white/5 p-2 text-slate-300 ring-1 ring-white/10 hover:bg-rose-600 hover:text-white"
                        title="Delete"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </>
          ) : (
            <AnimeForm
              initial={mode === "edit" && editing ? editing : undefined}
              onSave={(a) => {
                if (mode === "edit") updateAnime(a);
                else addAnime(a);
                setMode("list");
                setEditing(null);
                window.scrollTo({ top: 0 });
                showToast(mode === "edit" ? "✅ Anime update ho gaya" : "✅ Anime save ho gaya");
              }}
              onCancel={() => {
                setMode("list");
                setEditing(null);
              }}
            />
          )}
        </main>
      </div>
    </div>
  );
}

function StatCard({ icon, value, label }: { icon: React.ReactNode; value: number; label: string }) {
  return (
    <div className="rounded-2xl bg-slate-900/60 p-4 ring-1 ring-white/10">
      <div className="flex items-center gap-2">{icon}</div>
      <div className="mt-2 text-3xl font-black text-white">{value}</div>
      <div className="text-xs uppercase tracking-wide text-slate-400">{label}</div>
    </div>
  );
}

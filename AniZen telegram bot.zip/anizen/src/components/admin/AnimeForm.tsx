import { useState } from "react";
import { Plus, Trash2, Save, ArrowLeft, GripVertical, Film, ListPlus, CheckCircle2, AlertTriangle } from "lucide-react";
import type { Anime, Episode, QualityLink } from "../../types";
import { uid } from "../../store/AnimeStore";
import MediaInput from "./MediaInput";
import { HOST_LABEL, parseBulk, parseVideoLink } from "../../utils/videoLinks";
import { WEEK_DAYS } from "../../utils/format";

interface Props {
  initial?: Anime;
  onSave: (a: Anime) => void;
  onCancel: () => void;
}

const TYPES = ["TV", "Movie", "OVA", "ONA", "Special"];
const STATUSES = ["Ongoing", "Completed", "Upcoming"];

function emptyAnime(): Anime {
  return {
    id: uid(),
    title: "",
    titleEnglish: "",
    synopsis: "",
    poster: "",
    banner: "",
    thumbnail: "",
    genres: [],
    type: "TV",
    status: "Ongoing",
    year: new Date().getFullYear(),
    rating: 8,
    studio: "",
    featured: false,
    trailerUrl: "",
    episodes: [],
    createdAt: Date.now(),
  };
}

export default function AnimeForm({ initial, onSave, onCancel }: Props) {
  const [form, setForm] = useState<Anime>(initial ? { ...initial } : emptyAnime());
  const [genreInput, setGenreInput] = useState("");
  const [showBulk, setShowBulk] = useState(false);
  const [bulkText, setBulkText] = useState("");
  const [bulkMsg, setBulkMsg] = useState<{ kind: "ok" | "err"; text: string } | null>(null);

  const set = <K extends keyof Anime>(key: K, value: Anime[K]) =>
    setForm((f) => ({ ...f, [key]: value }));

  const addGenre = () => {
    const g = genreInput.trim();
    if (g && !form.genres.includes(g)) set("genres", [...form.genres, g]);
    setGenreInput("");
  };

  const addEpisode = () => {
    const ep: Episode = {
      id: uid(),
      number: form.episodes.length + 1,
      title: `Episode ${form.episodes.length + 1}`,
      videoUrl: "",
      videoType: "mp4",
      thumbnail: "",
      duration: "",
    };
    set("episodes", [...form.episodes, ep]);
  };

  /** Add many episodes at once from pasted links (one per line). */
  const addBulk = () => {
    const { rows, skipped } = parseBulk(bulkText);
    if (rows.length === 0) {
      setBulkMsg({ kind: "err", text: "Koi sahi link nahi mila. Har line me ek http/https link daalo." });
      return;
    }
    const start = form.episodes.length;
    const eps: Episode[] = rows.map((r, i) => ({
      id: uid(),
      number: start + i + 1,
      title: r.title || `Episode ${start + i + 1}`,
      videoUrl: r.video.url,
      videoType: r.video.type,
      thumbnail: "",
      duration: "",
    }));
    set("episodes", [...form.episodes, ...eps]);
    setBulkText("");
    setBulkMsg({
      kind: skipped.length ? "err" : "ok",
      text:
        `${eps.length} episode add ho gaye ✅ — neeche "Update/Publish Anime" dabana mat bhoolna.` +
        (skipped.length ? ` ${skipped.length} line chhod di (link nahi tha): ${skipped.slice(0, 2).join(" , ")}` : ""),
    });
  };

  /** A pasted link gets converted so it really plays (Drive/Dropbox/YouTube...). */
  const onVideoValue = (id: string, v: string, current: Episode) => {
    if (v.startsWith("idb://") || v.startsWith("data:")) {
      updateEp(id, { videoUrl: v, videoType: "mp4" });
      return;
    }
    const p = parseVideoLink(v);
    if (p) updateEp(id, { videoUrl: p.url, videoType: p.type });
    else updateEp(id, { videoUrl: v, videoType: current.videoType });
  };

  const updateEp = (id: string, patch: Partial<Episode>) =>
    set(
      "episodes",
      form.episodes.map((e) => (e.id === id ? { ...e, ...patch } : e)),
    );

  const removeEp = (id: string) =>
    set(
      "episodes",
      form.episodes.filter((e) => e.id !== id).map((e, i) => ({ ...e, number: i + 1 })),
    );

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title.trim()) {
      alert("Title is required");
      return;
    }
    if (!form.poster) {
      alert("Poster image is required");
      return;
    }
    onSave(form);
  };

  return (
    <form onSubmit={submit} className="space-y-6">
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={onCancel}
          className="flex items-center gap-2 rounded-full bg-white/5 px-4 py-2 text-sm font-semibold text-slate-300 ring-1 ring-white/10 hover:bg-white/10"
        >
          <ArrowLeft className="h-4 w-4" /> Back
        </button>
        <button
          type="submit"
          className="flex items-center gap-2 rounded-full bg-fuchsia-600 px-6 py-2.5 text-sm font-bold text-white shadow-lg shadow-fuchsia-600/30 hover:bg-fuchsia-500"
        >
          <Save className="h-4 w-4" /> {initial ? "Update Anime" : "Publish Anime"}
        </button>
      </div>

      <h2 className="text-2xl font-black text-white">{initial ? "Edit Anime" : "Add New Anime"}</h2>

      {/* Basic info */}
      <div className="grid gap-4 rounded-2xl bg-slate-900/60 p-5 ring-1 ring-white/10 md:grid-cols-2">
        <Field label="Title (Romaji) *">
          <input value={form.title} onChange={(e) => set("title", e.target.value)} className={inputCls} placeholder="e.g. Kaze no Senshi" />
        </Field>
        <Field label="English Title">
          <input value={form.titleEnglish} onChange={(e) => set("titleEnglish", e.target.value)} className={inputCls} placeholder="e.g. Warriors of the Wind" />
        </Field>
        <Field label="Synopsis" full>
          <textarea value={form.synopsis} onChange={(e) => set("synopsis", e.target.value)} rows={3} className={inputCls} placeholder="Short description..." />
        </Field>
        <Field label="Type">
          <select value={form.type} onChange={(e) => set("type", e.target.value)} className={inputCls}>
            {TYPES.map((t) => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>
        </Field>
        <Field label="Status">
          <select value={form.status} onChange={(e) => set("status", e.target.value)} className={inputCls}>
            {STATUSES.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </Field>
        <Field label="Airing day (Schedule tab)">
          <select value={form.airDay || ""} onChange={(e) => set("airDay", e.target.value || undefined)} className={inputCls}>
            <option value="">— Not set —</option>
            {WEEK_DAYS.map((d) => (
              <option key={d.id} value={d.id}>{d.full}</option>
            ))}
          </select>
        </Field>
        <Field label="Air time (e.g. 20:30)">
          <input
            type="time"
            value={form.airTime || ""}
            onChange={(e) => set("airTime", e.target.value || undefined)}
            className={inputCls}
          />
        </Field>
        <Field label="Year">
          <input type="number" value={form.year} onChange={(e) => set("year", Number(e.target.value))} className={inputCls} />
        </Field>
        <Field label="Rating (0-10)">
          <input type="number" step="0.1" min="0" max="10" value={form.rating} onChange={(e) => set("rating", Number(e.target.value))} className={inputCls} />
        </Field>
        <Field label="Studio">
          <input value={form.studio} onChange={(e) => set("studio", e.target.value)} className={inputCls} placeholder="e.g. Studio AniVerse" />
        </Field>
        <Field label="Featured on Hero">
          <label className="flex cursor-pointer items-center gap-2 py-2 text-sm text-slate-300">
            <input type="checkbox" checked={form.featured} onChange={(e) => set("featured", e.target.checked)} className="h-4 w-4 accent-fuchsia-600" />
            Show in homepage hero slider
          </label>
        </Field>

        {/* Genres */}
        <Field label="Genres" full>
          <div className="flex gap-2">
            <input
              value={genreInput}
              onChange={(e) => setGenreInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  addGenre();
                }
              }}
              className={inputCls}
              placeholder="Type a genre and press Enter"
            />
            <button type="button" onClick={addGenre} className="shrink-0 rounded-lg bg-fuchsia-600 px-4 text-sm font-bold text-white hover:bg-fuchsia-500">
              Add
            </button>
          </div>
          <div className="mt-2 flex flex-wrap gap-2">
            {form.genres.map((g) => (
              <span key={g} className="flex items-center gap-1 rounded-full bg-fuchsia-600/20 px-3 py-1 text-xs font-semibold text-fuchsia-300 ring-1 ring-fuchsia-500/30">
                {g}
                <button type="button" onClick={() => set("genres", form.genres.filter((x) => x !== g))} className="text-fuchsia-300 hover:text-white">
                  ×
                </button>
              </span>
            ))}
          </div>
        </Field>
      </div>

      {/* Images */}
      <div className="grid gap-4 rounded-2xl bg-slate-900/60 p-5 ring-1 ring-white/10 md:grid-cols-3">
        <MediaInput label="Poster (portrait) *" value={form.poster} onChange={(v) => set("poster", v)} hint="Best 3:4 ratio, used on cards" />
        <MediaInput label="Banner (wide)" value={form.banner} onChange={(v) => set("banner", v)} hint="Best 16:9, used in hero & modal" />
        <MediaInput label="Thumbnail (wide)" value={form.thumbnail || ""} onChange={(v) => set("thumbnail", v)} hint="Optional, used in Continue Watching" />
        <div className="md:col-span-3">
          <MediaInput label="Trailer URL (optional)" value={form.trailerUrl || ""} onChange={(v) => set("trailerUrl", v)} preview="none" accept="video/*" hint="YouTube link or .mp4 URL" />
        </div>
      </div>

      {/* Episodes */}
      <div className="rounded-2xl bg-slate-900/60 p-5 ring-1 ring-white/10">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="flex items-center gap-2 text-lg font-bold text-white">
            <Film className="h-5 w-5 text-fuchsia-400" /> Episodes ({form.episodes.length})
          </h3>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => setShowBulk((s) => !s)}
              className="flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-sm font-bold text-white ring-1 ring-white/15 hover:bg-white/15"
            >
              <ListPlus className="h-4 w-4" /> Bulk add links
            </button>
            <button type="button" onClick={addEpisode} className="flex items-center gap-2 rounded-full bg-fuchsia-600 px-4 py-2 text-sm font-bold text-white hover:bg-fuchsia-500">
              <Plus className="h-4 w-4" /> Add Episode
            </button>
          </div>
        </div>

        {showBulk && (
          <div className="mb-5 rounded-xl bg-blue-500/10 p-4 ring-1 ring-blue-500/25">
            <p className="mb-2 text-sm font-bold text-white">Bahut saare episodes ek saath (unlimited)</p>
            <p className="mb-3 text-xs leading-relaxed text-slate-300">
              Har line me ek episode ka link paste karo. Naam dena ho to <code className="rounded bg-white/10 px-1">Naam | link</code>{" "}
              likho. Google Drive, Dropbox, YouTube, Vimeo aur seedhe MP4 links chalte hain — Drive ka link apne aap sahi
              ho jaata hai.
            </p>
            <textarea
              value={bulkText}
              onChange={(e) => setBulkText(e.target.value)}
              rows={6}
              placeholder={"https://drive.google.com/file/d/xxxxx/view\nEpisode 2 | https://drive.google.com/file/d/yyyyy/view\nhttps://www.dropbox.com/s/zzzz/ep3.mp4?dl=0"}
              className="w-full rounded-lg border border-white/10 bg-slate-900/70 p-3 font-mono text-xs text-white placeholder-slate-600 outline-none focus:border-blue-500/60"
            />
            <div className="mt-3 flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={addBulk}
                className="flex items-center gap-2 rounded-full bg-blue-600 px-5 py-2 text-sm font-bold text-white hover:bg-blue-500"
              >
                <Plus className="h-4 w-4" /> Add all episodes
              </button>
              <span className="text-xs text-slate-400">{bulkText.split(/\r?\n/).filter((l) => l.trim()).length} line</span>
            </div>
            {bulkMsg && (
              <p className={`mt-3 flex items-start gap-1.5 text-xs font-semibold ${bulkMsg.kind === "ok" ? "text-emerald-400" : "text-amber-300"}`}>
                {bulkMsg.kind === "ok" ? <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" /> : <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />}
                <span>{bulkMsg.text}</span>
              </p>
            )}
          </div>
        )}

        {form.episodes.length === 0 ? (
          <p className="py-8 text-center text-sm text-slate-500">No episodes yet. Click "Add Episode" to upload video links.</p>
        ) : (
          <div className="space-y-4">
            {form.episodes.map((ep) => (
              <div key={ep.id} className="rounded-xl bg-slate-800/40 p-4 ring-1 ring-white/10">
                <div className="mb-3 flex items-center gap-2">
                  <GripVertical className="h-4 w-4 text-slate-600" />
                  <span className="flex h-7 w-9 items-center justify-center rounded bg-fuchsia-600 text-xs font-black text-white">
                    {ep.number}
                  </span>
                  <input
                    value={ep.title}
                    onChange={(e) => updateEp(ep.id, { title: e.target.value })}
                    className="flex-1 rounded-lg border border-white/10 bg-slate-900/60 px-3 py-1.5 text-sm font-semibold text-white outline-none focus:border-fuchsia-500/60"
                    placeholder="Episode title"
                  />
                  <button type="button" onClick={() => removeEp(ep.id)} className="rounded-lg bg-rose-600/20 p-2 text-rose-400 hover:bg-rose-600 hover:text-white">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
                <div className="grid gap-3 md:grid-cols-4">
                  <div className="md:col-span-3">
                    <MediaInput
                      label="Video (Gallery upload or URL) — plays in VLC Player 🎬"
                      value={ep.videoUrl}
                      onChange={(v) => onVideoValue(ep.id, v, ep)}
                      accept="video/*"
                      preview={ep.videoType === "mp4" ? "video" : "none"}
                      hint="Gallery se upload karo, ya Drive / Dropbox / YouTube / MP4 ka link paste karo"
                    />
                    {(() => {
                      const p = parseVideoLink(ep.videoUrl);
                      if (!p) return null;
                      return (
                        <div className="mt-2">
                          <p className="flex items-center gap-1.5 text-[11px] font-semibold text-emerald-400">
                            <CheckCircle2 className="h-3.5 w-3.5" /> {HOST_LABEL[p.host]} link pehchana gaya
                          </p>
                          {p.warning && <p className="mt-1 text-[11px] leading-relaxed text-amber-300">⚠️ {p.warning}</p>}
                        </div>
                      );
                    })()}
                    {ep.videoType === "mp4" && (
                      <QualityEditor
                        value={ep.qualities}
                        onChange={(q) => updateEp(ep.id, { qualities: q })}
                      />
                    )}
                  </div>
                  <div>
                    <label className="mb-1 block text-[11px] font-bold uppercase text-slate-400">Source Type</label>
                    <select value={ep.videoType} onChange={(e) => updateEp(ep.id, { videoType: e.target.value as "mp4" | "embed" })} className={inputCls}>
                      <option value="mp4">MP4 / Gallery video (VLC)</option>
                      <option value="embed">Embed (YouTube/iframe)</option>
                    </select>
                    <label className="mb-1 mt-3 block text-[11px] font-bold uppercase text-slate-400">Duration</label>
                    <input value={ep.duration || ""} onChange={(e) => updateEp(ep.id, { duration: e.target.value })} className={inputCls} placeholder="24m" />
                  </div>
                  <div className="md:col-span-4">
                    <MediaInput label="Episode Thumbnail (optional)" value={ep.thumbnail || ""} onChange={(v) => updateEp(ep.id, { thumbnail: v })} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="flex justify-end gap-3">
        <button type="button" onClick={onCancel} className="rounded-full bg-white/5 px-6 py-2.5 text-sm font-bold text-slate-300 ring-1 ring-white/10 hover:bg-white/10">
          Cancel
        </button>
        <button type="submit" className="flex items-center gap-2 rounded-full bg-fuchsia-600 px-6 py-2.5 text-sm font-bold text-white shadow-lg shadow-fuchsia-600/30 hover:bg-fuchsia-500">
          <Save className="h-4 w-4" /> {initial ? "Update Anime" : "Publish Anime"}
        </button>
      </div>
    </form>
  );
}

const inputCls =
  "w-full rounded-lg border border-white/10 bg-slate-800/60 px-3 py-2 text-sm text-white placeholder-slate-500 outline-none focus:border-fuchsia-500/60";

const QUALITY_LABELS = ["1080p", "720p", "480p", "360p"];

/** Optional extra resolutions for one episode. Viewers get a Quality menu in the player. */
function QualityEditor({
  value,
  onChange,
}: {
  value?: QualityLink[];
  onChange: (q: QualityLink[] | undefined) => void;
}) {
  const [open, setOpen] = useState(!!value?.length);
  const urlOf = (label: string) => value?.find((q) => q.label === label)?.url || "";

  const setUrl = (label: string, url: string) => {
    const rest = (value || []).filter((q) => q.label !== label);
    const next = url.trim() ? [...rest, { label, url: url.trim() }] : rest;
    next.sort((a, b) => parseInt(b.label, 10) - parseInt(a.label, 10));
    onChange(next.length ? next : undefined);
  };

  return (
    <div className="mt-3">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="text-[11px] font-bold uppercase tracking-wide text-cyan-400 hover:text-cyan-300"
      >
        {open ? "− " : "+ "}Quality links (optional){value?.length ? ` · ${value.length} set` : ""}
      </button>
      {open && (
        <div className="mt-2 space-y-2 rounded-lg bg-slate-900/60 p-3 ring-1 ring-white/10">
          <p className="text-[11px] leading-relaxed text-slate-400">
            Isi episode ki alag-alag quality ke direct video links daalo. Upar wala link <b>Original</b> rahega aur
            player me <b>Quality</b> menu aa jayega. Khaali chhodo to sirf original chalega. Cloudinary ke links me
            ye apne aap ban jaata hai.
          </p>
          {QUALITY_LABELS.map((label) => (
            <div key={label} className="flex items-center gap-2">
              <span className="w-12 shrink-0 text-xs font-bold text-slate-300">{label}</span>
              <input
                value={urlOf(label)}
                onChange={(e) => setUrl(label, e.target.value)}
                placeholder="https://... (video link)"
                className="min-w-0 flex-1 rounded-lg border border-white/10 bg-slate-800/60 px-3 py-1.5 text-xs text-white placeholder-slate-600 outline-none focus:border-cyan-400/50"
              />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function Field({ label, children, full }: { label: string; children: React.ReactNode; full?: boolean }) {
  return (
    <div className={full ? "md:col-span-2" : ""}>
      <label className="mb-1.5 block text-xs font-bold uppercase tracking-wide text-slate-400">{label}</label>
      {children}
    </div>
  );
}

import { useEffect, useState } from "react";
import {
  Server,
  Loader2,
  CheckCircle2,
  XCircle,
  Copy,
  Check,
  Trash2,
  KeyRound,
  Save,
} from "lucide-react";
import { getApiUrl, health, hasToken, setApiUrl } from "../../store/api";
import { copyText } from "../../utils/share";
import { API_URL } from "../../config";
import { useAnimeStore } from "../../store/AnimeStore";

type Status = { kind: "ok" | "err" | "info"; text: string } | null;

export default function BackendPanel() {
  const { syncNow } = useAnimeStore();
  const savedUrl = getApiUrl();
  const isHardCoded = !!API_URL;
  const [url, setUrl] = useState(savedUrl);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<Status>(null);
  const [copied, setCopied] = useState(false);
  const [alive, setAlive] = useState<boolean | null>(null);

  useEffect(() => {
    let cancelled = false;
    if (!savedUrl) {
      setAlive(null);
      return;
    }
    (async () => {
      const ok = await health();
      if (!cancelled) setAlive(ok);
    })();
    return () => {
      cancelled = true;
    };
  }, [savedUrl]);

  const connect = async () => {
    const clean = url.trim().replace(/\/$/, "");
    if (!/^https?:\/\/.+/.test(clean)) {
      setStatus({ kind: "err", text: "URL http:// ya https:// se shuru hona chahiye." });
      return;
    }
    setBusy(true);
    setStatus(null);
    try {
      setApiUrl(clean);
      const ok = await health();
      if (!ok) throw new Error("Server se jawab nahi mila. URL check karo aur server chal raha hai confirm karo.");
      setAlive(true);
      setStatus({ kind: "ok", text: "Backend connect ✅ Reload karo ya 'Sync now' dabao." });
      syncNow();
    } catch (e) {
      setAlive(false);
      setStatus({ kind: "err", text: e instanceof Error ? e.message : "Connect nahi hua" });
    } finally {
      setBusy(false);
    }
  };

  const disconnect = () => {
    setApiUrl("");
    setUrl("");
    setAlive(null);
    setStatus({ kind: "info", text: "Backend hata diya. Page reload karo taaki purana mode chalu ho." });
  };

  const doCopy = async (text: string) => {
    if (await copyText(text)) {
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    }
  };

  const inputCls =
    "w-full rounded-lg border border-white/10 bg-slate-800/60 px-3 py-2 text-sm text-white placeholder-slate-500 outline-none focus:border-emerald-500/60 disabled:opacity-50";

  return (
    <div className="mb-6 rounded-2xl bg-slate-900/60 p-5 ring-1 ring-white/10">
      <div className="mb-3 flex flex-wrap items-center gap-3">
        <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-600/20 text-emerald-400">
          <Server className="h-5 w-5" />
        </span>
        <div className="min-w-0 flex-1">
          <h3 className="font-black text-white">Real Backend (Node + SQLite)</h3>
          <p className="text-xs text-slate-400">
            {savedUrl
              ? "Website is server par asli database use kar rahi hai."
              : "Apna Node/Express + SQLite server chalao, URL yahan lagao — sabhi phones ek server par jud jaayenge."}
          </p>
        </div>
        {savedUrl ? (
          alive === null ? (
            <span className="flex items-center gap-1.5 rounded-full bg-slate-500/20 px-3 py-1 text-xs font-bold text-slate-300 ring-1 ring-white/10">
              <Loader2 className="h-3 w-3 animate-spin" /> Checking
            </span>
          ) : alive ? (
            <span className="flex items-center gap-1.5 rounded-full bg-emerald-500/15 px-3 py-1 text-xs font-bold text-emerald-300 ring-1 ring-emerald-500/30">
              <CheckCircle2 className="h-3 w-3" /> LIVE
            </span>
          ) : (
            <span className="flex items-center gap-1.5 rounded-full bg-rose-500/15 px-3 py-1 text-xs font-bold text-rose-300 ring-1 ring-rose-500/30">
              <XCircle className="h-3 w-3" /> OFFLINE
            </span>
          )
        ) : (
          <span className="rounded-full bg-slate-500/20 px-3 py-1 text-xs font-bold text-slate-300 ring-1 ring-white/10">OFF</span>
        )}
      </div>

      {isHardCoded && (
        <p className="mb-3 rounded-lg bg-emerald-500/10 px-3 py-2 text-xs text-emerald-200 ring-1 ring-emerald-500/20">
          Backend URL website ke code me hard-coded hai (<code className="font-mono">VITE_API_URL</code>). Har phone
          apne aap is server se connect ho jayega.
        </p>
      )}

      <div className="space-y-3">
        <input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="https://your-server.example.com"
          className={inputCls}
          disabled={isHardCoded}
          inputMode="url"
        />

        <div className="flex flex-wrap gap-2">
          {!isHardCoded && (
            <button
              onClick={connect}
              disabled={busy}
              className="flex items-center gap-2 rounded-full bg-emerald-600 px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-emerald-600/30 transition hover:bg-emerald-500 disabled:opacity-60"
            >
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              {busy ? "Connecting..." : savedUrl ? "Save & re-check" : "Connect"}
            </button>
          )}
          {savedUrl && (
            <>
              <button
                onClick={() => doCopy(savedUrl)}
                className="flex items-center gap-2 rounded-full bg-white/10 px-4 py-2.5 text-sm font-semibold text-slate-200 ring-1 ring-white/15 hover:bg-white/15"
              >
                {copied ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
                {copied ? "Copied" : "Copy URL"}
              </button>
              {!isHardCoded && (
                <button
                  onClick={disconnect}
                  className="flex items-center gap-2 rounded-full bg-rose-600/20 px-4 py-2.5 text-sm font-bold text-rose-300 ring-1 ring-rose-500/30 hover:bg-rose-600 hover:text-white"
                >
                  <Trash2 className="h-4 w-4" /> Remove
                </button>
              )}
            </>
          )}
        </div>

        {status && (
          <p
            className={`text-sm font-semibold ${
              status.kind === "ok"
                ? "text-emerald-400"
                : status.kind === "err"
                  ? "text-rose-400"
                  : "text-slate-300"
            }`}
          >
            {status.text}
          </p>
        )}

        <p className="flex items-start gap-2 text-xs text-slate-500">
          <KeyRound className="mt-0.5 h-3.5 w-3.5 shrink-0" />
          <span>
            {hasToken()
              ? "Admin login active hai — add/edit/delete server par save honge."
              : "Backend set karne ke baad admin panel ka password server par verify hoga (JWT)."}
          </span>
        </p>
      </div>
    </div>
  );
}

import { useState } from "react";
import {
  Database,
  Copy,
  Check,
  RefreshCw,
  Loader2,
  Settings2,
  Trash2,
  FlaskConical,
  Unplug,
  ListOrdered,
  MessageCircle,
  Cloud,
} from "lucide-react";
import { useAnimeStore } from "../../store/AnimeStore";
import {
  getCloudinary,
  setCloudinary,
  testCloudinary,
  getWorkerCfg,
  setWorkerCfg,
  WORKER_CLOUD_ID,
  NOSTR_CLOUD_ID,
} from "../../store/cloud";
import { catalogLink, copyText } from "../../utils/share";

type Status = { kind: "ok" | "err"; text: string } | null;

const SETUP_STEPS = [
  "cloudflare.com par free account banao (Sign Up → email verify).",
  "Dashboard me Workers & Pages → Create → Workers tab → Start with Hello World → Deploy.",
  "Apne Worker par click → Edit code → purana code hata ke worker/catalog-worker.js ka code paste karo → Save and deploy.",
  "Wapas Workers & Pages → KV → Create a namespace → naam aniverse → Add.",
  "Worker → Settings → Bindings → Add binding → KV namespace → Variable name bilkul ye: CATALOG → namespace aniverse → Deploy.",
  "Worker → Settings → Variables and Secrets → Add → type Secret → naam: ADMIN_KEY → value: apna secret → Deploy.",
  "Worker ka URL copy karo (jaise https://....workers.dev) → neeche Worker URL + wahi ADMIN_KEY daal ke Connect & upload dabao.",
];

export default function CloudPanel() {
  const { cloudId, syncState, localOnly, enableCloud, connectCloud, disconnectCloud, syncNow } = useAnimeStore();
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<Status>(null);
  const [copied, setCopied] = useState("");
  const [connectId, setConnectId] = useState("");

  // Worker (advanced, permanent option)
  const [workerOn, setWorkerOn] = useState(() => cloudId === WORKER_CLOUD_ID && !!getWorkerCfg()?.key);
  const [workerUrl, setWorkerUrl] = useState(() => getWorkerCfg()?.url || "");
  const [adminKey, setAdminKey] = useState(() => getWorkerCfg()?.key || "");
  const [showGuide, setShowGuide] = useState(false);
  const [showWorker, setShowWorker] = useState(false);

  // Cloudinary
  const saved = getCloudinary();
  const [cloudName, setCloudName] = useState(saved?.cloudName || "");
  const [preset, setPreset] = useState(saved?.preset || "");
  const [cldOn, setCldOn] = useState(!!saved);
  const [cldStatus, setCldStatus] = useState<Status>(null);
  const [cldBusy, setCldBusy] = useState(false);
  const [showCld, setShowCld] = useState(false);

  const shareUrl = catalogLink();
  // Default is the shared Nostr catalog, managed from the "Data Safety & Sharing" panel above.
  const nostrMode = cloudId === NOSTR_CLOUD_ID;
  const isLive = !!cloudId && !nostrMode;

  const copy = async (text: string, key: string) => {
    const ok = await copyText(text);
    if (ok) {
      setCopied(key);
      setTimeout(() => setCopied(""), 1500);
    } else {
      window.prompt("Copy this:", text);
    }
  };

  const enable = async () => {
    setBusy(true);
    setStatus(null);
    try {
      await enableCloud();
      setStatus({ kind: "ok", text: "Online database ON ✅ Ab har add / edit / delete online save hoga." });
    } catch (e) {
      setStatus({ kind: "err", text: e instanceof Error ? e.message : "Connect nahi hua" });
    } finally {
      setBusy(false);
    }
  };

  const connect = async () => {
    if (!connectId.trim()) {
      setStatus({ kind: "err", text: "Pehle Database ID paste karo." });
      return;
    }
    setBusy(true);
    setStatus(null);
    try {
      await connectCloud(connectId.trim());
      setConnectId("");
      setStatus({ kind: "ok", text: "Database connect ho gayi ✅" });
    } catch (e) {
      setStatus({ kind: "err", text: e instanceof Error ? e.message : "Connect nahi hua" });
    } finally {
      setBusy(false);
    }
  };

  const connectWorker = async () => {
    const url = workerUrl.trim().replace(/\/$/, "");
    const key = adminKey.trim();
    if (!/^https:\/\/.+/.test(url)) {
      setStatus({ kind: "err", text: "Worker URL sahi nahi lag raha. https:// se shuru hona chahiye." });
      return;
    }
    if (!key) {
      setStatus({ kind: "err", text: "Admin Key bharo (jo Worker me ADMIN_KEY secret banaya tha)." });
      return;
    }
    setBusy(true);
    setStatus(null);
    try {
      setWorkerCfg(url, key);
      await enableCloud();
      setWorkerOn(true);
      setStatus({ kind: "ok", text: "Cloudflare connect ✅ Ab har change Worker par save hoga." });
    } catch (e) {
      setStatus({ kind: "err", text: e instanceof Error ? e.message : "Connect nahi hua" });
    } finally {
      setBusy(false);
    }
  };

  const disconnect = () => {
    setWorkerCfg("", "");
    disconnectCloud();
    setWorkerOn(false);
    setStatus({ kind: "ok", text: "Database disconnect. Anime ab sirf is device par save honge." });
  };

  const validCloud = (c: string) => /^[a-z0-9_-]{3,}$/i.test(c);

  const saveCld = async () => {
    const c = cloudName.trim();
    const p = preset.trim();
    if (!c || !p) {
      setCldStatus({ kind: "err", text: "Cloud name aur preset dono bharo." });
      return;
    }
    if (!validCloud(c)) {
      setCldStatus({ kind: "err", text: "Cloud name sahi nahi lag raha (sirf letters/numbers)." });
      return;
    }
    setCldBusy(true);
    setCldStatus(null);
    try {
      await testCloudinary({ cloudName: c, preset: p });
      setCloudinary({ cloudName: c, preset: p });
      setCldOn(true);
      setCldStatus({ kind: "ok", text: "Test pass ✅ Save ho gaya. Ab gallery uploads sabko dikhenge." });
    } catch (e) {
      setCldStatus({
        kind: "err",
        text: `Save nahi hua: ${e instanceof Error ? e.message : "test fail"}. Details check karo.`,
      });
    } finally {
      setCldBusy(false);
    }
  };

  const removeCld = () => {
    setCloudinary(null);
    setCloudName("");
    setPreset("");
    setCldOn(false);
    setCldStatus({ kind: "ok", text: "Cloudinary hata diya. Uploads ab local honge." });
  };

  const inputCls =
    "w-full rounded-lg border border-white/10 bg-slate-800/60 px-3 py-2 text-sm text-white placeholder-slate-500 outline-none focus:border-blue-500/60";

  const StatusLine = ({ s }: { s: Status }) =>
    s ? (
      <p className={`mt-3 text-sm font-semibold ${s.kind === "ok" ? "text-emerald-400" : "text-rose-400"}`}>{s.text}</p>
    ) : null;

  return (
    <div className="mb-6 rounded-2xl bg-slate-900/60 p-5 ring-1 ring-white/10">
      <div className="mb-3 flex flex-wrap items-center gap-3">
        <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-600/20 text-blue-400">
          <Database className="h-5 w-5" />
        </span>
        <div className="min-w-0 flex-1">
          <h3 className="font-black text-white">
            {nostrMode ? "Extra options (optional)" : "Online Database (sabhi phones ke liye)"}
          </h3>
          <p className="text-xs text-slate-400">
            {nostrMode
              ? "Shared catalog ab Nostr par chalta hai — uska status upar 'Data Safety & Sharing' me hai."
              : isLive
                ? "LIVE: har phone par yahi anime dikhenge, har change auto-save hota hai."
                : "Abhi anime sirf isi browser me hain. 1 tap me online database chalu karo."}
          </p>
        </div>
        {nostrMode ? null : isLive ? (
          <span className="flex items-center gap-1.5 rounded-full bg-emerald-500/15 px-3 py-1 text-xs font-bold text-emerald-300 ring-1 ring-emerald-500/30">
            {syncState === "saving" ? <Loader2 className="h-3 w-3 animate-spin" /> : <span className="h-2 w-2 rounded-full bg-emerald-400" />}
            {syncState === "saving" ? "Saving..." : syncState === "error" ? "Sync error" : "LIVE"}
          </span>
        ) : (
          <span className="rounded-full bg-slate-500/20 px-3 py-1 text-xs font-bold text-slate-300 ring-1 ring-white/10">
            OFF
          </span>
        )}
      </div>

      {nostrMode ? null : !isLive ? (
        <div className="space-y-3">
          <button
            onClick={enable}
            disabled={busy}
            className="flex items-center gap-2 rounded-full bg-blue-600 px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-blue-600/30 transition hover:bg-blue-500 disabled:opacity-60"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Database className="h-4 w-4" />}
            {busy ? "Connecting..." : "Enable Online Database (free, 1 tap)"}
          </button>
          <div className="flex gap-2">
            <input
              value={connectId}
              onChange={(e) => setConnectId(e.target.value)}
              placeholder="Database ID hai? Yahan paste karo (kvdb:...)"
              className={inputCls}
            />
            <button
              onClick={connect}
              disabled={busy}
              className="shrink-0 rounded-lg bg-white/10 px-4 text-sm font-bold text-white hover:bg-white/20 disabled:opacity-60"
            >
              Connect
            </button>
          </div>
          <p className="text-xs text-slate-500">
            Koi account ya setup nahi chahiye. Database ID milte hi share link se har phone jud jayega.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          <div>
            <label className="mb-1 block text-[11px] font-bold uppercase text-slate-400">Database ID</label>
            <div className="flex gap-2">
              <input readOnly value={cloudId} className={inputCls} />
              <button
                onClick={() => copy(cloudId, "id")}
                className="flex shrink-0 items-center rounded-lg bg-white/10 px-3 text-white hover:bg-white/20"
              >
                {copied === "id" ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
              </button>
            </div>
          </div>
          <div>
            <label className="mb-1 block text-[11px] font-bold uppercase text-slate-400">
              Share link (is link se kholne wale ko same anime dikhenge)
            </label>
            <div className="flex gap-2">
              <input readOnly value={shareUrl} className={inputCls} />
              <button
                onClick={() => copy(shareUrl, "link")}
                className="flex shrink-0 items-center gap-1.5 rounded-lg bg-blue-600 px-3 text-sm font-bold text-white hover:bg-blue-500"
              >
                {copied === "link" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                <span className="hidden sm:inline">Copy</span>
              </button>
              <a
                href={`https://wa.me/?text=${encodeURIComponent("AniZen dekho! 🔥\n" + shareUrl)}`}
                target="_blank"
                rel="noreferrer"
                className="flex shrink-0 items-center gap-1.5 rounded-lg bg-[#25D366]/15 px-3 text-sm font-bold text-[#25D366] ring-1 ring-[#25D366]/30 hover:bg-[#25D366] hover:text-white"
              >
                <MessageCircle className="h-4 w-4" />
                <span className="hidden sm:inline">WhatsApp</span>
              </a>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={syncNow}
              className="flex items-center gap-2 rounded-full bg-white/5 px-4 py-2 text-sm font-semibold text-slate-300 ring-1 ring-white/10 hover:bg-white/10"
            >
              <RefreshCw className="h-4 w-4" /> Sync now
            </button>
            <button
              onClick={disconnect}
              className="flex items-center gap-2 rounded-full bg-rose-600/20 px-4 py-2 text-sm font-semibold text-rose-300 ring-1 ring-rose-500/30 hover:bg-rose-600 hover:text-white"
            >
              <Unplug className="h-4 w-4" /> Disconnect
            </button>
          </div>
          {localOnly > 0 && (
            <p className="rounded-lg bg-amber-500/10 px-3 py-2 text-xs text-amber-200 ring-1 ring-amber-500/30">
              ⚠️ {localOnly} episode video sirf is device par hai — dusre phones par nahi chalegi. Video ka URL do ya
              Cloudinary set karo.
            </p>
          )}
          {syncState === "error" && (
            <p className="text-sm font-semibold text-rose-400">Online save fail hua. Internet check karke "Sync now" dabao.</p>
          )}
        </div>
      )}
      <StatusLine s={status} />

      {/* Advanced: Cloudflare Worker */}
      <button
        onClick={() => setShowWorker((s) => !s)}
        className="mt-5 flex items-center gap-2 text-sm font-semibold text-slate-300 hover:text-white"
      >
        <Cloud className="h-4 w-4" /> Advanced: Cloudflare Worker (permanent, kabhi expire nahi){" "}
        {workerOn && <span className="rounded bg-emerald-500/20 px-1.5 py-0.5 text-[10px] font-bold text-emerald-300">ON</span>}
      </button>
      {showWorker && (
        <div className="mt-3 space-y-3 rounded-xl bg-slate-800/40 p-4 ring-1 ring-white/10">
          <p className="text-xs text-slate-400">
            Upar wala free database har save par 1 saal ke liye refresh hota hai. Agar bilkul permanent server chahiye
            to apna Cloudflare Worker lagao (free). Connect karte hi ye catalog Worker par upload ho jayega.
          </p>
          <input
            value={workerUrl}
            onChange={(e) => setWorkerUrl(e.target.value)}
            placeholder="Worker URL — https://....workers.dev"
            className={inputCls}
            inputMode="url"
          />
          <input
            value={adminKey}
            onChange={(e) => setAdminKey(e.target.value)}
            placeholder="Admin Key (Worker me banaya hua ADMIN_KEY secret)"
            type="password"
            className={inputCls}
          />
          <button
            onClick={connectWorker}
            disabled={busy}
            className="flex items-center gap-2 rounded-full bg-orange-500 px-5 py-2 text-sm font-bold text-white hover:bg-orange-400 disabled:opacity-60"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Cloud className="h-4 w-4" />}
            {busy ? "Uploading..." : "Connect Worker & upload"}
          </button>
          <button onClick={() => setShowGuide((s) => !s)} className="flex items-center gap-2 text-sm font-semibold text-slate-300 hover:text-white">
            <ListOrdered className="h-4 w-4" /> {showGuide ? "Setup guide chhupao" : "Setup guide dekho (7 easy steps)"}
          </button>
          {showGuide && (
            <ol className="list-decimal space-y-2 rounded-xl bg-slate-900/60 p-4 pl-9 text-xs leading-relaxed text-slate-300 ring-1 ring-white/10">
              {SETUP_STEPS.map((s, i) => (
                <li key={i}>{s}</li>
              ))}
            </ol>
          )}
        </div>
      )}

      <button onClick={() => setShowCld((s) => !s)} className="mt-5 flex items-center gap-2 text-sm font-semibold text-slate-300 hover:text-white">
        <Settings2 className="h-4 w-4" /> Video hosting (Cloudinary){" "}
        {cldOn && <span className="rounded bg-emerald-500/20 px-1.5 py-0.5 text-[10px] font-bold text-emerald-300">ON</span>}
      </button>
      {showCld && (
        <div className="mt-3 space-y-3 rounded-xl bg-slate-800/40 p-4 ring-1 ring-white/10">
          <p className="text-xs leading-relaxed text-slate-400">
            Gallery ki video sabko dikhane ke liye: cloudinary.com par free sign up → Settings → Upload → "Add upload
            preset" → Signing mode <b>Unsigned</b> → Save. Phir apna <b>Cloud name</b> (dashboard par milta hai) aur
            preset ka naam yahan daalo. Save dabane par pehle test hoga.
          </p>
          <div className="grid gap-2 sm:grid-cols-2">
            <input value={cloudName} onChange={(e) => setCloudName(e.target.value)} placeholder="Cloud name" className={inputCls} />
            <input value={preset} onChange={(e) => setPreset(e.target.value)} placeholder="Unsigned upload preset" className={inputCls} />
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={saveCld}
              disabled={cldBusy}
              className="flex items-center gap-2 rounded-full bg-blue-600 px-5 py-2 text-sm font-bold text-white hover:bg-blue-500 disabled:opacity-60"
            >
              {cldBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : <FlaskConical className="h-4 w-4" />}
              {cldBusy ? "Testing..." : "Test & Save"}
            </button>
            {cldOn && (
              <button onClick={removeCld} className="flex items-center gap-2 rounded-full bg-rose-600/20 px-4 py-2 text-sm font-bold text-rose-300 ring-1 ring-rose-500/30 hover:bg-rose-600 hover:text-white">
                <Trash2 className="h-4 w-4" /> Remove
              </button>
            )}
          </div>
          <StatusLine s={cldStatus} />
        </div>
      )}
    </div>
  );
}

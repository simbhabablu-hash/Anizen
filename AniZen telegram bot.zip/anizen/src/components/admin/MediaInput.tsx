import { useRef, useState } from "react";
import { Upload, Link2, X, Loader2, CheckCircle2, AlertTriangle } from "lucide-react";
import { checkVideoFile, uploadMedia } from "../../store/media";
import { getCloudinary } from "../../store/cloud";
import { useResolvedUrl } from "../../hooks/useResolvedUrl";

interface Props {
  label: string;
  value: string;
  onChange: (v: string) => void;
  accept?: string;
  preview?: "image" | "video" | "none";
  hint?: string;
}

export default function MediaInput({
  label,
  value,
  onChange,
  accept = "image/*",
  preview = "image",
  hint,
}: Props) {
  const [mode, setMode] = useState<"url" | "upload">("url");
  const [uploading, setUploading] = useState(false);
  const [pct, setPct] = useState(0);
  const [stage, setStage] = useState<"checking" | "uploading" | "">("");
  const [uploadErr, setUploadErr] = useState("");
  const [warnings, setWarnings] = useState<string[]>([]);
  const [done, setDone] = useState<null | { shared: boolean; name: string }>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const resolved = useResolvedUrl(value);
  const isVideoField = accept.includes("video");

  const handleFile = async (file?: File) => {
    if (!file) return;
    setUploading(true);
    setUploadErr("");
    setWarnings([]);
    setDone(null);
    setPct(0);
    try {
      // 1) Make sure the browser can really play this video before waiting for the upload
      if (file.type.startsWith("video/") || isVideoField) {
        setStage("checking");
        const check = await checkVideoFile(file);
        if (check.warnings.length) setWarnings(check.warnings);
      }

      // 2) Upload with a real progress bar
      setStage("uploading");
      const { value: v, shared, note } = await uploadMedia(file, setPct);
      onChange(v);
      setDone({ shared, name: file.name });
      if (note) setUploadErr(note);
    } catch (e) {
      setUploadErr(e instanceof Error ? e.message : "Upload fail hua");
    } finally {
      setUploading(false);
      setStage("");
      if (fileRef.current) fileRef.current.value = ""; // allow picking the same file again
    }
  };

  const hasCloud = !!getCloudinary();

  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between">
        <label className="text-xs font-bold uppercase tracking-wide text-slate-400">{label}</label>
        <div className="flex gap-1 rounded-lg bg-white/5 p-0.5">
          <button
            type="button"
            onClick={() => setMode("url")}
            className={`flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-bold transition ${
              mode === "url" ? "bg-fuchsia-600 text-white" : "text-slate-400"
            }`}
          >
            <Link2 className="h-3 w-3" /> URL
          </button>
          <button
            type="button"
            onClick={() => setMode("upload")}
            className={`flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-bold transition ${
              mode === "upload" ? "bg-fuchsia-600 text-white" : "text-slate-400"
            }`}
          >
            <Upload className="h-3 w-3" /> Upload
          </button>
        </div>
      </div>

      {mode === "url" ? (
        <input
          value={value.startsWith("idb://") || value.startsWith("data:") ? "" : value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="https://..."
          className="w-full rounded-lg border border-white/10 bg-slate-800/60 px-3 py-2 text-sm text-white placeholder-slate-500 outline-none focus:border-fuchsia-500/60"
        />
      ) : (
        <button
          type="button"
          disabled={uploading}
          onClick={() => fileRef.current?.click()}
          className="flex w-full items-center justify-center gap-2 rounded-lg border border-dashed border-white/20 bg-slate-800/40 px-3 py-3 text-sm font-semibold text-slate-300 transition hover:border-fuchsia-500/60 hover:text-white disabled:opacity-60"
        >
          {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
          {uploading
            ? stage === "checking"
              ? "Video check ho rahi hai..."
              : `Uploading... ${Math.round(pct)}%`
            : value
              ? "Choose another file"
              : "Choose from Gallery / Device"}
        </button>
      )}
      <input
        ref={fileRef}
        type="file"
        accept={accept}
        className="hidden"
        onChange={(e) => handleFile(e.target.files?.[0])}
      />

      {/* Progress bar */}
      {uploading && stage === "uploading" && (
        <div className="mt-2">
          <div className="h-2 w-full overflow-hidden rounded-full bg-white/10">
            <div
              className="h-full rounded-full bg-gradient-to-r from-blue-500 to-violet-500 transition-all duration-200"
              style={{ width: `${Math.max(3, pct)}%` }}
            />
          </div>
          <p className="mt-1 text-[11px] text-slate-400">
            {hasCloud
              ? "Page band mat karna jab tak 100% na ho."
              : "Cloudinary set nahi hai — file sirf is phone me save ho rahi hai."}
          </p>
        </div>
      )}

      {hint && <p className="mt-1 text-[11px] text-slate-500">{hint}</p>}

      {/* Success */}
      {done && !uploading && !uploadErr && (
        <p className="mt-2 flex items-start gap-1.5 text-[12px] font-semibold text-emerald-400">
          <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
          <span>
            {done.shared
              ? "Upload ho gaya ✅ — ab neeche 'Update Anime' / 'Publish Anime' dabao tab save hoga."
              : "File is phone me save hui ✅ — ab neeche 'Update Anime' dabao."}
          </span>
        </p>
      )}

      {/* Warnings about the video file */}
      {warnings.length > 0 && (
        <div className="mt-2 space-y-1.5 rounded-lg bg-amber-500/10 p-3 ring-1 ring-amber-500/30">
          {warnings.map((w, i) => (
            <p key={i} className="flex items-start gap-1.5 text-[12px] leading-relaxed text-amber-200">
              <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-400" />
              <span>{w}</span>
            </p>
          ))}
        </div>
      )}

      {uploadErr && <p className="mt-2 text-[12px] font-semibold text-rose-400">{uploadErr}</p>}

      {value.startsWith("idb://") && (
        <p className="mt-1 text-[11px] font-semibold text-amber-400">
          ⚠️ Ye file sirf isi device par dikhegi. Sabko dikhane ke liye Cloudinary set karo ya URL paste karo.
        </p>
      )}

      {preview === "image" && resolved ? (
        <div className="relative mt-2 inline-block">
          <img src={resolved} alt="preview" className="h-24 rounded-lg object-cover ring-1 ring-white/10" />
          <button
            type="button"
            onClick={() => onChange("")}
            className="absolute -right-2 -top-2 rounded-full bg-rose-600 p-1 text-white"
          >
            <X className="h-3 w-3" />
          </button>
        </div>
      ) : null}

      {preview === "video" && resolved ? (
        <div className="relative mt-2 inline-block">
          <video
            src={resolved}
            className="h-28 rounded-lg bg-black object-cover ring-1 ring-white/10"
            muted
            playsInline
            preload="metadata"
            controls
          />
          <span className="pointer-events-none absolute left-1 top-1 rounded bg-emerald-500 px-1.5 py-0.5 text-[9px] font-bold text-white">
            VIDEO READY
          </span>
          <button
            type="button"
            onClick={() => onChange("")}
            className="absolute -right-2 -top-2 rounded-full bg-rose-600 p-1 text-white"
          >
            <X className="h-3 w-3" />
          </button>
        </div>
      ) : null}
    </div>
  );
}

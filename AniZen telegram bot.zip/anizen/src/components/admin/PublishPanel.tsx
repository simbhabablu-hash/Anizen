import { useState } from "react";
import { Rocket, Download, Copy, Check, Loader2, AlertTriangle, Scissors, Share2 } from "lucide-react";
import { useAnimeStore } from "../../store/AnimeStore";
import { toShareable } from "../../store/media";
import { copyText, shareFile } from "../../utils/share";

export default function PublishPanel() {
  const { rawAnimeList } = useAnimeStore();
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  const [copied, setCopied] = useState("");

  const build = async (compact: boolean) => {
    const { list, skipped, stripped } = await toShareable(rawAnimeList, { compact });
    const text = JSON.stringify({ publishedAt: Date.now(), anime: list }, null, 2);
    const sizeKB = Math.round(new Blob([text]).size / 1024);
    return { text, skipped, stripped, count: list.length, sizeKB };
  };

  const finishMsg = (count: number, sizeKB: number, skipped: number, stripped: number, compact: boolean) => {
    let m = `✅ ${count} anime, file size ${sizeKB} KB.`;
    if (skipped)
      m += ` ⚠️ ${skipped} episode video sirf device par thi, file me nahi gayi — unka URL/Cloudinary use karo.`;
    if (compact && stripped) m += ` ✂️ ${stripped} gallery tasveer hatayi gayi (compact mode) — publish ke baad poster ke liye image URL daal dena.`;
    if (!compact && sizeKB > 60)
      m += ` ⚠️ File badi hai, chat me kat sakti hai — "Copy compact" use karo ya poster ke liye image URL do.`;
    return m;
  };

  const download = async (compact: boolean) => {
    setBusy(true);
    setMsg("");
    try {
      const { text, skipped, stripped, count, sizeKB } = await build(compact);
      const blob = new Blob([text], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "published.json";
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
      setMsg(finishMsg(count, sizeKB, skipped, stripped, compact));
    } catch {
      setMsg("❌ File nahi ban paayi. Dobara try karo.");
    } finally {
      setBusy(false);
    }
  };

  const copy = async (compact: boolean) => {
    setBusy(true);
    setCopied("");
    try {
      const { text, skipped, stripped, count, sizeKB } = await build(compact);
      const ok = await copyText(text);
      if (!ok) {
        setMsg("❌ Copy nahi hua. 'Download file' ya 'Share file' use karo.");
        return;
      }
      setCopied(compact ? "compact" : "full");
      setTimeout(() => setCopied(""), 1800);
      setMsg(finishMsg(count, sizeKB, skipped, stripped, compact));
    } catch {
      setMsg("❌ Copy nahi hua. 'Download file' use karo.");
    } finally {
      setBusy(false);
    }
  };

  const share = async () => {
    setBusy(true);
    setMsg("");
    try {
      const { text, skipped, stripped, count, sizeKB } = await build(false);
      const file = new File([text], "published.json", { type: "application/json" });
      const how = await shareFile(file, "AniZen catalog", `${count} anime`);
      if (how === "shared") setMsg(`✅ File share ho gayi (${count} anime).`);
      else if (how === "downloaded") setMsg("⬇️ Share sheet nahi khuli, file download kar di hai.");
      else setMsg("❌ Share nahi hua. 'Download file' use karo.");
      if (skipped || stripped) {
        setMsg((m) => m + finishMsg(count, sizeKB, skipped, stripped, false).replace(`✅ ${count} anime, file size ${sizeKB} KB.`, ""));
      }
    } catch {
      setMsg("❌ Share nahi hua. 'Download file' use karo.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mb-6 rounded-2xl bg-gradient-to-br from-blue-600/15 to-violet-600/10 p-5 ring-1 ring-blue-500/30">
      <div className="mb-3 flex items-center gap-3">
        <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-600/25 text-blue-300">
          <Rocket className="h-5 w-5" />
        </span>
        <div>
          <h3 className="font-black text-white">Publish for everyone (permanent)</h3>
          <p className="text-xs text-slate-300">Backup file banao ya developer ko bhejo — har phone par hamesha dikhega.</p>
        </div>
      </div>

      <ol className="mb-4 list-decimal space-y-1 pl-5 text-sm text-slate-300">
        <li>
          Neeche <b>Copy compact</b> dabao (chat me bhejne ke liye sabse safe).
        </li>
        <li>
          Copy kiya hua text developer ko bhej do ("isko publish karo" likh ke).
        </li>
        <li>Wo use website ke andar daal ke deploy kar dega — phir har koi wahi anime dekhega.</li>
      </ol>

      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => copy(true)}
          disabled={busy}
          className="flex items-center gap-2 rounded-full bg-gradient-to-r from-blue-600 to-violet-600 px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-blue-600/30 disabled:opacity-60"
        >
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : copied === "compact" ? <Check className="h-4 w-4 text-emerald-300" /> : <Scissors className="h-4 w-4" />}
          {copied === "compact" ? "Copied" : "Copy compact"}
        </button>
        <button
          onClick={() => copy(false)}
          disabled={busy}
          className="flex items-center gap-2 rounded-full bg-white/10 px-5 py-2.5 text-sm font-bold text-white ring-1 ring-white/15 hover:bg-white/15 disabled:opacity-60"
        >
          {copied === "full" ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
          {copied === "full" ? "Copied" : "Copy full JSON"}
        </button>
        <button
          onClick={() => download(false)}
          disabled={busy}
          className="flex items-center gap-2 rounded-full bg-white/10 px-5 py-2.5 text-sm font-bold text-white ring-1 ring-white/15 hover:bg-white/15 disabled:opacity-60"
        >
          <Download className="h-4 w-4" />
          Download file
        </button>
        <button
          onClick={share}
          disabled={busy}
          className="flex items-center gap-2 rounded-full bg-white/10 px-5 py-2.5 text-sm font-bold text-white ring-1 ring-white/15 hover:bg-white/15 disabled:opacity-60"
        >
          <Share2 className="h-4 w-4" />
          Share file
        </button>
      </div>

      {msg && <p className="mt-3 text-sm font-semibold text-slate-200">{msg}</p>}

      <p className="mt-3 flex gap-2 text-xs text-amber-200/90">
        <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
        <span>
          Gallery se li hui tasveer file ko bahut badi bana deti hai aur chat me kat jaati hai. Best tareeka: poster
          ke liye image URL do, video ke liye MP4/YouTube URL — ya Cloudinary set karke gallery se upload karo (tab
          chhota link banta hai).
        </span>
      </p>
    </div>
  );
}

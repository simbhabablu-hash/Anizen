import { useEffect, useMemo, useState } from "react";
import {
  ShieldCheck,
  Cloud,
  CloudOff,
  Copy,
  Check,
  RefreshCw,
  Loader2,
  Wrench,
  AlertTriangle,
  Film,
} from "lucide-react";
import { useAnimeStore } from "../../store/AnimeStore";
import { findUnsharedVideos } from "../../store/media";
import { getCloudinary } from "../../store/cloud";
import { catalogLink, copyText } from "../../utils/share";

function ago(ts: number, now: number): string {
  if (!ts) return "abhi tak nahi";
  const s = Math.max(0, Math.round((now - ts) / 1000));
  if (s < 8) return "abhi-abhi";
  if (s < 60) return `${s} sec pehle`;
  const m = Math.round(s / 60);
  if (m < 60) return `${m} min pehle`;
  return `${Math.round(m / 60)} ghante pehle`;
}

export default function SyncStatusPanel() {
  const {
    rawAnimeList,
    cloudId,
    syncState,
    lastSyncAt,
    remoteMissing,
    enableCloud,
    syncNow,
    refreshNow,
    fixLocalVideos,
  } = useAnimeStore();

  const [now, setNow] = useState(Date.now());
  const [busy, setBusy] = useState(false);
  const [fixing, setFixing] = useState(false);
  const [progress, setProgress] = useState<{ done: number; total: number } | null>(null);
  const [msg, setMsg] = useState<{ kind: "ok" | "err"; text: string } | null>(null);
  const [copied, setCopied] = useState("");

  useEffect(() => {
    const t = window.setInterval(() => setNow(Date.now()), 5000);
    return () => window.clearInterval(t);
  }, []);

  const unshared = useMemo(() => findUnsharedVideos(rawAnimeList), [rawAnimeList]);
  const localOnes = unshared.filter((u) => u.kind === "local");
  const missingOnes = unshared.filter((u) => u.kind === "missing");
  const hasCloudinary = !!getCloudinary();
  // "live" = other phones can really see it: a shared catalog is configured AND it has been published
  const live = !!cloudId && !remoteMissing;
  const needsPublish = !!cloudId && remoteMissing;
  const isNostr = cloudId === "nostr";
  const link = catalogLink();

  const copy = async (text: string, key: string) => {
    if (await copyText(text)) {
      setCopied(key);
      setTimeout(() => setCopied(""), 1600);
    } else {
      window.prompt("Copy this:", text);
    }
  };

  const goLive = async () => {
    setBusy(true);
    setMsg(null);
    try {
      await enableCloud();
      setMsg({ kind: "ok", text: "Publish ho gaya ✅ Ab ye anime sab phones par dikhenge, aur har change auto-update hoga." });
    } catch (e) {
      setMsg({ kind: "err", text: e instanceof Error ? e.message : "Online nahi ho paya" });
    } finally {
      setBusy(false);
    }
  };

  const doRefresh = async () => {
    setBusy(true);
    setMsg(null);
    try {
      syncNow();
      const changed = await refreshNow();
      setMsg({ kind: "ok", text: changed ? "Naya data aa gaya ✅" : "Sab up-to-date hai ✅" });
    } finally {
      setBusy(false);
    }
  };

  const doFix = async () => {
    if (!hasCloudinary) {
      setMsg({
        kind: "err",
        text: "Videos online bhejne ke liye pehle neeche 'Video hosting (Cloudinary)' set karo (free account, 2 min).",
      });
      return;
    }
    setFixing(true);
    setMsg(null);
    setProgress({ done: 0, total: localOnes.length });
    try {
      const r = await fixLocalVideos((done, total) => setProgress({ done, total }));
      if (r.failed === 0) {
        setMsg({ kind: "ok", text: `${r.fixed} video online chali gayi ✅ Ab sab phones par chalegi.` });
      } else {
        setMsg({
          kind: "err",
          text: `${r.fixed} ho gayi, ${r.failed} fail hui. ${r.lastError ?? ""}`.trim(),
        });
      }
    } catch (e) {
      setMsg({ kind: "err", text: e instanceof Error ? e.message : "Fix fail hua" });
    } finally {
      setFixing(false);
      setProgress(null);
    }
  };

  return (
    <div className="mb-6 rounded-2xl bg-slate-900/60 p-5 ring-1 ring-white/10">
      <div className="mb-4 flex items-center gap-3">
        <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-600/20 text-emerald-400">
          <ShieldCheck className="h-6 w-6" />
        </span>
        <div>
          <h3 className="text-lg font-black text-white">Data Safety &amp; Sharing</h3>
          <p className="text-xs text-slate-400">Tumhara data kahan save hai aur sabko dikhega ya nahi.</p>
        </div>
      </div>

      {/* Sharing state */}
      <div
        className={`mb-3 rounded-xl p-4 ring-1 ${
          live ? "bg-emerald-500/10 ring-emerald-500/25" : "bg-rose-500/10 ring-rose-500/25"
        }`}
      >
        <div className="flex flex-wrap items-center gap-3">
          {live ? <Cloud className="h-5 w-5 text-emerald-400" /> : <CloudOff className="h-5 w-5 text-rose-400" />}
          <div className="min-w-0 flex-1">
            <p className={`text-sm font-black ${live ? "text-emerald-300" : "text-rose-300"}`}>
              {live
                ? "LIVE — sabko dikhega"
                : needsPublish
                  ? "PUBLISH NAHI HUA — dusre phones ko kuch nahi dikhega"
                  : "OFFLINE — abhi sirf is phone me hai"}
            </p>
            <p className="text-xs text-slate-400">
              {live
                ? `Last sync: ${ago(lastSyncAt, now)}${syncState === "saving" ? " · saving..." : ""}${syncState === "error" ? " · sync error" : ""}`
                : needsPublish
                  ? rawAnimeList.length > 0
                    ? `Is phone me ${rawAnimeList.length} anime hain par abhi online nahi gaye. Niche button dabao.`
                    : "Online abhi koi anime nahi hai. Pehle anime add karo."
                  : "Dusre phones ko ye anime nahi dikhenge. Niche button se online karo."}
            </p>
          </div>
          {live ? (
            <button
              onClick={doRefresh}
              disabled={busy}
              className="flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-xs font-bold text-white ring-1 ring-white/15 hover:bg-white/15 disabled:opacity-60"
            >
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
              Sync now
            </button>
          ) : (
            <button
              onClick={goLive}
              disabled={busy}
              className="flex items-center gap-2 rounded-full bg-emerald-600 px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-emerald-600/30 hover:bg-emerald-500 disabled:opacity-60"
            >
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Cloud className="h-4 w-4" />}
              {busy ? "Publishing... (thoda time lagega)" : "Publish now — sabke liye"}
            </button>
          )}
        </div>
      </div>

      {/* Permanent link */}
      {live && (
        <div className="mb-3 rounded-xl bg-white/5 p-4 ring-1 ring-white/10">
          <p className="mb-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Sabko ye link bhejo (isse same anime dikhenge)
          </p>
          <div className="flex gap-2">
            <input
              readOnly
              value={link}
              className="min-w-0 flex-1 rounded-lg border border-white/10 bg-slate-800/60 px-3 py-2 text-xs text-white outline-none"
            />
            <button
              onClick={() => copy(link, "link")}
              className="flex shrink-0 items-center gap-1.5 rounded-lg bg-blue-600 px-3 text-xs font-bold text-white hover:bg-blue-500"
            >
              {copied === "link" ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />} Copy
            </button>
          </div>
          <p className="mt-2 text-[11px] leading-relaxed text-slate-500">
            {isNostr ? (
              <>
                Koi special ID ya link nahi chahiye — website ka normal link kholne wale <b>har phone</b> ko
                ye anime apne aap dikhenge (har 20 sec me update hote hain). Data free Nostr relays par save hota
                hai.
              </>
            ) : (
              <>
                Zaroori: ye link <b>isi website address</b> ka hai — hamesha isi link se kholo, ya ID{" "}
                <code className="rounded bg-white/10 px-1 text-slate-300">{cloudId}</code> ko{" "}
                <code className="rounded bg-white/10 px-1 text-slate-300">VITE_CATALOG_ID</code> me daal ke
                redeploy karo.
              </>
            )}
          </p>
        </div>
      )}

      {/* Videos that other phones can't play */}
      {unshared.length === 0 ? (
        <div className="rounded-xl bg-emerald-500/10 p-4 text-sm font-semibold text-emerald-300 ring-1 ring-emerald-500/25">
          ✅ Sab episode videos sab phones par chalengi.
        </div>
      ) : (
        <div className="rounded-xl bg-amber-500/10 p-4 ring-1 ring-amber-500/30">
          <div className="flex items-start gap-3">
            <Film className="mt-0.5 h-5 w-5 shrink-0 text-amber-400" />
            <div className="min-w-0 flex-1">
              <p className="text-sm font-black text-amber-300">
                {unshared.length} episode dusre phones par NAHI chalenge
              </p>
              <ul className="mt-1 space-y-0.5 text-xs text-amber-100/80">
                {unshared.slice(0, 6).map((u) => (
                  <li key={`${u.animeId}-${u.episodeId}`}>
                    • {u.animeTitle} — Ep {u.episodeNumber}{" "}
                    <span className="text-amber-300/70">
                      ({u.kind === "local" ? "sirf is phone me" : "video link nahi hai"})
                    </span>
                  </li>
                ))}
                {unshared.length > 6 && <li>• ...aur {unshared.length - 6} aur</li>}
              </ul>
            </div>
          </div>

          {localOnes.length > 0 && (
            <button
              onClick={doFix}
              disabled={fixing}
              className="mt-3 flex w-full items-center justify-center gap-2 rounded-full bg-amber-500 px-5 py-3 text-sm font-black text-slate-950 shadow-lg shadow-amber-500/30 transition hover:bg-amber-400 disabled:opacity-70"
            >
              {fixing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wrench className="h-4 w-4" />}
              {fixing && progress
                ? `Uploading ${Math.min(progress.done + 1, progress.total)}/${progress.total}...`
                : `Fix now — ${localOnes.length} video online karo`}
            </button>
          )}

          {!hasCloudinary && localOnes.length > 0 && (
            <p className="mt-2 flex gap-2 text-xs text-amber-200/90">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>
                Fix chalane ke liye pehle <b>Video hosting (Cloudinary)</b> set karo (neeche). Ya episode me video ka
                URL (MP4/YouTube) paste karo.
              </span>
            </p>
          )}
          {missingOnes.length > 0 && (
            <p className="mt-2 text-xs text-amber-200/80">
              {missingOnes.length} episode me video hai hi nahi — unhe Edit karke link daalo.
            </p>
          )}
        </div>
      )}

      {msg && (
        <p className={`mt-3 text-sm font-semibold ${msg.kind === "ok" ? "text-emerald-400" : "text-rose-400"}`}>
          {msg.text}
        </p>
      )}
    </div>
  );
}

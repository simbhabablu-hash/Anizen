// ---------------------------------------------------------------------------
// AniZen catalog connection — set ONE of these so every phone sees the same anime.
//
// Easiest (recommended): don't touch this file.
// In Vercel → Settings → Environment Variables, add ONE of:
//   VITE_WORKER_URL   = https://your-worker.yourname.workers.dev
//   VITE_API_URL      = https://your-anizen-api.onrender.com
//   VITE_CATALOG_ID   = kvdb:abc123xyz   (from the 1-tap "Enable Online Database")
// Then redeploy. The site auto-connects on every phone.
//
// Or paste directly into the HARDCODED values below — same effect.
// ---------------------------------------------------------------------------

// You can hard-code the shared catalog here if you don't want to use env vars.
// Format for KVdb: "kvdb:XXXX"  (admin gets this by tapping "Enable Online Database" once).
const HARDCODED_CATALOG_ID = "";
const HARDCODED_WORKER_URL = "";
const HARDCODED_API_URL = "";

/** Set to true to auto-create a shared KVdb bucket the first time anyone visits
 *  the site, so every phone instantly shares the same anime without any setup. */
export const AUTO_SHARED_CATALOG = true;

const env = (import.meta.env ?? {}) as {
  VITE_API_URL?: string;
  VITE_WORKER_URL?: string;
  VITE_CATALOG_ID?: string;
  VITE_NOSTR_SEED?: string;
  VITE_NOSTR_RELAYS?: string;
};

/**
 * NOSTR (default shared catalog, zero setup).
 * The catalog is stored as signed events on free public Nostr relays. The signing key
 * is derived from NOSTR_SEED, so every visitor automatically knows where to read from.
 * Change the seed to start a brand-new empty catalog.
 */
export const NOSTR_SEED: string = (env.VITE_NOSTR_SEED || "").trim() || "anizen-by-balvir-coder-v1";

const DEFAULT_RELAYS = [
  "wss://relay.damus.io",
  "wss://nos.lol",
  "wss://relay.primal.net",
  "wss://relay.snort.social",
  "wss://nostr.mom",
];
export const NOSTR_RELAYS: string[] = (env.VITE_NOSTR_RELAYS || "")
  .split(",")
  .map((s) => s.trim())
  .filter((s) => /^wss:\/\//.test(s)).length
  ? (env.VITE_NOSTR_RELAYS || "")
      .split(",")
      .map((s) => s.trim())
      .filter((s) => /^wss:\/\//.test(s))
  : DEFAULT_RELAYS;

const clean = (v?: string | null) => (v || "").trim().replace(/\/$/, "");

/** Pre-configured catalog id (e.g. "kvdb:xxx") shared by every visitor. */
export const SHARED_CATALOG_ID: string = clean(env.VITE_CATALOG_ID) || clean(HARDCODED_CATALOG_ID);

/** Cloudflare Worker URL for the shared catalog. */
export const WORKER_URL: string = clean(env.VITE_WORKER_URL) || clean(HARDCODED_WORKER_URL);

/** Node + Express + SQLite backend URL (see /server folder). */
export const API_URL: string = clean(env.VITE_API_URL) || clean(HARDCODED_API_URL);

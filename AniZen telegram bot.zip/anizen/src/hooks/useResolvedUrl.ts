import { useEffect, useState } from "react";
import { resolveRef } from "../store/media";

/** Resolve an idb:// media reference (or plain URL) into a usable src. */
export function useResolvedUrl(ref: string | undefined | null): string {
  const [url, setUrl] = useState(ref && !ref.startsWith("idb://") ? ref : "");

  useEffect(() => {
    let mounted = true;
    resolveRef(ref).then((u) => mounted && setUrl(u));
    return () => {
      mounted = false;
    };
  }, [ref]);

  return url;
}

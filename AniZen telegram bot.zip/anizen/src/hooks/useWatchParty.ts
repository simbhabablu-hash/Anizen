import { useCallback, useEffect, useRef, useState } from "react";
import { PartyConnection, cleanCode, makeCode, makePeerId, CODE_LEN, type PartyMsg } from "../store/party";

export interface PartyMember {
  id: string;
  name: string;
  host: boolean;
}

export interface ChatMsg {
  id: string;
  name: string;
  text: string;
  mine: boolean;
  ts: number;
}

export type PartyStatus = "idle" | "connecting" | "live" | "error";

interface Opts {
  /** Open this anime/episode on screen. Return false if the anime is not in this device's catalog. */
  onRemoteEpisode: (animeId: string, ep: number) => boolean;
  /** What this device is watching right now (null if not on the watch page). */
  getCurrent: () => { animeId: string; ep: number } | null;
}

const SAVE_KEY = "aniverse:party";
const NAME_KEY = "aniverse:party-name";

export function savedPartyName(): string {
  try {
    const n = localStorage.getItem(NAME_KEY);
    if (n) return n;
  } catch {
    /* ignore */
  }
  return `Guest${Math.floor(100 + Math.random() * 900)}`;
}

function storeName(n: string) {
  try {
    localStorage.setItem(NAME_KEY, n);
  } catch {
    /* ignore */
  }
}

export function useWatchParty(opts: Opts) {
  const optsRef = useRef(opts);
  optsRef.current = opts;

  const peerIdRef = useRef(makePeerId());
  const connRef = useRef<PartyConnection | null>(null);
  const nameRef = useRef("Guest");
  const hostRef = useRef(false);
  const membersRef = useRef(new Map<string, PartyMember & { seen: number }>());
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const detachRef = useRef<(() => void) | null>(null);
  const suppressUntil = useRef(0);
  const expectSeek = useRef(0);
  const pending = useRef<{ t: number; playing: boolean } | null>(null);
  const epKey = useRef("");
  const navRef = useRef<{ key: string; at: number }>({ key: "", at: 0 });
  const lastHostSeen = useRef(0);
  const timers = useRef<number[]>([]);

  const [room, setRoom] = useState<{ code: string; host: boolean } | null>(null);
  const [status, setStatus] = useState<PartyStatus>("idle");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [members, setMembers] = useState<PartyMember[]>([]);
  const [chat, setChat] = useState<ChatMsg[]>([]);
  const [videoAttached, setVideoAttached] = useState(false);
  const [blocked, setBlocked] = useState(false);
  const [roomAnimeId, setRoomAnimeId] = useState<string | null>(null);
  const [selfName, setSelfName] = useState("");

  /* ---------------- applying what others did to OUR player ---------------- */

  const applyToVideo = useCallback((t: number, playing: boolean) => {
    const v = videoRef.current;
    if (!v || v.readyState < 1) {
      pending.current = { t, playing }; // video not ready yet: do it as soon as it is
      return;
    }
    suppressUntil.current = Date.now() + 900; // our own play/pause events below must not echo back
    const target = t + (playing ? 0.5 : 0); // rough network delay
    const drift = Math.abs(v.currentTime - target);
    if (isFinite(target) && drift > (playing ? 1.5 : 0.4)) {
      expectSeek.current += 1;
      window.setTimeout(() => {
        expectSeek.current = 0;
      }, 3000);
      try {
        v.currentTime = target;
      } catch {
        expectSeek.current = 0;
      }
    }
    if (playing && v.paused) {
      v.play()
        .then(() => setBlocked(false))
        .catch(() => setBlocked(true)); // browser wants a tap before it lets us start playback
    } else if (!playing && !v.paused) {
      v.pause();
    }
  }, []);

  /** Make sure we are on the same anime+episode. Returns true if already there. */
  const ensureEpisode = useCallback((animeId: string, ep: number, start?: { t: number; playing: boolean }) => {
    const cur = optsRef.current.getCurrent();
    setRoomAnimeId(animeId);
    if (cur && cur.animeId === animeId && cur.ep === ep) return true;
    const key = `${animeId}:${ep}`;
    epKey.current = key; // so opening it ourselves is not announced back to the room
    if (start) pending.current = start;
    const nav = navRef.current;
    if (!(nav.key === key && Date.now() - nav.at < 4000)) {
      navRef.current = { key, at: Date.now() };
      const found = optsRef.current.onRemoteEpisode(animeId, ep);
      setNotice(
        found ? "" : "Ye anime tumhare catalog me nahi mila. Page refresh karo (host ne abhi add kiya hoga).",
      );
    }
    return false;
  }, []);

  /* ---------------- sending ---------------- */

  const sendState = useCallback(() => {
    const c = connRef.current;
    if (!c) return;
    const v = videoRef.current;
    const cur = optsRef.current.getCurrent();
    void c.send({
      k: "state",
      host: hostRef.current,
      animeId: cur?.animeId,
      ep: cur?.ep,
      t: v ? v.currentTime : undefined,
      playing: v ? !v.paused : undefined,
    });
  }, []);

  /* ---------------- incoming messages ---------------- */

  const touchMember = useCallback((m: PartyMsg) => {
    const map = membersRef.current;
    const had = map.get(m.from);
    const next = { id: m.from, name: m.name || "Guest", host: !!m.host, seen: Date.now() };
    map.set(m.from, next);
    if (!had || had.name !== next.name || had.host !== next.host) {
      setMembers(Array.from(map.values()).map(({ id, name, host }) => ({ id, name, host })));
    }
  }, []);

  const handleMsg = useCallback(
    (m: PartyMsg) => {
      setStatus((s) => (s === "connecting" || s === "error" ? "live" : s));
      if (m.k !== "leave") touchMember(m);
      if (m.host) lastHostSeen.current = Date.now();
      const imHost = hostRef.current;
      const c = connRef.current;

      switch (m.k) {
        case "hello":
          // newcomer: say who we are, and let the host (or whoever is left) tell them what is playing
          if (c) void c.send({ k: "ping", host: imHost });
          if (imHost || Date.now() - lastHostSeen.current > 12000) sendState();
          break;

        case "leave":
          if (membersRef.current.delete(m.from)) {
            setMembers(Array.from(membersRef.current.values()).map(({ id, name, host }) => ({ id, name, host })));
          }
          break;

        case "state": {
          if (imHost) break; // the host's own player is the source of truth
          if (!m.animeId || !m.ep) break;
          const there = ensureEpisode(m.animeId, m.ep, { t: m.t ?? 0, playing: !!m.playing });
          if (there && m.t !== undefined) applyToVideo(m.t, !!m.playing);
          break;
        }

        case "action": {
          if (m.a === "episode") {
            if (m.animeId && m.ep) ensureEpisode(m.animeId, m.ep, { t: 0, playing: true });
            break;
          }
          const playing = m.a === "play" ? true : m.a === "pause" ? false : !!m.playing;
          if (m.animeId && m.ep) {
            if (!ensureEpisode(m.animeId, m.ep, { t: m.t ?? 0, playing })) break;
          }
          if (m.t !== undefined) applyToVideo(m.t, playing);
          break;
        }

        case "chat": {
          const text = String(m.text ?? "").slice(0, 300);
          if (!text) break;
          setChat((prev) =>
            [...prev, { id: `${m.from}-${m.ts}`, name: m.name || "Guest", text, mine: false, ts: m.ts }].slice(-100),
          );
          break;
        }
        default:
          break;
      }
    },
    [touchMember, ensureEpisode, applyToVideo, sendState],
  );

  /* ---------------- hooking into the <video> element ---------------- */

  const attachVideo = useCallback(
    (el: HTMLVideoElement | null) => {
      detachRef.current?.();
      detachRef.current = null;
      videoRef.current = el;
      setVideoAttached(!!el);
      if (!el) return;

      const tell = (a: "play" | "pause" | "seek") => {
        const c = connRef.current;
        if (!c) return;
        const cur = optsRef.current.getCurrent();
        void c.send({ k: "action", a, t: el.currentTime, playing: !el.paused, animeId: cur?.animeId, ep: cur?.ep });
      };
      const onPlay = () => {
        setBlocked(false);
        if (Date.now() >= suppressUntil.current) tell("play");
      };
      const onPause = () => {
        if (Date.now() >= suppressUntil.current) tell("pause");
      };
      const onSeeked = () => {
        if (expectSeek.current > 0) {
          expectSeek.current -= 1; // that seek was us following someone else
          return;
        }
        tell("seek");
      };
      const onMeta = () => {
        const p = pending.current;
        if (p) {
          pending.current = null;
          applyToVideo(p.t, p.playing);
        }
      };

      el.addEventListener("play", onPlay);
      el.addEventListener("pause", onPause);
      el.addEventListener("seeked", onSeeked);
      el.addEventListener("loadedmetadata", onMeta);
      detachRef.current = () => {
        el.removeEventListener("play", onPlay);
        el.removeEventListener("pause", onPause);
        el.removeEventListener("seeked", onSeeked);
        el.removeEventListener("loadedmetadata", onMeta);
      };
      if (el.readyState >= 1) onMeta();
    },
    [applyToVideo],
  );

  /* ---------------- room lifecycle ---------------- */

  const clearTimers = () => {
    timers.current.forEach((t) => window.clearInterval(t));
    timers.current = [];
  };

  const teardown = useCallback((sayBye: boolean) => {
    const c = connRef.current;
    connRef.current = null;
    clearTimers();
    if (!c) return;
    if (sayBye) {
      void c
        .send({ k: "leave" })
        .catch(() => 0)
        .finally(() => c.stop());
    } else {
      c.stop();
    }
  }, []);

  const connect = useCallback(
    async (code: string, host: boolean, name: string) => {
      teardown(false);
      const nm = name.trim() || savedPartyName();
      storeName(nm);
      nameRef.current = nm;
      setSelfName(nm);
      hostRef.current = host;
      membersRef.current.clear();
      setMembers([]);
      setChat([]);
      setError("");
      setNotice("");
      setBlocked(false);
      setRoomAnimeId(null);
      epKey.current = "";
      pending.current = null;
      lastHostSeen.current = host ? Date.now() : 0;
      setRoom({ code, host });
      setStatus("connecting");
      try {
        sessionStorage.setItem(SAVE_KEY, JSON.stringify({ code, host, name: nm }));
      } catch {
        /* ignore */
      }

      const conn = new PartyConnection(code, peerIdRef.current, () => nameRef.current, handleMsg);
      connRef.current = conn;
      conn.start();

      const ok = await conn.send({ k: "hello", host });
      if (connRef.current !== conn) return; // left while connecting
      if (ok === 0) {
        setStatus("error");
        setError("Koi relay connect nahi hua. Internet check karo, phir dobara try karo.");
      } else {
        setStatus("live");
      }

      // host keeps everybody aligned; everybody announces they are still here
      timers.current.push(
        window.setInterval(() => {
          if (hostRef.current) sendState();
        }, 4000),
        window.setInterval(() => {
          const c = connRef.current;
          if (c) void c.send({ k: "ping", host: hostRef.current });
          const now = Date.now();
          let changed = false;
          membersRef.current.forEach((mem, id) => {
            if (now - mem.seen > 25000) {
              membersRef.current.delete(id);
              changed = true;
            }
          });
          if (changed) {
            setMembers(Array.from(membersRef.current.values()).map(({ id, name: n, host: h }) => ({ id, name: n, host: h })));
          }
        }, 8000),
      );
    },
    [teardown, handleMsg, sendState],
  );

  const create = useCallback(
    (name: string): string => {
      const code = makeCode();
      void connect(code, true, name);
      return code;
    },
    [connect],
  );

  const join = useCallback(
    (codeRaw: string, name: string): boolean => {
      const code = cleanCode(codeRaw);
      if (code.length !== CODE_LEN) {
        setError(`Code ${CODE_LEN} akshar ka hota hai.`);
        return false;
      }
      void connect(code, false, name);
      return true;
    },
    [connect],
  );

  const leave = useCallback(() => {
    teardown(true);
    setRoom(null);
    setStatus("idle");
    setMembers([]);
    setChat([]);
    setError("");
    setNotice("");
    setBlocked(false);
    setRoomAnimeId(null);
    membersRef.current.clear();
    try {
      sessionStorage.removeItem(SAVE_KEY);
    } catch {
      /* ignore */
    }
  }, [teardown]);

  // Page refreshed while in a party: slip back into the same room
  useEffect(() => {
    try {
      const raw = sessionStorage.getItem(SAVE_KEY);
      if (raw) {
        const s = JSON.parse(raw) as { code: string; host: boolean; name: string };
        if (s?.code && cleanCode(s.code).length === CODE_LEN) void connect(s.code, !!s.host, s.name || "");
      }
    } catch {
      /* ignore */
    }
    return () => teardown(false);
  }, [connect, teardown]);

  /** Called whenever this device opens an episode. Tells the room, unless we were just following it. */
  const announceEpisode = useCallback((animeId: string, ep: number) => {
    setRoomAnimeId(animeId);
    const c = connRef.current;
    if (!c) return;
    const key = `${animeId}:${ep}`;
    if (epKey.current === key) return;
    epKey.current = key;
    void c.send({ k: "action", a: "episode", animeId, ep, t: 0, playing: true });
  }, []);

  const sendChat = useCallback((text: string) => {
    const t = text.trim().slice(0, 300);
    const c = connRef.current;
    if (!t || !c) return;
    setChat((prev) =>
      [...prev, { id: `me-${Date.now()}`, name: nameRef.current, text: t, mine: true, ts: Date.now() }].slice(-100),
    );
    void c.send({ k: "chat", text: t });
  }, []);

  const tapToSync = useCallback(() => {
    const v = videoRef.current;
    if (!v) return;
    v.play()
      .then(() => setBlocked(false))
      .catch(() => {});
  }, []);

  return {
    room,
    status,
    error,
    notice,
    members,
    chat,
    videoAttached,
    blocked,
    roomAnimeId,
    selfName,
    create,
    join,
    leave,
    attachVideo,
    announceEpisode,
    sendChat,
    tapToSync,
    clearError: () => setError(""),
  };
}

export type WatchParty = ReturnType<typeof useWatchParty>;

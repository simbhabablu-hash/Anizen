import { useCallback, useEffect, useState } from "react";
import type { Anime } from "../types";

const LIST_KEY = "aniverse:watchlist";
const HISTORY_KEY = "aniverse:history";
const MAX_HISTORY = 300;

/** One watched episode. Only ids are stored, so history stays tiny and never goes stale. */
export interface HistoryItem {
  animeId: string;
  episode: number;
  /** seconds watched so far (0 if unknown, e.g. YouTube/Drive embeds) */
  position: number;
  /** episode length in seconds (0 if unknown) */
  duration: number;
  watchedAt: number;
}

/** "Continue Watching" card: latest unfinished episode of an anime. */
export interface ContinueItem {
  anime: Anime;
  episode: number;
  progress: number; // 0..1
  updatedAt: number;
}

export function isFinished(h: Pick<HistoryItem, "position" | "duration">): boolean {
  return h.duration > 0 && h.position >= Math.max(h.duration * 0.95, h.duration - 15);
}

export function progressOf(h: Pick<HistoryItem, "position" | "duration">): number {
  return h.duration > 0 ? Math.max(0, Math.min(1, h.position / h.duration)) : 0;
}

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write<T>(key: string, value: T) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* ignore */
  }
}

export function useWatchlist() {
  const [list, setList] = useState<Anime[]>(() => read<Anime[]>(LIST_KEY, []));
  const [history, setHistory] = useState<HistoryItem[]>(() => {
    const h = read<HistoryItem[]>(HISTORY_KEY, []);
    return Array.isArray(h) ? h.filter((x) => x && x.animeId && x.episode > 0) : [];
  });

  useEffect(() => write(LIST_KEY, list), [list]);
  useEffect(() => write(HISTORY_KEY, history), [history]);

  /* ---------------- Saved ---------------- */

  const inList = useCallback((id: string) => list.some((a) => a.id === id), [list]);

  const toggle = useCallback((anime: Anime) => {
    setList((prev) =>
      prev.some((a) => a.id === anime.id) ? prev.filter((a) => a.id !== anime.id) : [anime, ...prev],
    );
  }, []);

  /* ---------------- History ---------------- */

  /** An episode was opened: make sure it is in history (keeps any progress it already has). */
  const touchHistory = useCallback((animeId: string, episode: number) => {
    setHistory((prev) => {
      const i = prev.findIndex((h) => h.animeId === animeId && h.episode === episode);
      const now = Date.now();
      if (i >= 0) {
        if (i === 0) return [{ ...prev[0], watchedAt: now }, ...prev.slice(1)];
        return [{ ...prev[i], watchedAt: now }, ...prev.filter((_, k) => k !== i)];
      }
      return [{ animeId, episode, position: 0, duration: 0, watchedAt: now }, ...prev].slice(0, MAX_HISTORY);
    });
  }, []);

  /** Real playback progress, reported by the player. */
  const recordProgress = useCallback((animeId: string, episode: number, position: number, duration: number) => {
    if (!(duration > 0) || !isFinite(position) || !isFinite(duration)) return;
    setHistory((prev) => {
      const item: HistoryItem = {
        animeId,
        episode,
        position: Math.max(0, Math.min(position, duration)),
        duration,
        watchedAt: Date.now(),
      };
      const i = prev.findIndex((h) => h.animeId === animeId && h.episode === episode);
      if (i === 0) return [item, ...prev.slice(1)];
      return [item, ...prev.filter((_, k) => k !== i)].slice(0, MAX_HISTORY);
    });
  }, []);

  const removeHistory = useCallback((animeId: string, episode?: number) => {
    setHistory((prev) => prev.filter((h) => !(h.animeId === animeId && (episode === undefined || h.episode === episode))));
  }, []);

  const clearHistory = useCallback(() => setHistory([]), []);

  return {
    list,
    history,
    inList,
    toggle,
    touchHistory,
    recordProgress,
    removeHistory,
    clearHistory,
  };
}

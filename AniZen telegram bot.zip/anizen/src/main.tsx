import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";
import { AnimeProvider } from "./store/AnimeStore";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <AnimeProvider>
      <App />
    </AnimeProvider>
  </StrictMode>
);

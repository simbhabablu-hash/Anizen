// Owner contact handles shown in the footer. Change them here and they update everywhere.
export const TELEGRAM_USER = "coder6883";
export const INSTAGRAM_USER = "m_a_j_h_a________";

export const TELEGRAM_URL = `https://t.me/${TELEGRAM_USER}`;
export const INSTAGRAM_URL = `https://www.instagram.com/${INSTAGRAM_USER}/`;

// Aapke Telegram BOT ka link (e.g. https://t.me/AniZenBot).
// Vercel env var VITE_TELEGRAM_BOT_URL se set karo; khaali = button chhup jayega.
export const TELEGRAM_BOT_URL: string = ((import.meta as any).env?.VITE_TELEGRAM_BOT_URL || "").trim();

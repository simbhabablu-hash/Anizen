import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import type { Anime } from "../types";
import { SEED_ANIME } from "./seed";
import { idbGet, idbSet } from "./db";
import { resolveAnime, uid, toShareable, uploadLocalVideos } from "./media";
import {
  createCatalog,
  explainError,
  fetchCatalog,
  getCatalogId,
  saveCatalog,
  setCatalogId,
  setWorkerCfg,
  usesWorker,
  WORKER_CLOUD_ID,
  NOSTR_CLOUD_ID,
} from "./cloud";
import { NoCatalogError } from "./nostr";
import publishedJson from "../data/published.json";

export { uid };

const STORE_KEY = "aniverse:anime";
const INIT_KEY = "aniverse:initialized";
const PUB_KEY = "aniverse:published-at";

// Catalog bundled inside the website itself (same for every visitor, on every phone).
const PUBLISHED = publishedJson as unknown as { publishedAt: number; anime: Anime[] };

export type SyncState = "idle" | "saving" | "saved" | "error";

interface AnimeStoreCtx {
  animeList: Anime[]; // resolved for viewing
  rawAnimeList: Anime[]; // original refs, for admin
  loading: boolean;
  saveError: boolean;
  cloudId: string;
  syncState: SyncState;
  localOnly: number; // episodes whose video exists only on this device
  getById: (id: string) => Anime | undefined;
  addAnime: (a: Anime) => void;
  updateAnime: (a: Anime) => void;
  deleteAnime: (id: string) => void;
  importAnime: (list: Anime[], mode: "replace" | "merge") => void;
  allGenres: string[];
  resetToSeed: () => void;
  clearAll: () => void;
  enableCloud: () => Promise<string>;
  connectCloud: (id: string) => Promise<void>;
  disconnectCloud: () => void;
  syncNow: () => void;
  lastSyncAt: number;
  /** Shared catalog was reachable but nothing has been published there yet */
  remoteMissing: boolean;
  refreshNow: () => Promise<boolean>;
  fixLocalVideos: (
    onProgress?: (done: number, total: number) => void,
  ) => Promise<{ fixed: number; failed: number; lastError?: string }>;
}

const Ctx = createContext<AnimeStoreCtx | null>(null);

function withTimeout<T>(p: Promise<T>, ms: number): Promise<T> {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error("timeout")), ms);
    p.then(
      (v) => {
        clearTimeout(t);
        resolve(v);
      },
      (e) => {
        clearTimeout(t);
        reject(e);
      },
    );
  });
}

/** Cheap fingerprint of a catalog so we only re-render when something really changed. */
function sigOf(list: Anime[]): string {
  const s = JSON.stringify(list);
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return `${list.length}:${s.length}:${h}`;
}

const REFRESH_MS = 20000;

export function AnimeProvider({ children }: { children: ReactNode }) {
  const lastRemoteSig = useRef("");
  const pushing = useRef(false);
  const retryTimer = useRef<number | null>(null);
  const [lastSyncAt, setLastSyncAt] = useState(0);
  const [remoteMissing, setRemoteMissing] = useState(false);
  const [rawList, setRawList] = useState<Anime[]>([]);
  const [viewList, setViewList] = useState<Anime[]>([]);
  const [loading, setLoading] = useState(true);
  const [saveError, setSaveError] = useState(false);
  const [cloudId, setCloudIdState] = useState<string>(() => (usesWorker() ? WORKER_CLOUD_ID : getCatalogId()));
  const [syncState, setSyncState] = useState<SyncState>("idle");
  const [localOnly, setLocalOnly] = useState(0);

  const hydrated = useRef(false);
  const shouldPush = useRef(false);
  const cloudIdRef = useRef(cloudId);
  const rawRef = useRef<Anime[]>([]);
  rawRef.current = rawList;

  useEffect(() => () => {
    if (retryTimer.current != null) window.clearTimeout(retryTimer.current);
  }, []);

  // Initial load: shared online catalog first (so every phone sees the same anime)
  useEffect(() => {
    let mounted = true;
    (async () => {
      const id = getCatalogId();
      const worker = usesWorker();
      let initial: Anime[] | null = null;

      // Everyone (visitors AND admin) reads the same shared catalog. Visitors never
      // create their own database, so no phone can end up on a private empty one.
      const effectiveId = id;

      if (effectiveId || worker) {
        try {
          initial = await withTimeout(fetchCatalog(effectiveId), 20000);
          lastRemoteSig.current = sigOf(initial);
          setRemoteMissing(false);
          setLastSyncAt(Date.now());
          await idbSet(STORE_KEY, initial);
          await idbSet(INIT_KEY, true);
        } catch (e) {
          // If a stale/broken Worker/API was configured on this browser, do not
          // trap this device in a private local database. Fall back to the
          // built-in shared Nostr catalog so new visitors can still see the same data.
          if (effectiveId !== NOSTR_CLOUD_ID) {
            try {
              initial = await withTimeout(fetchCatalog(NOSTR_CLOUD_ID), 20000);
              cloudIdRef.current = NOSTR_CLOUD_ID;
              setCloudIdState(NOSTR_CLOUD_ID);
              setCatalogId(NOSTR_CLOUD_ID);
              lastRemoteSig.current = sigOf(initial);
              setRemoteMissing(false);
              setLastSyncAt(Date.now());
              await idbSet(STORE_KEY, initial);
              await idbSet(INIT_KEY, true);
            } catch {
              if (e instanceof NoCatalogError) setRemoteMissing(true);
              initial = null;
            }
          } else {
            if (e instanceof NoCatalogError) setRemoteMissing(true);
            initial = null;
          }
        }
      }

      // Bundled/published catalog only when NO shared server is configured, so
      // a real backend / online DB never gets overwritten by demo content.
      if (!initial && !effectiveId && !worker && PUBLISHED.anime.length > 0) {
        const seenAt = (await idbGet<number>(PUB_KEY)) || 0;
        if (PUBLISHED.publishedAt > seenAt) {
          initial = PUBLISHED.anime;
          await idbSet(STORE_KEY, initial);
          await idbSet(INIT_KEY, true);
          await idbSet(PUB_KEY, PUBLISHED.publishedAt);
        }
      }

      if (!initial) {
        const stored = await idbGet<Anime[]>(STORE_KEY);
        if (Array.isArray(stored)) initial = stored;
        else initial = []; // never auto-seed demo titles anymore
        await idbSet(INIT_KEY, true);
      }

      if (!mounted) return;
      hydrated.current = true;
      setRawList(initial);
      setLoading(false);
    })();
    return () => {
      mounted = false;
    };
  }, []);

  // Persist on device + push to shared catalog when the admin changed something
  useEffect(() => {
    if (!hydrated.current) return;
    (async () => {
      const ok = await idbSet(STORE_KEY, rawList);
      await idbSet(INIT_KEY, true);
      setSaveError(!ok);

      if (shouldPush.current && cloudIdRef.current && !pushing.current) {
        shouldPush.current = false;
        setSyncState("saving");
        pushing.current = true;
        try {
          const { list, skipped } = await toShareable(rawList);
          try {
            await saveCatalog(cloudIdRef.current, list);
          } catch (primaryError) {
            // Automatic public fallback: if the configured backend is down or stale,
            // retry the same catalog on the built-in shared Nostr catalog. This prevents
            // gallery uploads from silently becoming visible only on the admin phone.
            if (cloudIdRef.current !== NOSTR_CLOUD_ID) {
              await saveCatalog(NOSTR_CLOUD_ID, list);
              setCatalogId(NOSTR_CLOUD_ID);
              cloudIdRef.current = NOSTR_CLOUD_ID;
              setCloudIdState(NOSTR_CLOUD_ID);
            } else {
              throw primaryError;
            }
          }
          lastRemoteSig.current = sigOf(list);
          setLastSyncAt(Date.now());
          setRemoteMissing(false);
          setLocalOnly(skipped);
          setSyncState("saved");
        } catch {
          // Keep the pending write alive and retry automatically instead of leaving
          // the anime only in IndexedDB on this device.
          shouldPush.current = true;
          setSyncState("error");
          if (retryTimer.current == null) {
            retryTimer.current = window.setTimeout(() => {
              retryTimer.current = null;
              setRawList((prev) => [...prev]);
            }, 5000);
          }
        } finally {
          pushing.current = false;
        }
      }
    })();
  }, [rawList]);

  // Resolve media refs for display
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const resolved = await Promise.all(rawList.map(resolveAnime));
      if (!cancelled) setViewList(resolved);
    })();
    return () => {
      cancelled = true;
    };
  }, [rawList]);

  const mutate = useCallback((fn: (prev: Anime[]) => Anime[]) => {
    shouldPush.current = true;
    setRawList(fn);
  }, []);

  const getById = useCallback((id: string) => viewList.find((a) => a.id === id), [viewList]);
  const addAnime = useCallback((a: Anime) => mutate((prev) => [a, ...prev]), [mutate]);
  const updateAnime = useCallback(
    (a: Anime) => mutate((prev) => prev.map((x) => (x.id === a.id ? a : x))),
    [mutate],
  );
  const deleteAnime = useCallback(
    (id: string) => mutate((prev) => prev.filter((x) => x.id !== id)),
    [mutate],
  );
  const importAnime = useCallback(
    (list: Anime[], mode: "replace" | "merge") =>
      mutate((prev) => {
        if (mode === "replace") return list;
        const map = new Map(prev.map((a) => [a.id, a]));
        list.forEach((a) => map.set(a.id, a));
        return Array.from(map.values());
      }),
    [mutate],
  );
  const resetToSeed = useCallback(() => mutate(() => SEED_ANIME), [mutate]);
  const clearAll = useCallback(() => mutate(() => []), [mutate]);

  const enableCloud = useCallback(async () => {
    setSyncState("saving");
    try {
      const { list, skipped } = await toShareable(rawRef.current);
      const id = await createCatalog(list);
      setCatalogId(id);
      cloudIdRef.current = id;
      setCloudIdState(id);
      lastRemoteSig.current = sigOf(list);
      setLastSyncAt(Date.now());
      setRemoteMissing(false);
      setLocalOnly(skipped);
      setSyncState("saved");
      return id;
    } catch (e) {
      setSyncState("error");
      throw new Error(explainError(e));
    }
  }, []);

  const connectCloud = useCallback(async (id: string) => {
    setSyncState("saving");
    try {
      const list = await fetchCatalog(id);
      setCatalogId(id);
      cloudIdRef.current = id;
      setCloudIdState(id);
      setRawList(list); // no push: we just loaded it
      setSyncState("saved");
    } catch (e) {
      setSyncState("error");
      throw new Error(explainError(e));
    }
  }, []);

  const disconnectCloud = useCallback(() => {
    setWorkerCfg("", "");
    setCatalogId("");
    cloudIdRef.current = "";
    setCloudIdState("");
    setSyncState("idle");
  }, []);

  const syncNow = useCallback(() => {
    shouldPush.current = true;
    setRawList((prev) => [...prev]);
  }, []);

  /**
   * Pull the latest shared catalog. Returns true if the list changed.
   * Safe by design: it NEVER overwrites a device that still holds local-only media
   * (the admin's phone) or has an unsaved change in flight.
   */
  const refreshNow = useCallback(async (): Promise<boolean> => {
    const id = cloudIdRef.current;
    if (!hydrated.current || (!id && !usesWorker())) return false;
    if (shouldPush.current || pushing.current) return false;
    try {
      const remote = await withTimeout(fetchCatalog(id), 20000);
      const sig = sigOf(remote);
      setLastSyncAt(Date.now());
      setRemoteMissing(false);
      if (sig === lastRemoteSig.current) return false;
      const hasLocalMedia = rawRef.current.some(
        (a) =>
          a.poster?.startsWith("idb://") ||
          a.banner?.startsWith("idb://") ||
          a.thumbnail?.startsWith("idb://") ||
          a.episodes.some((e) => e.videoUrl.startsWith("idb://")),
      );
      lastRemoteSig.current = sig;
      if (hasLocalMedia) return false; // keep admin's local files; they push from here
      await idbSet(STORE_KEY, remote);
      setRawList(remote);
      return true;
    } catch (e) {
      // Same public fallback used by initial load: a broken Worker/API must not
      // make one browser look at a private IndexedDB catalog.
      if (id !== NOSTR_CLOUD_ID) {
        try {
          const remote = await withTimeout(fetchCatalog(NOSTR_CLOUD_ID), 20000);
          const sig = sigOf(remote);
          cloudIdRef.current = NOSTR_CLOUD_ID;
          setCloudIdState(NOSTR_CLOUD_ID);
          setCatalogId(NOSTR_CLOUD_ID);
          lastRemoteSig.current = sig;
          setLastSyncAt(Date.now());
          setRemoteMissing(false);
          await idbSet(STORE_KEY, remote);
          setRawList(remote);
          return true;
        } catch {
          /* keep current local view if every shared source is unavailable */
        }
      }
      if (e instanceof NoCatalogError) setRemoteMissing(true);
      return false;
    }
  }, []);

  // Live updates: every phone re-checks the shared catalog every 20s and when the tab
  // comes back to the foreground, so admin changes show up without a manual reload.
  useEffect(() => {
    const tick = () => {
      if (document.visibilityState === "visible") void refreshNow();
    };
    const iv = window.setInterval(tick, REFRESH_MS);
    document.addEventListener("visibilitychange", tick);
    window.addEventListener("focus", tick);
    window.addEventListener("online", tick);
    return () => {
      window.clearInterval(iv);
      document.removeEventListener("visibilitychange", tick);
      window.removeEventListener("focus", tick);
      window.removeEventListener("online", tick);
    };
  }, [refreshNow]);

  const fixLocalVideos = useCallback(
    async (onProgress?: (done: number, total: number) => void) => {
      const res = await uploadLocalVideos(rawRef.current, onProgress);
      if (res.fixed > 0) {
        shouldPush.current = true;
        setRawList(res.list);
      }
      return { fixed: res.fixed, failed: res.failed, lastError: res.lastError };
    },
    [],
  );

  const allGenres = useMemo(() => {
    const set = new Set<string>();
    viewList.forEach((a) => a.genres.forEach((g) => set.add(g)));
    return Array.from(set).sort();
  }, [viewList]);

  const value = useMemo(
    () => ({
      animeList: viewList,
      rawAnimeList: rawList,
      loading,
      saveError,
      cloudId,
      syncState,
      localOnly,
      getById,
      addAnime,
      updateAnime,
      deleteAnime,
      importAnime,
      allGenres,
      resetToSeed,
      clearAll,
      enableCloud,
      connectCloud,
      disconnectCloud,
      syncNow,
      lastSyncAt,
      remoteMissing,
      refreshNow,
      fixLocalVideos,
    }),
    [
      viewList,
      rawList,
      loading,
      saveError,
      cloudId,
      syncState,
      localOnly,
      getById,
      addAnime,
      updateAnime,
      deleteAnime,
      importAnime,
      allGenres,
      resetToSeed,
      clearAll,
      enableCloud,
      connectCloud,
      disconnectCloud,
      syncNow,
      lastSyncAt,
      remoteMissing,
      refreshNow,
      fixLocalVideos,
    ],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAnimeStore() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useAnimeStore must be used within AnimeProvider");
  return ctx;
}

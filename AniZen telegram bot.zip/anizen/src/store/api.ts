import type { Anime } from "../types";
import { API_URL } from "../config";

const API_ID_KEY = "aniverse:api-url";
const TOKEN_KEY = "aniverse:api-token";

/** URL priority: ?api= link param > website env/config > saved value in this browser. */
export function getApiUrl(): string {
  try {
    const params = new URLSearchParams(window.location.search);
    const q = params.get("api");
    if (q && /^https?:\/\/.+/.test(q)) {
      const clean = q.replace(/\/$/, "");
      localStorage.setItem(API_ID_KEY, clean);
      return clean;
    }
    const cfg = (API_URL || localStorage.getItem(API_ID_KEY) || "").trim().replace(/\/$/, "");
    return cfg;
  } catch {
    return (API_URL || "").replace(/\/$/, "");
  }
}

export function setApiUrl(url: string) {
  try {
    if (url) localStorage.setItem(API_ID_KEY, url);
    else localStorage.removeItem(API_ID_KEY);
  } catch {
    /* ignore */
  }
}

export function usesApi(): boolean {
  return !!getApiUrl();
}

export function getToken(): string {
  try {
    return localStorage.getItem(TOKEN_KEY) || "";
  } catch {
    return "";
  }
}

export function setToken(t: string) {
  try {
    if (t) localStorage.setItem(TOKEN_KEY, t);
    else localStorage.removeItem(TOKEN_KEY);
  } catch {
    /* ignore */
  }
}

export function hasToken(): boolean {
  return !!getToken();
}

async function req(path: string, init: RequestInit = {}, ms = 20000): Promise<Response> {
  const base = getApiUrl();
  if (!base) throw new Error("Backend URL set nahi hai.");
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  const headers = new Headers(init.headers || {});
  const token = getToken();
  if (token) headers.set("Authorization", `Bearer ${token}`);
  if (init.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  try {
    return await fetch(`${base}${path}`, { ...init, headers, signal: ctrl.signal });
  } finally {
    clearTimeout(t);
  }
}

function toErr(res: Response, fallback: string): Error {
  return new Error(`${fallback} (HTTP ${res.status})`);
}

async function readError(res: Response, fallback: string): Promise<Error> {
  try {
    const j = await res.json();
    if (j && typeof j.error === "string") return new Error(j.error);
  } catch {
    /* ignore */
  }
  return toErr(res, fallback);
}

/* ------------------------------ Health & auth ------------------------------ */

export async function health(): Promise<boolean> {
  try {
    const res = await req("/api/health", {}, 8000);
    return res.ok;
  } catch {
    return false;
  }
}

export async function login(password: string): Promise<void> {
  const res = await req("/api/auth/login", {
    method: "POST",
    body: JSON.stringify({ password }),
  });
  if (!res.ok) throw await readError(res, "Login fail");
  const j = (await res.json()) as { token?: string };
  if (!j.token) throw new Error("Token nahi mila");
  setToken(j.token);
}

export function logout() {
  setToken("");
}

export async function verifyToken(): Promise<boolean> {
  if (!hasToken()) return false;
  try {
    const res = await req("/api/auth/me");
    if (res.ok) return true;
    if (res.status === 401) setToken("");
    return false;
  } catch {
    return false;
  }
}

/* ------------------------------ Catalog ------------------------------ */

export async function apiListAnime(): Promise<Anime[]> {
  const res = await req("/api/catalog");
  if (!res.ok) throw await readError(res, "Catalog load fail");
  const j = (await res.json()) as { anime?: Anime[] } | Anime[];
  const list = Array.isArray(j) ? j : j.anime;
  if (!Array.isArray(list)) throw new Error("Bad catalog");
  return list;
}

export async function apiSaveAnime(anime: Anime): Promise<Anime> {
  const res = await req(`/api/anime/${encodeURIComponent(anime.id)}`, {
    method: "PUT",
    body: JSON.stringify(anime),
  });
  if (!res.ok) throw await readError(res, "Save fail");
  return (await res.json()) as Anime;
}

export async function apiCreateAnime(anime: Anime): Promise<Anime> {
  const res = await req("/api/anime", { method: "POST", body: JSON.stringify(anime) });
  if (!res.ok) throw await readError(res, "Create fail");
  return (await res.json()) as Anime;
}

export async function apiDeleteAnime(id: string): Promise<void> {
  const res = await req(`/api/anime/${encodeURIComponent(id)}`, { method: "DELETE" });
  if (!res.ok) throw await readError(res, "Delete fail");
}

export async function apiReplaceAll(list: Anime[]): Promise<void> {
  const res = await req("/api/catalog", {
    method: "PUT",
    body: JSON.stringify({ anime: list }),
  });
  if (!res.ok) throw await readError(res, "Bulk save fail");
}

import type { Anime } from "../types";
import { SHARED_CATALOG_ID, WORKER_URL } from "../config";
import { isKvdbId, kvdbLoad, kvdbSave } from "./kvdb";
import { apiListAnime, apiReplaceAll, usesApi } from "./api";
import { NOSTR_CLOUD_ID, nostrLoad, nostrSave } from "./nostr";

export { NOSTR_CLOUD_ID };
export const WORKER_CLOUD_ID = "cloudflare";
export const API_CLOUD_ID = "api";

// Old free JSON host (kept so previously-made catalogs still load).
const BASES = [
  "https://jsonblob.com/api/jsonBlob",
  "https://api.jsonblob.com/api/jsonBlob",
  "https://www.jsonblob.com/api/jsonBlob",
];
// "-v2": ignores the old per-phone auto-created databases that left some phones on an empty one.
const ID_KEY = "aniverse:catalog-id-v2";
const W_KEY = "aniverse:catalog-w";
const WORKER_URL_KEY = "aniverse:worker-url";
const WORKER_KEY_KEY = "aniverse:worker-admin-key";
const CLD_KEY = "aniverse:cloudinary";

/** Turn technical errors into a clear message for the admin. */
export function explainError(e: unknown): string {
  const m = e instanceof Error ? e.message : String(e);
  if (/abort|timeout/i.test(m)) return "Server ne jawab nahi diya (timeout). Thodi der baad try karo.";
  if (/failed to fetch|networkerror|load failed|network request/i.test(m))
    return "Server tak request nahi pahunchi. Internet check karo, ya ye browser/preview us service ko block kar raha hai.";
  return m;
}

async function request(url: string, init: RequestInit = {}, ms = 15000): Promise<Response> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    return await fetch(url, { ...init, signal: ctrl.signal });
  } finally {
    clearTimeout(t);
  }
}

async function tryBases<T>(fn: (base: string) => Promise<T>): Promise<T> {
  let last: unknown = new Error("Koi server available nahi");
  for (const b of BASES) {
    try {
      return await fn(b);
    } catch (e) {
      last = e;
    }
  }
  throw last;
}

/* ---------- Cloudflare Worker (advanced / permanent option) ---------- */

export interface WorkerCfg {
  url: string;
  key: string;
}

/**
 * Worker URL priority: hard-coded config > ?w= in shared link > saved in this browser.
 * (?w= is read-only for visitors — the admin key is never shared.)
 */
export function getWorkerCfg(): WorkerCfg | null {
  try {
    const params = new URLSearchParams(window.location.search);
    const wParam = params.get("w");
    if (wParam && /^https:\/\/.+\/?$/.test(wParam)) {
      const clean = wParam.replace(/\/$/, "");
      localStorage.setItem(WORKER_URL_KEY, clean);
      return { url: clean, key: localStorage.getItem(WORKER_KEY_KEY) || "" };
    }
    const url = (WORKER_URL || localStorage.getItem(WORKER_URL_KEY) || "").trim().replace(/\/$/, "");
    if (!url) return null;
    return { url, key: localStorage.getItem(WORKER_KEY_KEY) || "" };
  } catch {
    return WORKER_URL ? { url: WORKER_URL.replace(/\/$/, ""), key: "" } : null;
  }
}

export function setWorkerCfg(url: string, key: string) {
  try {
    if (url) localStorage.setItem(WORKER_URL_KEY, url);
    else localStorage.removeItem(WORKER_URL_KEY);
    if (key) localStorage.setItem(WORKER_KEY_KEY, key);
    else localStorage.removeItem(WORKER_KEY_KEY);
  } catch {
    /* ignore */
  }
}

export function usesWorker(): boolean {
  return !!getWorkerCfg()?.url;
}

function parseCatalog(json: unknown): Anime[] {
  const j = json as { anime?: unknown } | unknown[];
  const list = Array.isArray(j) ? j : j.anime;
  if (!Array.isArray(list)) throw new Error("Catalog file sahi format me nahi hai");
  return list as Anime[];
}

async function workerGet(): Promise<Anime[]> {
  const w = getWorkerCfg();
  if (!w) throw new Error("Worker set nahi hai");
  let res: Response;
  try {
    res = await request(`${w.url}/catalog`, { headers: { Accept: "application/json" }, cache: "no-store" });
  } catch (e) {
    throw new Error(explainError(e));
  }
  if (!res.ok) throw new Error(`Catalog load nahi hua (HTTP ${res.status})`);
  return parseCatalog(await res.json());
}

async function workerPut(list: Anime[]): Promise<void> {
  const w = getWorkerCfg();
  if (!w) throw new Error("Worker set nahi hai");
  if (!w.key) throw new Error("Admin Key missing hai — Admin Panel me Worker URL + Admin Key save karo.");
  let res: Response;
  try {
    res = await request(
      `${w.url}/catalog`,
      {
        method: "PUT",
        headers: { "Content-Type": "application/json", Accept: "application/json", "X-Admin-Key": w.key },
        body: JSON.stringify({ version: 1, anime: list }),
      },
      60000,
    );
  } catch (e) {
    throw new Error(explainError(e));
  }
  if (res.status === 401) {
    const j = await res.json().catch(() => ({}));
    throw new Error((j as { error?: string }).error || "Admin Key galat hai.");
  }
  if (!res.ok) {
    const j = await res.json().catch(() => ({}));
    throw new Error((j as { error?: string }).error || `Save nahi hua (HTTP ${res.status})`);
  }
}

/* ---------- Catalog ID ---------- */

/**
 * Priority: ?w= Worker link > ?c=ID in link > hard-coded config ID > saved in this browser.
 * (Worker links ignore ?c= because the Worker IS the database.)
 */
export function getCatalogId(): string {
  try {
    if (usesApi()) return API_CLOUD_ID;
    const params = new URLSearchParams(window.location.search);
    const wParam = params.get("w");
    if (wParam && /^https:\/\/.+\/?$/.test(wParam)) return WORKER_CLOUD_ID;
    const p = params.get("c");
    if (p && /^[\w:-]{8,80}$/.test(p)) {
      localStorage.setItem(ID_KEY, p);
      try {
        localStorage.removeItem(W_KEY);
      } catch {
        /* ignore */
      }
      return p;
    }
    if (usesWorker()) return WORKER_CLOUD_ID;
    // Default for everyone: the shared Nostr catalog.
    return SHARED_CATALOG_ID || localStorage.getItem(ID_KEY) || NOSTR_CLOUD_ID;
  } catch {
    return SHARED_CATALOG_ID || NOSTR_CLOUD_ID;
  }
}

export function setCatalogId(id: string) {
  try {
    if (id) localStorage.setItem(ID_KEY, id);
    else localStorage.removeItem(ID_KEY);
  } catch {
    /* ignore */
  }
}

export async function fetchCatalog(id: string): Promise<Anime[]> {
  if (usesApi() || id === API_CLOUD_ID) return apiListAnime();
  if (usesWorker() || id === WORKER_CLOUD_ID) return workerGet();
  if (id === NOSTR_CLOUD_ID) return nostrLoad();
  if (isKvdbId(id)) return kvdbLoad(id);
  return tryBases(async (base) => {
    const res = await request(`${base}/${id}`, { headers: { Accept: "application/json" }, cache: "no-store" });
    if (!res.ok) throw new Error(`Catalog load nahi hua (HTTP ${res.status})`);
    return parseCatalog(await res.json());
  });
}

/** Default = real backend if configured, else free KVDB, else Worker. */
export async function createCatalog(list: Anime[]): Promise<string> {
  if (usesApi()) {
    await apiReplaceAll(list);
    return API_CLOUD_ID;
  }
  if (usesWorker()) {
    await workerPut(list);
    return WORKER_CLOUD_ID;
  }
  await nostrSave(list);
  return NOSTR_CLOUD_ID;
}

export async function saveCatalog(id: string, list: Anime[]): Promise<void> {
  if (usesApi() || id === API_CLOUD_ID) return apiReplaceAll(list);
  if (usesWorker() || id === WORKER_CLOUD_ID) return workerPut(list);
  if (id === NOSTR_CLOUD_ID) {
    await nostrSave(list);
    return;
  }
  if (isKvdbId(id)) return kvdbSave(id, list);
  const body = { version: 1, anime: list };
  await tryBases(async (base) => {
    const res = await request(
      `${base}/${id}`,
      {
        method: "PUT",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify(body),
      },
      60000,
    );
    if (!res.ok) throw new Error(`Save nahi hua (HTTP ${res.status})`);
  });
}

/* ---------- Cloudinary (optional, for videos/images visible to everyone) ---------- */

export interface CloudinaryCfg {
  cloudName: string;
  preset: string;
}

export function getCloudinary(): CloudinaryCfg | null {
  try {
    const raw = localStorage.getItem(CLD_KEY);
    if (!raw) return null;
    const cfg = JSON.parse(raw) as CloudinaryCfg;
    return cfg.cloudName && cfg.preset ? cfg : null;
  } catch {
    return null;
  }
}

export function setCloudinary(cfg: CloudinaryCfg | null) {
  try {
    if (cfg) localStorage.setItem(CLD_KEY, JSON.stringify(cfg));
    else localStorage.removeItem(CLD_KEY);
  } catch {
    /* ignore */
  }
}

export type UploadProgress = (pct: number) => void;

/** Turn Cloudinary's English errors into something the admin can act on. */
function cloudinaryMessage(raw: string | undefined, status: number): string {
  const m = raw || "";
  if (/preset/i.test(m)) return `Upload preset galat hai ya "Unsigned" nahi hai (${m})`;
  if (/cloud.?name|invalid.*account|unknown api key/i.test(m)) return `Cloud name galat hai (${m})`;
  if (/size|too large|maximum/i.test(m))
    return `Video bahut badi hai — free Cloudinary me max 100MB ki file chalti hai. (${m})`;
  if (/format|not supported|invalid image|invalid video/i.test(m))
    return `Ye file format Cloudinary ko samajh nahi aaya — MP4 (H.264) me convert karke try karo. (${m})`;
  return m || `Cloudinary error (HTTP ${status})`;
}

/** XHR (not fetch) because only XHR gives real upload progress. */
function xhrPost(
  url: string,
  form: FormData,
  headers: Record<string, string>,
  onBytes?: (loaded: number) => void,
  timeoutMs = 300000,
): Promise<{ status: number; json: Record<string, unknown> }> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", url);
    Object.entries(headers).forEach(([k, v]) => xhr.setRequestHeader(k, v));
    xhr.timeout = timeoutMs;
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) onBytes?.(e.loaded);
    };
    xhr.onload = () => {
      let json: Record<string, unknown> = {};
      try {
        json = JSON.parse(xhr.responseText || "{}");
      } catch {
        /* non-JSON reply */
      }
      resolve({ status: xhr.status, json });
    };
    xhr.onerror = () => reject(new Error("Network error — internet check karo aur dobara try karo."));
    xhr.ontimeout = () => reject(new Error("Upload timeout — internet slow hai, dobara try karo."));
    xhr.onabort = () => reject(new Error("Upload cancel ho gaya."));
    xhr.send(form);
  });
}

const CHUNK_SIZE = 8 * 1024 * 1024; // Cloudinary needs >= 5MB per chunk (except the last)

async function cloudinaryUpload(
  cfg: CloudinaryCfg,
  file: Blob,
  type: "image" | "video",
  onProgress?: UploadProgress,
): Promise<string> {
  const url = `https://api.cloudinary.com/v1_1/${cfg.cloudName}/${type}/upload`;
  const total = file.size;
  const name = (file as File).name || (type === "video" ? "upload.mp4" : "upload.jpg");
  const form = (blob: Blob) => {
    const f = new FormData();
    f.append("file", blob, name);
    f.append("upload_preset", cfg.preset);
    return f;
  };
  const pick = (r: { status: number; json: Record<string, unknown> }): string => {
    const url2 = r.json.secure_url;
    if (r.status >= 200 && r.status < 300 && typeof url2 === "string") return url2;
    const err = (r.json.error as { message?: string } | undefined)?.message;
    throw new Error(cloudinaryMessage(err, r.status));
  };

  // Small file: one request, with progress
  if (total <= CHUNK_SIZE) {
    const r = await xhrPost(url, form(file), {}, (loaded) => onProgress?.(Math.min(99, (loaded / total) * 100)));
    const out = pick(r);
    onProgress?.(100);
    return out;
  }

  // Big file (phone gallery videos): split into chunks so a bad connection can retry
  // one piece instead of failing the whole upload.
  const uploadId = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 10)}`;
  let sent = 0;
  let lastResult: { status: number; json: Record<string, unknown> } | null = null;

  for (let start = 0; start < total; start += CHUNK_SIZE) {
    const end = Math.min(start + CHUNK_SIZE, total);
    const piece = file.slice(start, end);
    let attempt = 0;
    for (;;) {
      try {
        const r = await xhrPost(
          url,
          form(piece),
          {
            "X-Unique-Upload-Id": uploadId,
            "Content-Range": `bytes ${start}-${end - 1}/${total}`,
          },
          (loaded) => onProgress?.(Math.min(99, ((sent + loaded) / total) * 100)),
        );
        if (r.status >= 200 && r.status < 300) {
          lastResult = r;
          break;
        }
        // Real API error (bad preset, file too big...) — retrying will not help
        const err = (r.json.error as { message?: string } | undefined)?.message;
        throw Object.assign(new Error(cloudinaryMessage(err, r.status)), { fatal: true });
      } catch (e) {
        attempt++;
        const fatal = (e as { fatal?: boolean }).fatal;
        if (fatal || attempt >= 3) throw e;
        await new Promise((res) => setTimeout(res, 1200 * attempt));
      }
    }
    sent = end;
  }

  if (!lastResult) throw new Error("Upload poora nahi hua.");
  const out = pick(lastResult);
  onProgress?.(100);
  return out;
}

export async function uploadToCloudinary(file: File, onProgress?: UploadProgress): Promise<string> {
  const cfg = getCloudinary();
  if (!cfg) throw new Error("Cloudinary set nahi hai");
  return cloudinaryUpload(cfg, file, file.type.startsWith("video") ? "video" : "image", onProgress);
}

/** Uploads a tiny test image so the admin knows if the details are correct. */
export async function testCloudinary(cfg: CloudinaryCfg): Promise<void> {
  const png =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==";
  const blob = await (await fetch(png)).blob();
  await cloudinaryUpload(cfg, blob, "image");
}

import type { Anime } from "../types";

/**
 * Free online database (KVdb.io) — no account needed.
 * Catalog JSON is split into small chunks (KVdb allows max 16KB per value)
 * and every save refreshes a 1-year expiry.
 */

const API = "https://kvdb.io";
const CHUNK = 12000; // chars, safely under the 16KB value limit
const TTL = 31536000; // 1 year in seconds, refreshed on every save
export const KVDB_PREFIX = "kvdb:";

export function isKvdbId(id: string): boolean {
  return !!id && id.startsWith(KVDB_PREFIX);
}

export function bucketOf(id: string): string {
  return id.slice(KVDB_PREFIX.length);
}

async function req(url: string, init: RequestInit = {}, ms = 20000): Promise<Response> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    return await fetch(url, { ...init, signal: ctrl.signal });
  } finally {
    clearTimeout(t);
  }
}

/** Create a new empty database. Returns id like "kvdb:XyZ123...". */
export async function kvdbCreate(): Promise<string> {
  const rand = Math.random().toString(36).slice(2, 10);
  let res: Response;
  try {
    res = await req(
      `${API}/`,
      {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `email=${encodeURIComponent(`aniverse.${rand}@gmail.com`)}`,
      },
      25000,
    );
  } catch {
    throw new Error("Database server tak request nahi pahunchi. Internet check karke dobara try karo.");
  }
  if (!res.ok) throw new Error(`Database banane me error (HTTP ${res.status}). Thodi der baad try karo.`);
  const bucket = (await res.text()).trim();
  if (!bucket || bucket.length < 4 || /\s/.test(bucket)) {
    throw new Error("Database ID nahi mili. Dobara try karo.");
  }
  return KVDB_PREFIX + bucket;
}

async function put(bucket: string, key: string, value: string): Promise<void> {
  const res = await req(`${API}/${bucket}/${key}?ttl=${TTL}`, {
    method: "POST",
    headers: { "Content-Type": "text/plain" },
    body: value,
  });
  if (!res.ok) throw new Error(`Save fail (HTTP ${res.status})`);
}

async function get(bucket: string, key: string): Promise<string | null> {
  const res = await req(`${API}/${bucket}/${key}`, { headers: { Accept: "text/plain" } });
  if (res.status === 404 || res.status === 410) return null;
  if (!res.ok) throw new Error(`Load fail (HTTP ${res.status})`);
  return await res.text();
}

/** Save full catalog to the database (chunked). */
export async function kvdbSave(id: string, list: Anime[]): Promise<void> {
  const bucket = bucketOf(id);
  if (!bucket) throw new Error("Database ID galat hai.");
  const text = JSON.stringify({ version: 1, anime: list });
  const chunks: string[] = [];
  for (let i = 0; i < text.length; i += CHUNK) chunks.push(text.slice(i, i + CHUNK));

  let res: Response;
  try {
    // How many chunks existed before? (to delete leftovers when shrinking)
    let oldChunks = 0;
    try {
      const m = await get(bucket, "meta");
      if (m) oldChunks = JSON.parse(m).chunks || 0;
    } catch {
      /* fresh database */
    }

    // Upload chunks in parallel batches
    const BATCH = 6;
    for (let i = 0; i < chunks.length; i += BATCH) {
      await Promise.all(chunks.slice(i, i + BATCH).map((c, k) => put(bucket, `c${i + k}`, c)));
    }
    await put(bucket, "meta", JSON.stringify({ version: 1, chunks: chunks.length, updatedAt: Date.now() }));

    // Delete stale extra chunks (best effort)
    for (let i = chunks.length; i < oldChunks; i++) {
      try {
        res = await req(`${API}/${bucket}/c${i}`, { method: "DELETE" }, 8000);
        void res;
      } catch {
        /* ignore */
      }
    }
  } catch (e) {
    if (e instanceof Error && /abort/i.test(e.message)) {
      throw new Error("Server ne jawab nahi diya (timeout). 'Sync now' se dobara try karo.");
    }
    if (e instanceof TypeError) {
      throw new Error("Database server tak request nahi pahunchi. Internet check karo.");
    }
    throw e instanceof Error ? e : new Error("Save nahi hua. Dobara try karo.");
  }
}

/** Load full catalog from the database. */
export async function kvdbLoad(id: string): Promise<Anime[]> {
  const bucket = bucketOf(id);
  if (!bucket) throw new Error("Database ID galat hai.");
  try {
    const m = await get(bucket, "meta");
    if (!m) throw new Error("Is ID par koi catalog nahi mila. ID check karo.");
    const meta = JSON.parse(m) as { chunks?: number };
    const n = meta.chunks || 0;
    if (!n) return [];
    const parts: string[] = new Array(n);
    const BATCH = 8;
    for (let i = 0; i < n; i += BATCH) {
      const idxs = Array.from({ length: Math.min(BATCH, n - i) }, (_, k) => i + k);
      const vals = await Promise.all(idxs.map((k) => get(bucket, `c${k}`)));
      idxs.forEach((k, j) => {
        if (vals[j] == null) throw new Error("Catalog adhura mila. Admin se dobara Sync karwao.");
        parts[k] = vals[j] as string;
      });
    }
    const json = JSON.parse(parts.join("")) as { anime?: unknown } | unknown[];
    const list = Array.isArray(json) ? json : (json as { anime?: unknown }).anime;
    if (!Array.isArray(list)) throw new Error("Catalog sahi format me nahi hai.");
    return list as Anime[];
  } catch (e) {
    if (e instanceof Error && /abort/i.test(e.message)) {
      throw new Error("Server ne jawab nahi diya (timeout). Dobara try karo.");
    }
    if (e instanceof TypeError) {
      throw new Error("Database server tak request nahi pahunchi. Internet check karo.");
    }
    throw e instanceof Error ? e : new Error("Catalog load nahi hua.");
  }
}

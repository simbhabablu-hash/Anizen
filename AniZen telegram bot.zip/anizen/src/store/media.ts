import type { Anime } from "../types";
import { idbGet, idbSet } from "./db";
import { getCloudinary, uploadToCloudinary } from "./cloud";

// Unique id generator
export function uid(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

const REF_PREFIX = "idb://";
const MEDIA_PREFIX = "media:";

const urlCache = new Map<string, string>();

export function isRef(v: string | undefined | null): boolean {
  return !!v && v.startsWith(REF_PREFIX);
}

/** Store a file as a Blob in this device's IndexedDB (local-only). */
export async function storeMediaFile(file: File): Promise<string> {
  const id = uid();
  await idbSet(MEDIA_PREFIX + id, file);
  return REF_PREFIX + id;
}

/** Shrink an image into a small JPEG data URL so it can be shared inside the catalog. */
export function compressImage(file: Blob, maxW = 720, quality = 0.72): Promise<string> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, maxW / img.width);
      const c = document.createElement("canvas");
      c.width = Math.max(1, Math.round(img.width * scale));
      c.height = Math.max(1, Math.round(img.height * scale));
      c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL("image/jpeg", quality));
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Invalid image"));
    };
    img.src = url;
  });
}

/**
 * Upload from gallery.
 *  - Cloudinary configured -> real public URL (images AND videos visible to everyone)
 *  - Image, no Cloudinary   -> compressed, embedded in catalog (visible to everyone)
 *  - Video, no Cloudinary   -> stays on this device only
 */
export async function uploadMedia(
  file: File,
  onProgress?: (pct: number) => void,
): Promise<{ value: string; shared: boolean; note?: string }> {
  let note: string | undefined;
  if (getCloudinary()) {
    try {
      return { value: await uploadToCloudinary(file, onProgress), shared: true };
    } catch (e) {
      // Never block saving: fall back to local handling and tell the admin why.
      note = `Online upload fail hua: ${e instanceof Error ? e.message : "unknown"} — file sirf is phone me save hui.`;
    }
  }
  if (file.type.startsWith("image/")) {
    return { value: await compressImage(file), shared: true, note };
  }
  onProgress?.(100);
  return { value: await storeMediaFile(file), shared: false, note };
}

export interface VideoCheck {
  ok: boolean;
  /** Human readable warnings (Hinglish) for the admin */
  warnings: string[];
  duration?: number;
}

/** Search a slice of the file for an ASCII marker (cheap way to spot the codec inside MP4/MOV). */
async function sliceHas(file: Blob, from: number, to: number, markers: string[]): Promise<boolean> {
  const buf = new Uint8Array(await file.slice(from, to).arrayBuffer());
  for (const m of markers) {
    const b = [...m].map((c) => c.charCodeAt(0));
    outer: for (let i = 0; i <= buf.length - b.length; i++) {
      for (let j = 0; j < b.length; j++) if (buf[i + j] !== b[j]) continue outer;
      return true;
    }
  }
  return false;
}

/** HEVC / H.265 videos (common from new phone cameras) play on few browsers/devices. */
export async function looksLikeHevc(file: Blob): Promise<boolean> {
  try {
    const MB = 1024 * 1024;
    const head = await sliceHas(file, 0, Math.min(file.size, 2 * MB), ["hvc1", "hev1"]);
    if (head) return true;
    if (file.size > 2 * MB) return await sliceHas(file, Math.max(0, file.size - 4 * MB), file.size, ["hvc1", "hev1"]);
  } catch {
    /* ignore */
  }
  return false;
}

/**
 * Open the chosen video in a hidden <video> and make sure this browser can actually
 * decode it, so a broken file is caught BEFORE the admin waits for the upload.
 */
export async function checkVideoFile(file: File): Promise<VideoCheck> {
  const warnings: string[] = [];
  if (file.size > 100 * 1024 * 1024) {
    warnings.push(
      `Ye file ${(file.size / 1048576).toFixed(0)}MB ki hai. Free Cloudinary me 100MB se badi video upload nahi hoti — pehle compress karo.`,
    );
  }
  if (await looksLikeHevc(file)) {
    warnings.push(
      "Ye video H.265 (HEVC) lag rahi hai. Kai phones/browsers me ye atak jaati hai ya sirf awaaz aati hai. H.264 MP4 me convert karke upload karna best hai.",
    );
  }

  const probe = await new Promise<{ ok: boolean; duration?: number; w?: number }>((resolve) => {
    const url = URL.createObjectURL(file);
    const v = document.createElement("video");
    v.preload = "metadata";
    v.muted = true;
    let done = false;
    const finish = (r: { ok: boolean; duration?: number; w?: number }) => {
      if (done) return;
      done = true;
      URL.revokeObjectURL(url);
      resolve(r);
    };
    v.onloadedmetadata = () => finish({ ok: true, duration: v.duration, w: v.videoWidth });
    v.onerror = () => finish({ ok: false });
    window.setTimeout(() => finish({ ok: false }), 10000);
    v.src = url;
  });

  if (!probe.ok) {
    warnings.push("Is browser me ye video khul hi nahi rahi — format (codec) support nahi hai. MP4 (H.264) me convert karo.");
  } else if (probe.w === 0) {
    warnings.push("Is video me picture decode nahi ho rahi (sirf awaaz). Codec (HEVC/H.265) support nahi hai — H.264 MP4 me convert karo.");
  } else if (probe.duration !== undefined && !isFinite(probe.duration)) {
    warnings.push("Video ki length pata nahi chal rahi — seek/aage badhna theek se kaam nahi karega. Normal MP4 me export karo.");
  }

  return { ok: warnings.length === 0, warnings, duration: probe.duration };
}

export async function resolveRef(ref: string | undefined | null): Promise<string> {
  if (!ref) return "";
  if (!ref.startsWith(REF_PREFIX)) return ref;
  if (urlCache.has(ref)) return urlCache.get(ref)!;
  const id = ref.slice(REF_PREFIX.length);
  const blob = await idbGet<Blob>(MEDIA_PREFIX + id);
  if (!blob) return "";
  const url = URL.createObjectURL(blob);
  urlCache.set(ref, url);
  return url;
}

export async function resolveAnime(a: Anime): Promise<Anime> {
  const copy: Anime = { ...a };
  copy.poster = await resolveRef(a.poster);
  copy.banner = await resolveRef(a.banner);
  copy.thumbnail = a.thumbnail ? await resolveRef(a.thumbnail) : a.thumbnail;
  copy.trailerUrl = a.trailerUrl ? await resolveRef(a.trailerUrl) : a.trailerUrl;
  copy.episodes = await Promise.all(
    (a.episodes || []).map(async (ep) => ({
      ...ep,
      videoUrl: await resolveRef(ep.videoUrl),
      thumbnail: ep.thumbnail ? await resolveRef(ep.thumbnail) : ep.thumbnail,
    })),
  );
  return copy;
}

export interface LocalVideoItem {
  animeId: string;
  animeTitle: string;
  episodeId: string;
  episodeNumber: number;
  /** "local" = file lives only in this browser (fixable), "missing" = no video at all */
  kind: "local" | "missing";
}

/** Find every episode whose video other phones cannot play. */
export function findUnsharedVideos(list: Anime[]): LocalVideoItem[] {
  const out: LocalVideoItem[] = [];
  for (const a of list) {
    for (const e of a.episodes || []) {
      if (!e.videoUrl) {
        out.push({ animeId: a.id, animeTitle: a.titleEnglish || a.title, episodeId: e.id, episodeNumber: e.number, kind: "missing" });
      } else if (isRef(e.videoUrl) || e.videoUrl.startsWith("blob:")) {
        out.push({ animeId: a.id, animeTitle: a.titleEnglish || a.title, episodeId: e.id, episodeNumber: e.number, kind: "local" });
      }
    }
  }
  return out;
}

/**
 * Upload every device-only episode video to Cloudinary and swap the idb:// reference
 * for the public URL. Returns the new list plus counts.
 */
export async function uploadLocalVideos(
  list: Anime[],
  onProgress?: (done: number, total: number) => void,
): Promise<{ list: Anime[]; fixed: number; failed: number; lastError?: string }> {
  const targets = findUnsharedVideos(list).filter((t) => t.kind === "local");
  let fixed = 0;
  let failed = 0;
  let lastError: string | undefined;
  const byEp = new Map<string, string>();

  let done = 0;
  for (const t of targets) {
    const anime = list.find((a) => a.id === t.animeId);
    const ep = anime?.episodes.find((e) => e.id === t.episodeId);
    onProgress?.(done, targets.length);
    try {
      if (!ep || !isRef(ep.videoUrl)) throw new Error("File is browser me nahi mili");
      const blob = await idbGet<Blob>(MEDIA_PREFIX + ep.videoUrl.slice(REF_PREFIX.length));
      if (!blob) throw new Error("Video file is device par nahi mili (shayad browser data clear hua)");
      const file = blob instanceof File ? blob : new File([blob], `${ep.id}.mp4`, { type: blob.type || "video/mp4" });
      const url = await uploadToCloudinary(file);
      byEp.set(ep.id, url);
      fixed++;
    } catch (e) {
      failed++;
      lastError = e instanceof Error ? e.message : "Upload fail";
    }
    done++;
    onProgress?.(done, targets.length);
  }

  const next = list.map((a) => ({
    ...a,
    episodes: a.episodes.map((e) => (byEp.has(e.id) ? { ...e, videoUrl: byEp.get(e.id)!, videoType: "mp4" as const } : e)),
  }));
  return { list: next, fixed, failed, lastError };
}

/** Re-compress an already-embedded data-URL image down to a much smaller size. */
export function shrinkDataUrl(dataUrl: string, maxW = 380, quality = 0.55): Promise<string> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      try {
        const scale = Math.min(1, maxW / img.width);
        const c = document.createElement("canvas");
        c.width = Math.max(1, Math.round(img.width * scale));
        c.height = Math.max(1, Math.round(img.height * scale));
        c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height);
        resolve(c.toDataURL("image/jpeg", quality));
      } catch {
        resolve(dataUrl);
      }
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}

export interface ShareableOpts {
  /** Strip embedded gallery images entirely — smallest file, safe for chat paste. */
  compact?: boolean;
  /** Embedded images bigger than this (chars) are shrunk down. */
  maxDataUrl?: number;
}

/**
 * Convert the catalog into a version that is safe to publish online:
 * local images become small embedded images, local-only videos are dropped (and counted).
 */
export async function toShareable(
  list: Anime[],
  opts: ShareableOpts = {},
): Promise<{ list: Anime[]; skipped: number; stripped: number }> {
  const { compact = false, maxDataUrl = 25000 } = opts;
  let skipped = 0;
  let stripped = 0;

  const img = async (v?: string): Promise<string> => {
    if (!v) return "";
    if (!isRef(v)) {
      if (!v.startsWith("data:image")) return v;
      if (compact) {
        stripped++;
        return "";
      }
      if (v.length > maxDataUrl) {
        const small = await shrinkDataUrl(v);
        if (small.length < v.length) return small;
      }
      return v;
    }
    const blob = await idbGet<Blob>(MEDIA_PREFIX + v.slice(REF_PREFIX.length));
    if (!blob) return "";
    if (compact) {
      stripped++;
      return "";
    }
    try {
      return await compressImage(blob, 480, 0.6);
    } catch {
      return "";
    }
  };

  const out: Anime[] = [];
  for (const a of list) {
    const episodes = [];
    for (const e of a.episodes || []) {
      let videoUrl = e.videoUrl;
      if (isRef(videoUrl)) {
        videoUrl = "";
        skipped++;
      }
      episodes.push({ ...e, videoUrl, thumbnail: await img(e.thumbnail) });
    }
    out.push({
      ...a,
      poster: await img(a.poster),
      banner: await img(a.banner),
      thumbnail: await img(a.thumbnail),
      trailerUrl: isRef(a.trailerUrl) ? "" : a.trailerUrl,
      episodes,
    });
  }
  return { list: out, skipped, stripped };
}

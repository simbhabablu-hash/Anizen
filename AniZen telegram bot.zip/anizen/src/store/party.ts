import { SimplePool, finalizeEvent, generateSecretKey, type Event, type Filter } from "nostr-tools";
import { NOSTR_RELAYS } from "../config";

/**
 * Watch Party transport.
 *
 * Messages travel as Nostr "ephemeral" events (kind 20000-29999): relays forward them live to
 * everyone subscribed to the room tag and do NOT store them. Each person signs with a throw-away
 * key, so there is nothing to sign up for and no server of our own.
 */

const KIND = 24242;
// No O/0/I/1/L so a code read out loud or typed on a phone is hard to get wrong
const ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
export const CODE_LEN = 6;

export function makeCode(len = CODE_LEN): string {
  const bytes = crypto.getRandomValues(new Uint8Array(len));
  return Array.from(bytes, (b) => ALPHABET[b % ALPHABET.length]).join("");
}

export function cleanCode(s: string): string {
  return s.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, CODE_LEN);
}

export function makePeerId(): string {
  const bytes = crypto.getRandomValues(new Uint8Array(6));
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

export type PartyKind = "hello" | "ping" | "leave" | "state" | "action" | "chat";

export interface PartyMsg {
  k: PartyKind;
  from: string;
  name: string;
  ts: number;
  host?: boolean;
  /** which anime / episode the room is on */
  animeId?: string;
  ep?: number;
  /** playback position (seconds) and whether it is playing */
  t?: number;
  playing?: boolean;
  /** what a person just did */
  a?: "play" | "pause" | "seek" | "episode";
  text?: string;
}

export type PartyOutgoing = Omit<PartyMsg, "from" | "ts" | "name">;

export class PartyConnection {
  readonly tag: string;
  private pool = new SimplePool();
  private sk = generateSecretKey();
  private sub: { close: (reason?: string) => void } | null = null;
  private seen = new Set<string>();
  private lastSecond = 0;

  constructor(
    readonly code: string,
    readonly peerId: string,
    private name: () => string,
    private onMsg: (m: PartyMsg) => void,
  ) {
    this.tag = `anizen-party-${code}`;
  }

  start(): void {
    const filter = {
      kinds: [KIND],
      "#t": [this.tag],
      since: Math.floor(Date.now() / 1000) - 10,
    } as Filter;
    this.sub = this.pool.subscribeMany(NOSTR_RELAYS, filter, {
      onevent: (ev: Event) => this.handle(ev),
    });
  }

  private handle(ev: Event): void {
    // the same message arrives once per relay: keep only the first
    if (this.seen.has(ev.id)) return;
    this.seen.add(ev.id);
    if (this.seen.size > 600) {
      const keep = Array.from(this.seen).slice(-300);
      this.seen = new Set(keep);
    }
    try {
      const m = JSON.parse(ev.content) as PartyMsg;
      if (!m || typeof m.k !== "string" || m.from === this.peerId) return;
      this.onMsg(m);
    } catch {
      /* not ours / malformed */
    }
  }

  /** Returns how many relays accepted the message (0 = nothing got through). */
  async send(msg: PartyOutgoing): Promise<number> {
    const full: PartyMsg = { ...msg, from: this.peerId, name: this.name(), ts: Date.now() };
    // created_at must increase so relays never treat two quick events as duplicates
    const now = Math.floor(Date.now() / 1000);
    this.lastSecond = Math.max(now, this.lastSecond);
    const ev = finalizeEvent(
      { kind: KIND, created_at: this.lastSecond, tags: [["t", this.tag]], content: JSON.stringify(full) },
      this.sk,
    );
    const results = await Promise.allSettled(this.pool.publish(NOSTR_RELAYS, ev, { maxWait: 6000 }));
    return results.filter((r) => r.status === "fulfilled").length;
  }

  stop(): void {
    try {
      this.sub?.close("left");
    } catch {
      /* ignore */
    }
    try {
      this.pool.close(NOSTR_RELAYS);
    } catch {
      /* ignore */
    }
    this.sub = null;
  }
}

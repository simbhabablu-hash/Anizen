import type { Anime } from "../types";

const V = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample";

function poster(seed: string) {
  return `https://picsum.photos/seed/${seed}/450/640`;
}
function banner(seed: string) {
  return `https://picsum.photos/seed/${seed}/1280/720`;
}

export const SEED_ANIME: Anime[] = [
  {
    id: "seed-1",
    title: "Kaze no Senshi",
    titleEnglish: "Warriors of the Wind",
    synopsis:
      "In a world torn by ancient conflict, a young swordsman discovers a hidden power that could either save his homeland or destroy it. An epic tale of courage, friendship and destiny.",
    poster: poster("kaze1"),
    banner: banner("kaze1b"),
    thumbnail: banner("kaze1t"),
    genres: ["Action", "Adventure", "Fantasy"],
    type: "TV",
    status: "Ongoing",
    year: 2025,
    rating: 8.7,
    studio: "Studio AniVerse",
    featured: true,
    trailerUrl: `${V}/BigBuckBunny.mp4`,
    createdAt: Date.now() - 1000,
    episodes: [
      { id: "s1e1", number: 1, title: "The Awakening", videoUrl: `${V}/BigBuckBunny.mp4`, videoType: "mp4", duration: "24m" },
      { id: "s1e2", number: 2, title: "First Blade", videoUrl: `${V}/ElephantsDream.mp4`, videoType: "mp4", duration: "24m" },
      { id: "s1e3", number: 3, title: "The Hidden Village", videoUrl: `${V}/ForBiggerBlazes.mp4`, videoType: "mp4", duration: "24m" },
    ],
  },
  {
    id: "seed-2",
    title: "Hoshizora no Melody",
    titleEnglish: "Melody of the Starry Sky",
    synopsis:
      "A shy high-school pianist meets a mysterious transfer student who hears music in everything. Together they chase a dream that spans across the stars.",
    poster: poster("hoshi2"),
    banner: banner("hoshi2b"),
    thumbnail: banner("hoshi2t"),
    genres: ["Romance", "Slice of Life", "Drama"],
    type: "TV",
    status: "Completed",
    year: 2024,
    rating: 8.2,
    studio: "Lumen Works",
    featured: true,
    trailerUrl: `${V}/ForBiggerEscapes.mp4`,
    createdAt: Date.now() - 2000,
    episodes: [
      { id: "s2e1", number: 1, title: "Transfer Student", videoUrl: `${V}/ForBiggerEscapes.mp4`, videoType: "mp4", duration: "23m" },
      { id: "s2e2", number: 2, title: "Duet", videoUrl: `${V}/ForBiggerFun.mp4`, videoType: "mp4", duration: "23m" },
    ],
  },
  {
    id: "seed-3",
    title: "Cyber Ronin",
    titleEnglish: "Cyber Ronin",
    synopsis:
      "In neon-drenched Neo Tokyo, a masterless samurai turned hacker fights corporate overlords to protect the last free district of the city.",
    poster: poster("cyber3"),
    banner: banner("cyber3b"),
    thumbnail: banner("cyber3t"),
    genres: ["Action", "Sci-Fi", "Thriller"],
    type: "ONA",
    status: "Ongoing",
    year: 2025,
    rating: 9.1,
    studio: "Neon Frame",
    featured: true,
    trailerUrl: `${V}/ForBiggerJoyrides.mp4`,
    createdAt: Date.now() - 3000,
    episodes: [
      { id: "s3e1", number: 1, title: "Ghost Protocol", videoUrl: `${V}/ForBiggerJoyrides.mp4`, videoType: "mp4", duration: "25m" },
      { id: "s3e2", number: 2, title: "Firewall", videoUrl: `${V}/ForBiggerMeltdowns.mp4`, videoType: "mp4", duration: "25m" },
      { id: "s3e3", number: 3, title: "Zero Day", videoUrl: `${V}/Sintel.mp4`, videoType: "mp4", duration: "25m" },
    ],
  },
  {
    id: "seed-4",
    title: "Yokai Gakuen",
    titleEnglish: "Spirit Academy",
    synopsis:
      "An ordinary girl enrolls in a school for spirits and monsters, learning that being different is the greatest strength of all.",
    poster: poster("yokai4"),
    banner: banner("yokai4b"),
    thumbnail: banner("yokai4t"),
    genres: ["Supernatural", "Comedy", "Fantasy"],
    type: "TV",
    status: "Ongoing",
    year: 2025,
    rating: 7.9,
    studio: "Studio AniVerse",
    featured: false,
    trailerUrl: `${V}/TearsOfSteel.mp4`,
    createdAt: Date.now() - 4000,
    episodes: [
      { id: "s4e1", number: 1, title: "Enrollment Day", videoUrl: `${V}/TearsOfSteel.mp4`, videoType: "mp4", duration: "22m" },
      { id: "s4e2", number: 2, title: "The Night Class", videoUrl: `${V}/BigBuckBunny.mp4`, videoType: "mp4", duration: "22m" },
    ],
  },
  {
    id: "seed-5",
    title: "Grand Line Cooks",
    titleEnglish: "Grand Line Cooks",
    synopsis:
      "A team of rival chefs sail the seas competing in legendary cooking battles where flavour is everything and pride is on the line.",
    poster: poster("cook5"),
    banner: banner("cook5b"),
    thumbnail: banner("cook5t"),
    genres: ["Comedy", "Adventure", "Slice of Life"],
    type: "TV",
    status: "Completed",
    year: 2023,
    rating: 8.0,
    studio: "Table Top Studio",
    featured: false,
    trailerUrl: `${V}/ForBiggerBlazes.mp4`,
    createdAt: Date.now() - 5000,
    episodes: [
      { id: "s5e1", number: 1, title: "Set Sail", videoUrl: `${V}/ForBiggerBlazes.mp4`, videoType: "mp4", duration: "24m" },
    ],
  },
  {
    id: "seed-6",
    title: "Ashen Crown",
    titleEnglish: "Ashen Crown",
    synopsis:
      "Two royal siblings are separated by war and must each decide what kind of ruler they will become in a kingdom built on secrets.",
    poster: poster("ashen6"),
    banner: banner("ashen6b"),
    thumbnail: banner("ashen6t"),
    genres: ["Drama", "Fantasy", "Action"],
    type: "Movie",
    status: "Completed",
    year: 2024,
    rating: 8.9,
    studio: "Crown Pictures",
    featured: false,
    trailerUrl: `${V}/ElephantsDream.mp4`,
    createdAt: Date.now() - 6000,
    episodes: [
      { id: "s6e1", number: 1, title: "Full Movie", videoUrl: `${V}/ElephantsDream.mp4`, videoType: "mp4", duration: "1h 52m" },
    ],
  },
];

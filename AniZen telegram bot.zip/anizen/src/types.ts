/** An extra copy of the same episode in a different resolution (e.g. "720p"). */
export interface QualityLink {
  label: string;
  url: string;
}

export interface Episode {
  id: string;
  number: number;
  title: string;
  videoUrl: string;
  videoType: "mp4" | "embed";
  thumbnail?: string;
  duration?: string;
  /** Optional lower/higher resolution links. videoUrl stays the main/original file. */
  qualities?: QualityLink[];
}

export interface Anime {
  id: string;
  title: string;
  titleEnglish?: string;
  synopsis: string;
  poster: string; // portrait image (card / modal)
  banner: string; // wide hero image
  thumbnail?: string; // wide card / continue watching
  genres: string[];
  type: string; // TV, Movie, OVA, ONA, Special
  status: string; // Ongoing, Completed, Upcoming
  year: number;
  rating: number; // 0 - 10
  studio?: string;
  /** Weekly airing day for the Schedule tab: "mon" | "tue" | "wed" | "thu" | "fri" | "sat" | "sun" */
  airDay?: string;
  /** Airing time shown as typed, e.g. "20:30" */
  airTime?: string;
  featured: boolean;
  trailerUrl?: string;
  episodes: Episode[];
  createdAt: number;
}

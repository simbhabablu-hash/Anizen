import type { Anime } from "../types";

const DAY = 86_400_000;

/** Show a "New EP" badge for ongoing shows and anything added in the last 2 weeks. */
export function isFresh(a: Anime): boolean {
  return a.status === "Ongoing" || (!!a.createdAt && Date.now() - a.createdAt < 14 * DAY);
}

/** "Today 14:00" style label for the New Updates list. */
export function updateLabel(ts: number): { day: string; time: string } {
  if (!ts) return { day: "—", time: "" };
  const d = new Date(ts);
  const now = new Date();
  const startOf = (x: Date) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = Math.round((startOf(now) - startOf(d)) / DAY);
  const day =
    diff <= 0 ? "Today" : diff === 1 ? "Yesterday" : d.toLocaleDateString(undefined, { day: "numeric", month: "short" });
  const time = d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false });
  return { day, time };
}

/** 754 -> "12:34", 4000 -> "1:06:40" */
export function clock(sec: number): string {
  if (!isFinite(sec) || sec < 0) return "0:00";
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  return h > 0 ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}` : `${m}:${String(s).padStart(2, "0")}`;
}

/** "5 min ago", "3 hr ago", "2 days ago" */
export function timeAgo(ts: number): string {
  const s = Math.max(0, Math.round((Date.now() - ts) / 1000));
  if (s < 60) return "just now";
  const m = Math.round(s / 60);
  if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h} hr ago`;
  const d = Math.round(h / 24);
  return `${d} day${d > 1 ? "s" : ""} ago`;
}

/** Group heading for History: Today / Yesterday / This week / Earlier */
export function dayGroup(ts: number): string {
  const startOf = (x: Date) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = Math.round((startOf(new Date()) - startOf(new Date(ts))) / DAY);
  if (diff <= 0) return "Today";
  if (diff === 1) return "Yesterday";
  if (diff < 7) return "This week";
  return "Earlier";
}

export const WEEK_DAYS = [
  { id: "mon", short: "Mon", full: "Monday" },
  { id: "tue", short: "Tue", full: "Tuesday" },
  { id: "wed", short: "Wed", full: "Wednesday" },
  { id: "thu", short: "Thu", full: "Thursday" },
  { id: "fri", short: "Fri", full: "Friday" },
  { id: "sat", short: "Sat", full: "Saturday" },
  { id: "sun", short: "Sun", full: "Sunday" },
];

/** id of today's weekday ("mon".."sun") */
export function todayDayId(): string {
  const map = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
  return map[new Date().getDay()];
}

export function statusLabel(status: string): string {
  if (status === "Ongoing") return "Now Streaming";
  if (status === "Upcoming") return "Coming Soon";
  return status || "Streaming";
}

export function lastEpisodeNumber(a: Anime): number {
  return a.episodes?.length ? a.episodes[a.episodes.length - 1].number : 1;
}

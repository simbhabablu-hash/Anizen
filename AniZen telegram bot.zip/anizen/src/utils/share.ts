import { API_CLOUD_ID, getCatalogId, getWorkerCfg, NOSTR_CLOUD_ID, WORKER_CLOUD_ID } from "../store/cloud";
import { WORKER_URL } from "../config";

/** Base site URL without query params. */
export function siteBase(): string {
  return `${window.location.origin}${window.location.pathname}`;
}

/** Extra params so the receiver loads the SAME catalog (database) as the sender. */
function catalogParams(): string {
  const w = getWorkerCfg();
  // Worker mode: other phones need the Worker URL (read-only, no key shared).
  // If it's already hard-coded in config, no param needed.
  if (w?.url && !WORKER_URL) return `w=${encodeURIComponent(w.url)}`;
  const id = getCatalogId();
  // Nostr / API / Worker need no id in the link: everyone reads the same shared catalog.
  if (id && id !== WORKER_CLOUD_ID && id !== NOSTR_CLOUD_ID && id !== API_CLOUD_ID) {
    return `c=${encodeURIComponent(id)}`;
  }
  return "";
}

/** Link that opens the site with the same shared catalog. */
export function catalogLink(): string {
  const p = catalogParams();
  return p ? `${siteBase()}?${p}` : siteBase();
}

/** Invite link for a Watch Party: opens the site with the code ready to join. */
export function partyLink(code: string): string {
  const base = catalogLink();
  return `${base}${base.includes("?") ? "&" : "?"}party=${encodeURIComponent(code)}`;
}

/** Deep link to watch a specific anime + episode (includes catalog params). */
export function watchLink(animeId: string, episode?: number, title?: string): string {
  const parts = [`watch=${encodeURIComponent(animeId)}`];
  if (episode && episode > 1) parts.push(`ep=${episode}`);
  const c = catalogParams();
  if (c) parts.push(c);
  void title;
  return `${siteBase()}?${parts.join("&")}`;
}

/** Copy text with clipboard API + fallback for older browsers / non-HTTPS. */
export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      ta.remove();
      return ok;
    } catch {
      return false;
    }
  }
}

export type ShareResult = "shared" | "dismissed" | "unsupported";

/** Native share sheet (mobile). Falls back to copy if not available. */
export async function nativeShare(title: string, text: string, url: string): Promise<ShareResult> {
  if (navigator.share) {
    try {
      await navigator.share({ title, text, url });
      return "shared";
    } catch (e) {
      return e instanceof Error && e.name === "AbortError" ? "dismissed" : "unsupported";
    }
  }
  return "unsupported";
}

export function whatsappUrl(text: string): string {
  return `https://wa.me/?text=${encodeURIComponent(text)}`;
}

export function telegramUrl(url: string, text: string): string {
  return `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`;
}

/** Share a file (e.g. catalog JSON) via native sheet, else download it. Returns how it was handled. */
export async function shareFile(file: File, title: string, text: string): Promise<"shared" | "downloaded" | "failed"> {
  try {
    const nav = navigator as Navigator & { canShare?: (d: { files: File[] }) => boolean };
    if (nav.share && nav.canShare?.({ files: [file] })) {
      await nav.share({ title, text, files: [file] });
      return "shared";
    }
  } catch {
    /* user cancelled or failed -> download instead */
  }
  try {
    const url = URL.createObjectURL(file);
    const a = document.createElement("a");
    a.href = url;
    a.download = file.name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    return "downloaded";
  } catch {
    return "failed";
  }
}

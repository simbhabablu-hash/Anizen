export type VideoKind = "mp4" | "embed";

export interface ParsedVideo {
  url: string;
  type: VideoKind;
  /** Which host we recognised, shown to the admin */
  host: "drive" | "dropbox" | "youtube" | "vimeo" | "direct" | "page";
  /** Short Hinglish note when the link needs the admin's attention */
  warning?: string;
}

const isUrl = (s: string) => /^https?:\/\//i.test(s);

/**
 * Turn whatever the admin pastes into something that actually plays.
 *  - Google Drive share link  -> Drive's own streaming player (no size limit, uses the owner's 15GB+ Drive)
 *  - Dropbox share link       -> direct file link
 *  - YouTube / Vimeo          -> their embed player
 *  - anything else            -> treated as a direct video file
 */
export function parseVideoLink(input: string): ParsedVideo | null {
  const raw = input.trim();
  if (!raw || !isUrl(raw)) return null;

  // Google Drive: /file/d/<id>/view , open?id=<id> , uc?id=<id>
  const drive =
    raw.match(/drive\.google\.com\/file\/d\/([\w-]{10,})/) ||
    raw.match(/drive\.google\.com\/(?:open|uc)\?[^#]*?id=([\w-]{10,})/);
  if (drive) {
    return {
      url: `https://drive.google.com/file/d/${drive[1]}/preview`,
      type: "embed",
      host: "drive",
      warning: 'Drive me file ko "Anyone with the link" share karna zaroori hai, warna dusre phones par nahi chalegi.',
    };
  }

  // Dropbox: make it a raw file link
  if (/dropbox\.com\//i.test(raw)) {
    // ?dl=0 opens a web page; ?raw=1 serves the file itself
    const u = raw.replace(/([?&])dl=[01]/i, "$1raw=1");
    const url = /[?&]raw=1/.test(u) ? u : u + (u.includes("?") ? "&" : "?") + "raw=1";
    return { url, type: "mp4", host: "dropbox" };
  }

  if (/youtube\.com|youtu\.be/i.test(raw)) return { url: raw, type: "embed", host: "youtube" };
  if (/vimeo\.com/i.test(raw)) return { url: raw, type: "embed", host: "vimeo" };

  // Obvious web pages (not a video file) can only be shown as an embed
  const path = raw.split("?")[0].toLowerCase();
  const looksLikeFile = /\.(mp4|webm|mov|m4v|mkv|ogv|ogg|m3u8)$/.test(path);
  if (!looksLikeFile && /\.(html?|php|aspx?)$/.test(path)) {
    return {
      url: raw,
      type: "embed",
      host: "page",
      warning: "Ye video file nahi, webpage lag raha hai. Embed me tabhi chalega jab wo site embed allow kare.",
    };
  }

  return { url: raw, type: "mp4", host: "direct" };
}

export const HOST_LABEL: Record<ParsedVideo["host"], string> = {
  drive: "Google Drive",
  dropbox: "Dropbox",
  youtube: "YouTube",
  vimeo: "Vimeo",
  direct: "Direct video link",
  page: "Web page",
};

export interface BulkRow {
  title: string;
  video: ParsedVideo;
}

/**
 * Bulk text -> episodes. One episode per line:
 *   https://link
 *   Episode name | https://link
 * Blank lines and lines without a valid link are reported back, not silently dropped.
 */
export function parseBulk(text: string): { rows: BulkRow[]; skipped: string[] } {
  const rows: BulkRow[] = [];
  const skipped: string[] = [];
  for (const line of text.split(/\r?\n/)) {
    const l = line.trim();
    if (!l) continue;
    let title = "";
    let link = l;
    const bar = l.indexOf("|");
    if (bar > -1) {
      title = l.slice(0, bar).trim();
      link = l.slice(bar + 1).trim();
    }
    const video = parseVideoLink(link);
    if (!video) skipped.push(l.length > 60 ? l.slice(0, 57) + "..." : l);
    else rows.push({ title, video });
  }
  return { rows, skipped };
}

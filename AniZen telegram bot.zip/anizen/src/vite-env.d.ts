/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_API_URL?: string;
  readonly VITE_WORKER_URL?: string;
  readonly VITE_CATALOG_ID?: string;
  readonly VITE_NOSTR_SEED?: string;
  readonly VITE_NOSTR_RELAYS?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}

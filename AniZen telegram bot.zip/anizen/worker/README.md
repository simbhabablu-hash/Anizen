# AniZen Catalog Worker (Cloudflare) — Setup Guide

Ye Worker + KV aapki website ka permanent shared server hai. Sabhi phones yahi se anime padhenge.

## Step 1 — Free Cloudflare account
1. `cloudflare.com` kholo → **Sign Up** → free account banao → email verify karo.

## Step 2 — Worker banao
1. Dashboard me **Workers & Pages** → **Create** → **Workers** tab → **Start with Hello World** → **Deploy**.
2. Apne naye Worker par click karo → **Edit code**.
3. Wahan ka saara purana code hatao, aur `worker/catalog-worker.js` file ka poora code paste karo → **Save and deploy**.

## Step 3 — KV storage banao
1. Wapas **Workers & Pages** → **KV** → **Create a namespace** → naam `aniverse` → **Add**.

## Step 4 — KV ko Worker se jodo (Binding)
1. Apne Worker → **Settings** → **Bindings** → **Add binding** → **KV namespace**.
2. Variable name bilkul ye likho: `CATALOG`
3. Namespace: `aniverse` select karo → **Deploy**.

## Step 5 — Admin secret banao
1. Worker → **Settings** → **Variables and Secrets** → **Add** → type **Secret**.
2. Naam: `ADMIN_KEY`, value: apna secret (jaise `balvir63cf`) → **Deploy**.
3. Ye secret kisi ko mat dena. Sirf aapke admin phone me use hoga.

## Step 6 — Website se connect karo
1. Worker ka URL copy karo, jaise `https://aniverse-catalog.tumhara.workers.dev`
2. AniZen website → Admin Panel → **Cloudflare Sync** me Worker URL + wahi ADMIN_KEY daal ke **Connect & upload** dabao.
3. Wahi Worker URL developer ko bhej do — wo `src/config.ts` me daal ke deploy karega. Uske baad **har phone par** same anime dikhenge.

## Kharcha
Workers + KV dono ka free plan is website ke liye kaafi hai.

/**
 * AniZen shared catalog API — Cloudflare Worker + KV.
 *
 * Setup (no coding needed, dashboard only):
 *  1. Deploy this file as a Worker (paste into Edit code).
 *  2. Create a KV namespace (e.g. "aniverse").
 *  3. Worker Settings > Bindings > add KV binding, variable name: CATALOG
 *  4. Worker Settings > Variables > add Secret: ADMIN_KEY = your secret
 *
 * API:
 *  GET /catalog  -> public, returns { version, anime[] }  (every visitor reads this)
 *  PUT /catalog  -> needs header  X-Admin-Key: <ADMIN_KEY>  (only the admin app writes)
 */

export default {
  async fetch(request, env) {
    const cors = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, PUT, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, X-Admin-Key",
      "Access-Control-Max-Age": "86400",
    };
    const json = (obj, status = 200) =>
      new Response(JSON.stringify(obj), {
        status,
        headers: { ...cors, "Content-Type": "application/json" },
      });

    if (request.method === "OPTIONS") return new Response(null, { headers: cors });

    const path = new URL(request.url).pathname;
    if (path !== "/catalog") {
      return json({ ok: true, usage: "GET /catalog (public), PUT /catalog (admin key)" });
    }

    if (!env.CATALOG) {
      return json(
        { error: "KV binding 'CATALOG' missing. Worker Settings > Bindings me KV namespace jodo." },
        500,
      );
    }

    if (request.method === "GET") {
      const val = await env.CATALOG.get("catalog", "json");
      if (!val || !Array.isArray(val.anime)) return json({ version: 1, anime: [] });
      return json({ version: 1, anime: val.anime });
    }

    if (request.method === "PUT") {
      if (!env.ADMIN_KEY) {
        return json(
          { error: "ADMIN_KEY secret set nahi hai. Worker Settings > Variables me secret banao." },
          500,
        );
      }
      const got = request.headers.get("X-Admin-Key") || "";
      if (got !== env.ADMIN_KEY) {
        return json({ error: "Admin key galat hai." }, 401);
      }
      let body;
      try {
        body = await request.json();
      } catch {
        return json({ error: "JSON sahi nahi hai." }, 400);
      }
      const list = Array.isArray(body) ? body : body.anime;
      if (!Array.isArray(list)) return json({ error: "anime array chahiye." }, 400);
      const text = JSON.stringify({ version: 1, anime: list });
      if (text.length > 20 * 1024 * 1024) {
        return json({ error: "Catalog bahut bada hai (20MB se zyada)." }, 413);
      }
      await env.CATALOG.put("catalog", text);
      return json({ ok: true, count: list.length });
    }

    return json({ error: "Sirf GET aur PUT allowed." }, 405);
  },
};
